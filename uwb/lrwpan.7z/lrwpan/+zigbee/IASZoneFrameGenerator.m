function iasFrame = IASZoneFrameGenerator(cfg)
%IASZoneFrameGenerator Generate Intruder Alarm System Zone cluster library frames
%   IASFRAME = IASZONEFRAMEGENERATOR(CFG) generates the Intruder Alarm
%   System Zone cluster library frames frame IASFRAME corresponding to the
%   configuration object CFG.
%
%   See also zigbee.IASZoneFrameConfig, zigbee.IASZoneFrameDecoder.

%   Copyright 2017-2023 The MathWorks, Inc.

  % 1. Zone Status (2 octets)
  zoneStatus = generateZoneStatus(cfg);
 
  % 2. Extended status (1 octet, reserved, set to 0)
	extendedStatus = zeros(8, 1);
 
  % 3. Zone ID (1 octet)
	zoneID = int2bit(cfg.ZoneID, 8, false); 
 
  % 4. Delay (2 octets)
	delay = int2bit(hex2dec(cfg.Delay), 2*8, false);
 
  % 5. Putting it all together:
	iasFrame = [zoneStatus; extendedStatus; zoneID; delay];
  % Convert to bytes:
  iasFrame = zigbee.internal.bits2bytes(iasFrame);
end

function zoneStatus = generateZoneStatus(cfg)
  
  % 0. Preallocate:
  zoneStatus = zeros(2*8, 1);
  
  % 1. Alarm1 
  zoneStatus(1) = double(strcmp(cfg.Alarm1, 'Alarmed'));
  
  % 2. Alarm2
  zoneStatus(2) = double(strcmp(cfg.Alarm2, 'Alarmed'));
  
  % 3. Tamper
  zoneStatus(3) = double(cfg.Tampered);
  
  % 4. Low battery
  zoneStatus(4) = double(cfg.LowBattery);
  
  % 5. Supervision reports
  zoneStatus(5) = double(cfg.PeriodicReports);
  
  % 6. Restore reports
  zoneStatus(6) = double(cfg.RestoreReports);
  
  % 7. Trouble
  zoneStatus(7) = double(cfg.Trouble);
  
  % 8. AC fault
  zoneStatus(8) = double(cfg.ACFault);
  
  % 9. Test mode
  zoneStatus(9) = double(cfg.TestMode);
  
  % 10. BatteryDefect
  zoneStatus(10) = double(cfg.BatteryDefect);
end