function cfg = ColorControlFrameDecoder(commandType, zclPayload)
%COLORCONTROLFRAMEDECODER Decode frames of the Color Control ZigBee cluster
% CFG = COLORCONTROLFRAMEDECODER(ZCLCONFIG, ZCLPAYLOAD) decodes the Color
% Control ZigBee payload ZCLPAYLOAD for the command type COMMANDTYPE and
% outputs the corresponding Color Control cluster frame configuration to
% the object CFG.
%
%   See also zigbee.ColorControlFrameConfig, zigbee.ColorControlFrameGenerator.

% Copyright 2017-2023 The MathWorks, Inc.

% 0. Initializing configuration object
cfg = zigbee.ColorControlFrameConfig('CommandType', commandType);

% convert bytes to bits
if ~isempty(zclPayload)
  zclPayloadBin = zigbee.internal.bytes2bits(zclPayload);
end

currPos = 1;
switch commandType
  % Move to Hue
  case 'Move to Hue'
    hueLen = 8;
    cfg = decodeMoveToHueCommand(cfg, zclPayloadBin, hueLen);

  % Enhanced Move to Hue
  case 'Enhanced Move to Hue'
    % 1. Enhanced Hue (2 octets)
    hueLen = 2*8;
    cfg = decodeMoveToHueCommand(cfg, zclPayloadBin, hueLen);

  % Move Hue
  case {'Move Hue', 'Move Saturation'}
    rateLen = 8;
    cfg = decodeMoveCommands(cfg, zclPayloadBin, rateLen);
    
  case 'Enhanced Move Hue'
    rateLen = 2*8;
    cfg = decodeMoveCommands(cfg, zclPayloadBin, rateLen);

  % Step Hue
  case {'Step Hue', 'Step Saturation'}
    len = 8;
    cfg = decodeStepCommands(cfg, zclPayloadBin, len);
    
  case 'Enhanced Step Hue'
    len = 2*8;
    cfg = decodeStepCommands(cfg, zclPayloadBin, len);
        
  % Move to Saturation
  case 'Move to Saturation'
    
    cfg = decodeMoveToSaturation(cfg, zclPayloadBin, currPos);

  % Move to Hue and Saturation
  case 'Move to Hue and Saturation'
    % 1. Hue (1 octet)
    cfg.Hue = bit2int(zclPayloadBin(currPos:currPos+7)', 8, false);
    currPos = currPos+8;

    % 2 & 3. Saturation & Time
    cfg = decodeMoveToSaturation(cfg, zclPayloadBin, currPos);
    
	% Enhanced Move to Hue and Saturation
  case 'Enhanced Move to Hue and Saturation'
    % 1. Enhanced Hue (2 octets)
    cfg.Hue = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 2 & 3. Saturation & Time
    cfg = decodeMoveToSaturation(cfg, zclPayloadBin, currPos);

  % Move to Color
  case 'Move to Color'
    % 1. ColorX (2 octets)
    cfg.ColorX = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 2. ColorY (2 octets)
    cfg.ColorY = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 3. Transition Time (2 octets)
    cfg.Time = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);

  % Move Color
  case 'Move Color'
    % 1. RateX (2 octets)
    cfg.RateX = bit2int(zclPayloadBin(currPos:currPos+15', 16, false));
    currPos = currPos+16;

    % 2. RateY (2 octets)
    cfg.RateY = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);

  % Step Color
  case 'Step Color'
    % 1. StepX (2 octets)
    cfg.StepX = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 2. StepY (2 octets)
    cfg.StepY = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 3. Transition Time (2 octets)
    cfg.Time = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);

  % Move to Color Temperature
  case 'Move to Color Temperature'
    % 1. Color Temperature Mireds (2 octets)
    cfg.Mireds = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 2. Transition Time (2 octets)
    cfg.Time = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);

  % Color Loop Set
  case 'Color Loop Set'
    % 1. Update Flags (1 octet)
    cfg = decodeUpdateFlags(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 2. Color Loop Action (1 octet)
    cfg = decodeAction(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 3. Color Loop HueDirection (1 octet)
    cfg = decodeLoopDirection(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 4. Time (2 octets)
    cfg.Time = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 5. Start Hue (2 octets)
    cfg.StartHue = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);

  % Move Color Temperature
  case 'Move Color Temperature'
    % 1. Move Mode (1 octet)
    cfg = decodeMoveMode(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 2. Rate (2 octets)
    cfg.Rate = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 3. Color Temperature Minimum Mireds (2 octets)
    cfg.MinMireds = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 4. Color Temperature Maximum Mireds (2 octets)
    cfg.MaxMireds = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);

  % Step Color Temperature
  case 'Step Color Temperature'
    % 1. Step Mode (1 octet)
    cfg = decodeStepMode(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 2. Step Size (2 octets)
    cfg.StepSize = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 3. Transition Time (2 octets)
    cfg.Time = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 4. Color Temperature Minimum Mireds (2 octets)
    cfg.MinMireds = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;

    % 5. Color Temperature Maximum Mireds (2 octets)
    cfg.MaxMireds = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
end
end

function cfg = decodeMoveToHueCommand(cfg, zclPayloadBin, hueLen)
  currPos = 1;
  
  % 1. Hue (1 or 2 octets)
  cfg.Hue = bit2int(zclPayloadBin(currPos:currPos + hueLen-1)', hueLen, false);
  currPos = currPos + hueLen;

  % 2. HueDirection (1 octet)
  cfg = decodeDirection(cfg, zclPayloadBin(currPos:currPos+7));
  currPos = currPos+8;

  % 3. Transition Time (2 octets)
  cfg.Time = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
end

function cfg = decodeMoveCommands(cfg, zclPayloadBin, rateLen)
  currPos = 1;
  % 1. Move Mode (1 octet)
  cfg = decodeMoveMode(cfg, zclPayloadBin(currPos:currPos+7));
  currPos = currPos+8;

  % 2. Rate (1 octet)
  cfg.Rate = bit2int(zclPayloadBin(currPos:currPos+rateLen-1)', rateLen, false);
end

function cfg = decodeStepCommands(cfg, zclPayloadBin, len)
  currPos = 1;
 % 1. Step Mode (1 octet)
  cfg = decodeStepMode(cfg, zclPayloadBin(currPos:currPos+7));
  currPos = currPos+8;

  % 2. Step Size (1 octet)
  cfg.StepSize = bit2int(zclPayloadBin(currPos:currPos + len-1)', len, false);
  currPos = currPos + len;

  % 3. Transition Time (2 octets)
  cfg.Time = bit2int(zclPayloadBin(currPos:currPos + len-1)', len, false);
end

function cfg = decodeMoveToSaturation(cfg, zclPayloadBin, currPos)

  % 1. Saturation (1 octet)
  cfg.Saturation = bit2int(zclPayloadBin(currPos:currPos+7)', 8, false);
  currPos = currPos+8;

  % 2. Transition Time (2 octets)
  cfg.Time = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
end

function cfg = decodeDirection(cfg, HueDirection)
switch bit2int(HueDirection(:), length(HueDirection), false)
  case 0
    cfg.HueDirection = 'Shortest distance';
  case 1
    cfg.HueDirection = 'Longest distance';
  case 2
    cfg.HueDirection = 'Up';
  case 3
    cfg.HueDirection = 'Down';
  otherwise
    warning(getString(message('lrwpan:ZigBee:ZCLInvalidValue', 'Direction')));
end
end

function cfg = decodeMoveMode(cfg, moveMode)
switch bit2int(moveMode(:), length(moveMode), false)
  case 0
    cfg.MoveMode = 'Stop';
  case 1
    cfg.MoveMode = 'Up';
  case 3
    cfg.MoveMode = 'Down';
  otherwise
    warning(getString(message('lrwpan:ZigBee:ZCLInvalidValue', 'Move mode')));
end
end

function cfg = decodeStepMode(cfg, stepMode)
switch bit2int(stepMode(:), length(stepMode), false)
  case 1
    cfg.StepMode = 'Up';
  case 3
    cfg.StepMode = 'Down';
  otherwise
    warning(getString(message('lrwpan:ZigBee:ZCLInvalidValue', 'Step mode')));
end
end

function cfg = decodeAction(cfg, action)
switch bit2int(action(:), length(action), false)
  case 0
    cfg.Action = 'De-activate';
  case 1
    cfg.Action = 'Activate from StartHue';
  case 2
    cfg.Action = 'Activate from current Hue';
  otherwise
    warning(getString(message('lrwpan:ZigBee:ZCLInvalidValue', 'Action')));
end
end

function cfg = decodeLoopDirection(cfg, loopDirection)
if bit2int(loopDirection(:), length(loopDirection), false) == 0
  cfg.ColorLoopDirection = 'Decreasing';
elseif bit2int(loopDirection(:), length(loopDirection), false) == 1
  cfg.ColorLoopDirection = 'Increasing';
else
  warning(getString(message('lrwpan:ZigBee:ZCLInvalidValue', 'Color loop direction')));
end
end

function cfg = decodeUpdateFlags(cfg, updateFlags)
% 1. Update Action (1 Bit)
cfg.UpdateAction = logical(updateFlags(1));

% 2. Update HueDirection (1 Bit)
cfg.UpdateDirection = logical(updateFlags(2));

% 3. Update Time (1 Bit)
cfg.UpdateTime = logical(updateFlags(3));

% 4. Update Start Hue (1 Bit)
cfg.UpdateStartHue = logical(updateFlags(4));

% 5. Reserved (5 Bits)
end