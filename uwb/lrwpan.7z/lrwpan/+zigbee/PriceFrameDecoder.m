function cfg = PriceFrameDecoder(commandType, zclPayload)
%PriceFrameDecoder Decode frames of ZigBee Smart-Energy Price cluster
%   CFG = PriceFrameDecoder(ZCLCONFIG, ZCLPAYLOAD) decodes the ZigBee Smart-Energy
%   Price-cluster frame ZCLPAYLOAD and outputs the corresponding configuration to the
%   object CFG.
%
%   See also zigbee.PriceFrameConfig, zigbee.PriceFrameGenerator.

%   Copyright 2017-2023 The MathWorks, Inc.

% convert bytes to bits
if ~isempty(zclPayload)
  zclPayloadBin = zigbee.internal.bytes2bits(zclPayload);
end

% 0. Initialize:
cfg = zigbee.PriceFrameConfig;

switch commandType
  case 'Get Current Price'
    % 1. Command type
    cfg.CommandType = 'Get Current Price';
    
    % 2 Rx on when idle
    cfg.IdleReceiving = logical(zclPayloadBin(1));
    
  case 'Price Acknowledgment'
    % 1. Command type
    cfg.CommandType = 'Price Acknowledgment';
    
    % 2. Provider identifier
    cfg.ProviderID = bit2int(zclPayloadBin(1:4*8)', 4*8, false);    
    
    % 3. Issuer event identifier
    cfg.EventID = bit2int(zclPayloadBin(4*8+1:8*8)', 4*8, false);    
    
    % 4. Generated time
    cfg.GenerationTime = bit2int(zclPayloadBin(8*8+1:12*8)', 4*8, false);
    
    % 5. Control
    control = zclPayloadBin(12*8+1:13*8);
    
    % 5.1 Price Acknowledgment
    cfg.PriceAcknowledgment = logical(control(1));
    
    
  case 'Publish Price'
    % 1. Command type
    cfg.CommandType = 'Publish Price';
    cnt = 0;
    
    % 2. Provider Id
    cfg.ProviderID = bit2int(zclPayloadBin(cnt+1:cnt+4*8)', 4*8, false);
    cnt = cnt+4*8;
    
    % 3. Rate label
    lengthOfTheLabel = bit2int(zclPayloadBin(cnt+1:cnt+8)', 8, false);
    cnt = cnt+8;
    if (lengthOfTheLabel ~= 0)
      cfg.RateLabel = zigbee.internal.decodeLabel(zclPayloadBin(cnt+1:cnt+lengthOfTheLabel*8));
      cnt = cnt+lengthOfTheLabel*8;
    end
    
    % 4. Issuer event ID
    cfg.EventID = bit2int(zclPayloadBin(cnt+1:cnt+4*8)', 4*8, false);
    cnt = cnt+4*8;
    
    % 5. Generated Time
    cfg.GenerationTime = bit2int(zclPayloadBin(cnt+1:cnt+4*8)', 4*8, false);
    cnt = cnt+4*8;
    
    % 6. Unit of measure
    ID = bit2int(zclPayloadBin(cnt+1:cnt+8)', 8, false);
    if ID >= hex2dec('80')
      index = ID + 1 - hex2dec('80');
      cfg.UnitFormat = 'BCD';
    else
      index = ID + 1;
      cfg.UnitFormat = 'Binary';
    end
    cfg.Unit =  zigbee.PriceFrameConfig.UnitValues{index};
    cnt = cnt+8;
    
    % 7. Currency
    cfg.Currency = bit2int(zclPayloadBin(cnt+1:cnt+2*8)', 2*8, false);
    cnt = cnt+2*8;    
   
    % 8. Price tier
    cfg.PriceTier = bit2int(zclPayloadBin(cnt+1:cnt+4)', 4, false);
    cnt = cnt+4;
    
    % 9. Price trailing digit - Indicates the number of digits after the decimal point of the price
    priceTrailingDigit = bit2int(zclPayloadBin(cnt+1:cnt+4)', 4, false);
    cnt = cnt+4;
    
    % 10. Register tier
    cfg.RegisterTier = bit2int(zclPayloadBin(cnt+1:cnt+4)', 4, false);
    cnt = cnt+4;
        
    % 11. Number of price tiers
    cfg.NumPriceTiers = bit2int(zclPayloadBin(cnt+1:cnt+4)', 4, false);
    cnt = cnt+4;   
        
    % 12. Start time
    cfg.StartTime = bit2int(zclPayloadBin(cnt+1:cnt+4*8)', 4*8, false);
    cnt = cnt+4*8;
    
    % 13. Duration in minutes
    cfg.Duration = bit2int(zclPayloadBin(cnt+1:cnt+2*8)', 2*8, false);
    cnt = cnt+2*8;
    
    % 14. Price
    price = num2str(bit2int(zclPayloadBin(cnt+1:cnt+4*8)', 4*8, false));
    cfg.Price = str2double(strcat(price(1:length(price)-priceTrailingDigit), '.', price(end-priceTrailingDigit+1:end)));        
 
end
end

