classdef ColorControlFrameConfig < matlab.mixin.CustomDisplay
%COLORCONTROLFRAMECONFIG Configuration for frames of the Color Control cluster library
% FRAMECONFIG = COLORCONTROLFRAMECONFIG creates a configuration object for
% frames of the Color Control cluster library.
%
% FRAMECONFIG = COLORCONTROLFRAMECONFIG(Name, Value) creates a ZigBee
% Color Control Cluster frame configuration object with the specified property
% Name set to the specified Value. You can specify additional name-value
% pair arguments in any order as (Name1, Value1, ..., NameN, ValueN).
%
% ColorControlFrameConfig properties:
%
% CommandType         - Command type
% Hue                 - Ultimate hue value
% HueDirection        - Direction of hue movement
% Time                - Duration of effect
% MoveMode            - Move mode (Up/Down/Stop)
% Rate                - Number of units per second
% StepMode            - Step mode (Up/Down)
% StepSize            - Amount of value change
% Saturation          - Ultimate saturation value
% ColorX              - X coordinate of CIE 1931 Color Space
% ColorY              - Y coordinate of CIE 1931 Color Space
% RateX               - Number of ColorX units per second
% RateY               - Number of ColorY units per second
% StepX               - Amount of ColorX value change
% StepY               - Amount of ColorY value change
% UpdateAction        - Flag for considering color-loop action
% Action              - Color-loop action
% UpdateDirection     - Flag for considering color-loop direction
% UpdateTime          - Flag for considering color-loop time
% UpdateStartHue      - Flag for considering color-loop start hue
% ColorLoopDirection  - Color Loop direction
% StartHue            - Initial hue of color loop
% Mireds              - Color temperature mireds
% MinMireds           - Minimum color temperature mireds
% MaxMireds           - Maximum color temperature mireds
%
% See also zigbee.ColorControlFrameGenerator, zigbee.ColorControlFrameDecoder.

% Copyright 2017-2023 The MathWorks, Inc.

properties
  %CommandType Command type
  % Specify CommandType as one of 'Move to Hue' | 'Move Hue' | 'Step Hue' |
  % 'Move to Saturation' | 'Move Saturation' | 'Step Saturation' |
  % 'Move to Hue and Saturation' | 'Move to Color' | 'Move Color' |
  % 'Step Color' | 'Move to Color Temperature' | 'Enhanced Move to Hue' |
  % 'Enhanced Move Hue' | 'Enhanced Step Hue' | 'Enhanced Move to Hue and Saturation' |
  % 'Color Loop Set' | 'Stop Move Step' | 'Move Color Temperature' |
  % 'Step Color Temperature'. The default is 'Move to Hue'.
  CommandType = 'Move to Hue';

  %Hue Ultimate hue value
  % Specify Hue as a scalar non-negative integer lesser than 256. The
  % default is 0.
  Hue = 0;

  %HueDirection Direction of hue movement
  % Specify HueDirection as one of 'Shortest distance' |'Longest distance' |
  % 'Up' | 'Down' . The default is 'Shortest distance'.
  HueDirection = 'Shortest distance';

  %MoveMode Move mode
  % Specify MoveMode as one of 'Stop' | 'Up' | 'Down'. The default is
  % 'Up'.
  MoveMode = 'Up';

  %Rate Number of units per second
  % Specify Rate as a scalar non-negative integer lesser than 256. The
  % default is 1.
  Rate = 1;

  %StepMode Step mode
  % Specify StepMode as one of 'Up' | 'Down' . The default is 'Up'.
  StepMode = 'Up';

  %StepSize Amount of value change
  % Specify StepSize as a scalar non-negative integer lesser than 256. The
  % default is 0.
  StepSize = 1;

  %Saturation Ultimate saturation value
  % Specify Saturation as a scalar non-negative integer lesser than 256.
  % The default is 0.
  Saturation = 0;

  %ColorX X coordinate of CIE 1931 Color Space
  % Specify ColorX as a scalar non-negative integer lesser than 2^16. The
  % value x in the xyY CIE 1931 Color Space is given by ColorX/65536. The
  % default is 0.
  ColorX = 0;

  %ColorY Y coordinate of CIE 1931 Color Space
  % Specify ColorX as scalar non-negative integer lesser than 2^16. The
  % value y in the xyY CIE 1931 Color Space is given by ColorY/65536. The
  % default is 0.
  ColorY = 0;

  %RateX Number of ColorX units per second
  % Specify RateX as a scalar non-negative integer lesser than 256. The
  % default is 1.
  RateX = 1;

  %RateY Number of ColorY units per second
  % Specify RateY as a scalar non-negative integer lesser than 256. The
  % default is 0.
  RateY = 1;

  %StepX Amount of ColorX value change
  % Specify StepX as a scalar non-negative integer lesser than 256. The
  % default is 1.
  StepX = 1;

  %StepY Amount of ColorY value change
  % Specify StepY as a scalar non-negative integer lesser than 256. The
  % default is 1.
  StepY = 1;

  %UpdateAction Flag for considering color-loop action
  % Specify UpdateAction as a logical scalar. If true, the device will
  % consider the Action property. The default is false.
  UpdateAction = false;

  %UpdateDirection Flag for considering color-loop direction
  % Specify UpdateDirection as a logical scalar. If true, the device will
  % consider the color loop direction. The default is false.
  UpdateDirection = false;

  %UpdateTime Flag for considering color-loop time
  % Specify UpdateTime as a logical scalar. If true, the device will
  % consider the color loop time. The default is false.
  UpdateTime = false;

  %UpdateStartHue Flag for considering color-loop start hue
  % Specify UpdateStartHue as a logical scalar. If true, the device will
  % consider the StartHue value. The default is false.
  UpdateStartHue = false;
  
  %Action Color-loop action
  % Specify Action as one of 'De-activate' | 'Activate from StartHue' |
  % 'Activate from current Hue'. The default is 'De-activate'.
  Action = 'De-activate';

  %ColorLoopDirection Color Loop direction
  % Specify ColorLoopDirection as one of 'Decreasing' | 'Increasing'.
  % The default is 'Decreasing'.
  ColorLoopDirection = 'Decreasing';
  
	%Mireds Color temperature mireds
  % Specify Mireds as a scalar non-negative integer lesser than
  % 256. The default is 500.
  Mireds = 500;

  %Time Duration of effect
  % Specify Time, in deciseconds (i.e., tenths of a second), as a scalar
  % non-negative integer lesser than 256. The default is 30 (i.e., 3 seconds).
  Time = 30;
  
  %MinMireds Minimum color temperature mireds
  % Specify MinMireds as a scalar non-negative integer lesser than 256. The
  % default is 100.
  MinMireds = 100;

  %MaxMireds Maximum color temperature mireds
  % Specify MaxMireds as a scalar non-negative integer lesser than 256. The
  % default is 1000.
  MaxMireds = 1000;
  
  %StartHue Initial hue of color loop
  % Specify StartHue as a scalar non-negative integer lesser than 256. The
  % default is 0.
  StartHue = 0;
end

properties(Constant, Hidden)
  CommandTypeValues = {'Move to Hue', 'Move Hue', 'Step Hue', 'Move to Saturation', ...
    'Move Saturation', 'Step Saturation', 'Move to Hue and Saturation', ...
    'Move to Color', 'Move Color', 'Step Color', 'Move to Color Temperature', ...
    'Enhanced Move to Hue', 'Enhanced Move Hue', 'Enhanced Step Hue', ...
    'Enhanced Move to Hue and Saturation', 'Color Loop Set', 'Stop Move Step', ...
    'Move Color Temperature', 'Step Color Temperature'};
  HueDirectionValues = {'Shortest distance', 'Longest distance', 'Up', 'Down'};
  MoveModeValues = {'Stop', 'Up', 'Down'};
  StepModeValues = {'Up', 'Down'};
  ColorLoopDirectionValues = {'Decreasing', 'Increasing'};
  ActionValues = {'De-activate', 'Activate from StartHue', 'Activate from current Hue'}
end

methods
  function obj = ColorControlFrameConfig(varargin)
    % Apply constructor name value pairs:
    for i = 1:2:nargin
      obj.(varargin{i}) = varargin{i+1};
    end
  end

  % For auto-completion:
  function v = set(obj, prop)
    v = obj.([prop, 'Values']);
  end

  function obj = set.CommandType(obj, value)
    obj.CommandType = validatestring(value, obj.CommandTypeValues, '', 'CommandType');
  end

  function obj = set.Hue(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'Hue');
    obj.Hue = value;
  end

  function obj = set.HueDirection(obj, value)
    obj.HueDirection = validatestring(value, obj.HueDirectionValues, '', 'HueDirection');
  end

  function obj = set.Time(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'Time');
    obj.Time = value;
  end

  function obj = set.MoveMode(obj, value)
    obj.MoveMode = validatestring(value, obj.MoveModeValues, '', 'MoveMode');
  end

  function obj = set.Rate(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 256}, '', 'Rate');
    obj.Rate = value;
  end
    
  function obj = set.StepMode(obj, value)
    obj.StepMode = validatestring(value, obj.StepModeValues, '', 'StepMode');
  end

  function obj = set.StepSize(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 256}, '', 'StepSize');
    obj.StepSize = value;
  end

  function obj = set.Saturation(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 256}, '', 'Saturation');
    obj.Saturation = value;
  end

  function obj = set.ColorX(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'ColorX');
    obj.ColorX = value;
  end

  function obj = set.ColorY(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'ColorY');
    obj.ColorY = value;
  end

  function obj = set.RateX(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'RateX');
    obj.RateX = value;
  end

  function obj = set.RateY(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'RateY');
    obj.RateY = value;
  end

  function obj = set.StepX(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'StepX');
    obj.StepX = value;
  end

  function obj = set.StepY(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'StepY');
    obj.StepY = value;
  end

  function obj = set.Mireds(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'Mireds');
    obj.Mireds = value;
  end

  function obj = set.UpdateAction(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'UpdateAction');
    obj.UpdateAction = value;
  end

  function obj = set.UpdateDirection(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'UpdateDirection');
    obj.UpdateDirection = value;
  end

  function obj = set.UpdateTime(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'UpdateTime');
    obj.UpdateTime = value;
  end

  function obj = set.UpdateStartHue(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'UpdateStartHue');
    obj.UpdateStartHue = value;
  end

  function obj = set.ColorLoopDirection(obj, value)
    obj.ColorLoopDirection = validatestring(value, obj.ColorLoopDirectionValues, '', 'ColorLoopDirection');
  end

  function obj = set.Action(obj, value)
    obj.Action = validatestring(value, obj.ActionValues, '', 'Action');
  end

  function obj = set.MinMireds(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'MinMireds');
    obj.MinMireds = value;
  end

  function obj = set.MaxMireds(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'MaxMireds');
    obj.MaxMireds = value;
  end

  function obj = set.StartHue(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'StartHue');
    obj.StartHue = value;
  end
end

methods (Access = protected)
  function groups = getPropertyGroups(obj)
    propList = properties(obj);
    activeIdx1 = true(size(propList));

    for n = 1:numel(propList)
      if  isInactiveProperty(obj, propList{n})
        activeIdx1(n) = false;
      end
    end
    groups = matlab.mixin.util.PropertyGroup(propList(activeIdx1));
  end

  function flag = isInactiveProperty(obj, prop)
    flag = false;
    if strcmp(prop, 'Hue')
      flag = ~any(strcmp(obj.CommandType, {'Move to Hue', 'Move to Hue and Saturation', ...
              'Enhanced Move to Hue', 'Enhanced Move to Hue and Saturation'}));
      
    elseif strcmp(prop, 'HueDirection')
      flag = ~any(strcmp(obj.CommandType, {'Move to Hue', 'Enhanced Move to Hue'}));

    elseif strcmp(prop, 'Time')
      flag = any(strcmp(obj.CommandType, {'Move Hue', 'Move Saturation', ...
                                          'Move Color', 'Enhanced Move Hue', 'Stop Move Step', ...
                                          'Move Color Temperature'}));
                                    
    elseif strcmp(prop, 'MoveMode')
      flag = ~any(strcmp(obj.CommandType, {'Move Hue', 'Move Saturation', 'Enhanced Move Hue', ...
                                           'Move Color Temperature'}));
                                    
    elseif strcmp(prop, 'Rate')
      flag = ~any(strcmp(obj.CommandType, {'Move Hue', 'Move Saturation', 'Enhanced Move Hue', 'Move Color Temperature'}));
                  
    elseif strcmp(prop, 'StepMode')
      flag = ~any(strcmp(obj.CommandType, {'Step Hue', 'Step Saturation', 'Enhanced Step Hue', ...
                                           'Step Color Temperature'}));
                                    
    elseif strcmp(prop, 'StepSize')
      flag = ~any(strcmp(obj.CommandType, {'Step Hue', 'Step Saturation', 'Enhanced Step Hue', 'Step Color Temperature'}));
        
    elseif strcmp(prop, 'Saturation')
      flag = ~any(strcmp(obj.CommandType, {'Move to Saturation', 'Move to Hue and Saturation', ...
                                      'Enhanced Move to Hue and Saturation'}));
                                    
    elseif any(strcmp(prop, {'ColorX', 'ColorY'}))
      flag = ~strcmp(obj.CommandType, 'Move to Color');
      
    elseif any(strcmp(prop, {'RateX', 'RateY'}))
      flag = ~strcmp(obj.CommandType, 'Move Color');
      
    elseif any(strcmp(prop, {'StepX', 'StepY'}))
      flag = ~strcmp(obj.CommandType, 'Step Color');
      
    elseif strcmp(prop, 'Mireds')
      flag = ~strcmp(obj.CommandType, 'Move to Color Temperature');
      
    elseif any(strcmp(prop, {'UpdateAction', 'UpdateDirection', 'UpdateTime', 'UpdateStartHue', ...
                             'Action', 'ColorLoopDirection', 'StartHue'}))
      flag = ~strcmp(obj.CommandType, 'Color Loop Set');
      
    elseif any(strcmp(prop, {'MinMireds', 'MaxMireds'}))
      flag = ~any(strcmp(obj.CommandType, {'Move Color Temperature', 'Step Color Temperature'}));
    end
  end
end

end
