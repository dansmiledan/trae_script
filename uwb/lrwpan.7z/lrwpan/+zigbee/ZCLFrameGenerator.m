function zclFrame = ZCLFrameGenerator(cfg, varargin)
%ZCLFrameGenerator Generate ZigBee Cluster Library frames 
%   ZCLFRAME = ZCLFRAMEGENERATOR(CFG)  generates the ZigBee Cluster Library
%   frame ZCLFRAME corresponding to the ZigBee Cluster Library
%   configuration object CFG.
%
%   See also zigbee.ZCLFrameConfig, zigbee.ZCLFrameDecoder.

%   Copyright 2017-2023 The MathWorks, Inc.
  
  % 1. Frame Control (1 octet)
  frameControl = generateFrameControl(cfg);

  % 2. Manufacturer code (0 or 2 octets)
  if cfg.ManufacturerCommand    
    manufacturerCode = int2bit(cfg.ManufacturerCode, 2*8, false);
  else
    manufacturerCode = [];
  end

  % 3. SequenceNumber (1 octet)
  seqNo = int2bit(cfg.SequenceNumber, 1*8, false);

  % 4. CommandID (1 octet)
  commandID = zigbee.commandID(cfg.CommandType);

  % 5. Put everything together:
  zclFrame = [frameControl; manufacturerCode; seqNo; commandID];
  % Convert bits to bytes:
  zclFrame = zigbee.internal.bits2bytes(zclFrame);
  if nargin > 1
    payload = varargin{1};
    zclFrame = [zclFrame; payload];
  end
end


function frameControl = generateFrameControl(cfg)
  
  % 0. preallocate:
  frameControl = zeros(8, 1);
  
  % 1. Frame type (2 bits)
  if strcmp(cfg.FrameType, 'Library-wide')
    frameControl(1:2) = [0; 0];
  else
    frameControl(1:2) = [1; 0];
  end

  % 2. Manufacturer-specific command (1-bit)
  frameControl(3) = double(cfg.ManufacturerCommand);

  % 3. Direction (1-bit)
  frameControl(4) = double(strcmp(cfg.Direction, 'Downlink'));

  % 4. Disable default response (1-bit)
  frameControl(5) = double(cfg.DisableDefaultResponse);
  
  % bits 6-8 are reserved (zeros)
end

