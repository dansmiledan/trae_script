function ID = commandID( commandName )
%COMMANDID Get the binary ID of a ZigBee command

% Copyright 2017-2023 The MathWorks, Inc.

  switch commandName
    case 'Read Attributes'
      IDhex = '00';
    case 'Read Attributes Response'
      IDhex = '01';
    case 'Write Attributes'
      IDhex = '02';
    case 'Write Attributes Undivided'
      IDhex = '03';
    case 'Write Attributes Response'
      IDhex = '04';
    case 'Write Attributes No Response'
      IDhex = '05';
    case 'Configure Reporting'
      IDhex = '06';
    case 'Configure Reporting Response'
      IDhex = '07';
    case 'Read Reporting Configuration'
      IDhex = '08';
    case 'Read Reporting Configuration Response'
      IDhex = '09';
    case 'Report Attributes'
      IDhex = '0A';
    case 'Default Response'
      IDhex = '0B';
    case 'Discover Attributes'
      IDhex = '0C';
    case 'Discover Attributes Response'
      IDhex = '0D';
    case 'Read Attributes Structured'
      IDhex = '0E';
    case 'Write Attributes Structured'
      IDhex = '0F';
    case 'Write Attributes Structured Response'
      IDhex = '10';
    case 'Discover Commands Received'
      IDhex = '11';
    case 'Discover Commands Received Response'
      IDhex = '12';
    case 'Discover Commands Generated'
      IDhex = '13';
    case 'Discover Commands Generated Response'
      IDhex = '14';
    case 'Discover Attributes Extended'
      IDhex = '15';
    case 'Discover Attributes Extended Response'
      IDhex = '16';
      
      
   % CLUSTER SPECIFIC COMMANDS:
   
    % Basic cluster
    case 'Reset to Factory Defaults'
      IDhex = '00';

    % On/Off cluster
    case 'Off'
      IDhex = '00';
    case 'On'
      IDhex = '01';
    case 'Toggle'
      IDhex = '02';
    case 'Off with effect'
      IDhex = '40';
    case 'On with recall global scene'
      IDhex = '41';
    case 'On with timed off'
      IDhex = '42';

    % Intruder Alarm System (IAS) Zone cluster
    case 'Zone Status Change Notification'
      IDhex = '00';
    case 'Zone Enroll Request'
      IDhex = '01';

    % Intruder Alarm System (IAS) Warning Device cluster
    case 'Start warning'
      IDhex = '00';
    case 'Squawk'
      IDhex = '01';

    % Color Control Cluster
    case 'Move to Hue'
      IDhex = '00';
    case 'Move Hue'
      IDhex = '01';
    case 'Step Hue'
      IDhex = '02';
    case 'Move to Saturation'
      IDhex = '03';
    case 'Move Saturation'
      IDhex = '04';
    case 'Step Saturation'
      IDhex = '05';
    case 'Move to Hue and Saturation'
      IDhex = '06';
    case 'Move to Color'
      IDhex = '07';
    case 'Move Color'
      IDhex = '08';
    case 'Step Color'
      IDhex = '09';
    case 'Move to Color Temperature'
      IDhex = '0a';
    case 'Enhanced Move to Hue'
      IDhex = '40';
    case 'Enhanced Move Hue'
      IDhex = '41';
    case 'Enhanced Step Hue'
      IDhex = '42';
    case 'Enhanced Move to Hue and Saturation'
      IDhex = '43';
    case 'Color Loop Set'
      IDhex = '44';
    case 'Stop Move Step'
      IDhex = '47';
    case 'Move Color Temperature'
      IDhex = '4b';
    case 'Step Color Temperature'
      IDhex = '4c';

    % Commissioning Cluster
    case 'Restart Device'
      IDhex = '00';
    case 'Save Startup Parameters'
      IDhex = '01';
    case 'Restore Startup Parameters'
      IDhex = '02';
    case  'Reset Startup Parameters'
      IDhex = '03';
    case 'Restart Device Response'
      IDhex = '00';
    case 'Save Startup Parameters Response'
      IDhex = '01';
    case 'Restore Startup Parameters Response'
      IDhex = '02';
    case 'Reset Startup Parameters Response'
      IDhex = '03';

    % Group Cluster
    case 'Add group'
      IDhex = '00';
    case 'View group'
      IDhex = '01';
    case 'Get group membership'
      IDhex = '02';
    case 'Remove group'
      IDhex = '03';
    case 'Remove all groups'
      IDhex = '04';
    case 'Add group if identifying'
      IDhex = '05';
    case 'Add group response'
      IDhex = '00';
    case 'View group response'
      IDhex = '01';
    case 'Get group membership response'
      IDhex = '02';
    case 'Remove group response'
      IDhex = '03';

    % Identify Cluster
    case 'Identify'
      IDhex = '00';
    case 'Identify Query'
      IDhex = '01';
    case 'Trigger effect'
      IDhex = '40';
    case 'Identify Query Response'
      IDhex = '00';

    % Level control Cluster
    case 'Move to Level'
      IDhex = '00';
    case 'Move'
      IDhex = '01';
    case 'Step'
      IDhex = '02';
    case 'Stop'
      IDhex = '03';
    case 'Move to Level with OnOff'
      IDhex = '04';
    case 'Move with OnOff'
      IDhex = '05';
    case 'Step with OnOff'
      IDhex = '06';
    case 'Stop with OnOff'
      IDhex = '07';

    % Scene Cluster
    case 'Add Scene'
      IDhex = '00';
    case 'View Scene'
      IDhex = '01';
    case 'Remove Scene'
      IDhex = '02';
    case 'Remove All Scenes'
      IDhex = '03';
    case 'Store Scene'
      IDhex = '04';
    case 'Recall Scene'
      IDhex = '05';
    case 'Get Scene Membership'
      IDhex = '06';
    case 'Enhanced Add Scene'
      IDhex = '40';
    case 'Enhanced View Scene'
      IDhex = '41';
    case 'Copy Scene'
      IDhex = '42';
    case 'Add Scene Response'
      IDhex = '00';
    case 'View Scene Response'
      IDhex = '01';
    case 'Remove Scene Response'
      IDhex = '02';
    case 'Remove All Scenes Response'
      IDhex = '03';
    case 'Store Scene Response'
      IDhex = '04';
    case 'Get Scene Membership Response'
      IDhex = '06';
    case 'Enhanced Add Scene Response'
      IDhex = '40';
    case 'Enhanced View Scene Response'
      IDhex = '41';
    case 'Copy Scene Response'
      IDhex = '42';

    % ZLL Commissioning Cluster
    case 'Scan request'
      IDhex = '00';
    case 'Device information request'
      IDhex = '02';
    case 'Identify request'
      IDhex = '06';
    case 'Reset to factory new request'
      IDhex = '07';
    case 'Network start request'
      IDhex = '10';
    case 'Network join router request'
      IDhex = '12';
    case 'Network join end device request'
      IDhex = '14';
    case 'Network update request'
      IDhex = '16';
    case 'Get group identifiers request'
      IDhex = '41';
    case 'Get endpoint list request'
      IDhex = '42';
    case 'Scan response'
      IDhex = '01';
    case 'Device information response'
      IDhex = '03';
    case 'Network start response'
      IDhex = '11';
    case 'Network join router response'
      IDhex = '13';
    case 'Network join end device response'
      IDhex = '15';
    case 'Endpoint information'
      IDhex = '40';
    case 'Get group identifiers response'
      IDhex = '41';
    case 'Get endpoint list response'
      IDhex = '42';
      
    % Smart Energy - DRLC Cluster (Demand Response and Load Control)
    case 'Load Control Event'
      IDhex = '00';
    case 'Cancel Load Control Event'
      IDhex = '01';
    case 'Cancel All Load Control Events'
      IDhex = '02';
    case 'Report Event Status'
      IDhex = '00';
    case 'Get Scheduled Events'
      IDhex = '01';
      
    % Smart Energy - Energy Management Cluster
    case 'Manage Event'
      IDhex = '00';
    % DRLC & Energy Management clusters contain a common command
    % 'Report Event Status'(with commandID: 00) which is already handled.
    % Hence, there is no need to duplicate the case for Energy Management Cluster.
            
    % Messaging Cluster Server Side Commands
    case 'Display Message'
      IDhex = '00';
    case 'Cancel Message'
      IDhex = '01';
      
    % Messaging Cluster Client Side Commands
    case 'Get Last Message'
      IDhex = '00';
    case 'Message Confirmation'
      IDhex = '01';
      
    % Price Cluster Client side commands
    case 'Get Current Price'
      IDhex = '00';
    case 'Price Acknowledgment'
      IDhex = '02';
      
    % Price Cluster Server side commands
    case 'Publish Price'
      IDhex = '00';
      
    otherwise
      IDhex = '00';
      warning(message('lrwpan:ZigBee:UnknownZCLCommand', commandName));
                
  end
  ID = int2bit(hex2dec(IDhex), 8, false);
end

