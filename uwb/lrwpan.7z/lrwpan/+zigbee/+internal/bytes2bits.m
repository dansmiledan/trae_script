function bits = bytes2bits(bytes)
%BYTES2BITS Convert byte column to binary row

% Copyright 2017-2023 The MathWorks, Inc.

bits = int2bit(hex2dec(bytes), 8, false)';
