classdef SecurityConfig < matlab.mixin.CustomDisplay 
  %SecurityConfig Common (security) configuration for ZigBee NET and APP layer frames
  %   FRAMECONFIG = SecurityConfig creates a common configuration object for
  %   ZigBee NET/APP frames.
  %
  %   FRAMECONFIG = SecurityConfig(Name,Value) creates a Base ZigBee
  %   NET/APP frame configuration object with the specified property Name
  %   set to the specified Value. You can specify additional name-value
  %   pair arguments in any order as (Name1,Value1,...,NameN,ValueN).
  %
  %   SecurityConfig properties:
  %
  %   Security              - Indication of secure frame
  %   DataEncryption        - Indication of encrypted payload
  %   MICLength             - Length of message integrity code (MIC)
  %   KeyIdentifier         - Key type
  %   ExtendedNonce         - Presence of sender address in auxiliary (security) header
  %   FrameCounter          - Frame counter
  %   SecuritySourceAddress - Source address in auxiliary (security) header
  %   KeySequence           - Key sequence number
  %
  %   See also zigbee.NETFrameConfig, zigbee.APPFrameConfig
  
  %   Copyright 2017-2023 The MathWorks, Inc.
  
  properties
    %Security Security enabled
    % Specify Security as a logical scalar indicating whether the auxiliary
    % (security) header is present. The default is false.
    Security = false
    
    %DataEncryption Indication of encrypted payload
    % Specify DataEncryption as a scalar logical. If true, the
    % network-layer payload is encrypted. The default is false.
    DataEncryption = false
    
    %MICLength Length of message integrity code (MIC)
    % Specify MICLength as one of 0 | 32 | 64 | 128 (bits). The message
    % integrity code is the last part of the network-layer payload and
    % enables data authentication. The default is 0.
    MICLength = 0
    
    %KeyIdentifier Key type
    % Specify KeyIdentifier as one of 'Data' | 'Network' |
    % 'Key-transport' | 'Key-load'. The default is 'Network'.
    KeyIdentifier = 'Network'
    
    %ExtendedNonce Presence of sender address in auxiliary (security) header
    % Specify ExtendedNonce as a scalar logical. If true, the source
    % address in included in the auxiliary (security) header. The default
    % is false.
    ExtendedNonce = false
    
    %FrameCounter Frame counter
    % Specify FrameCounter as a scalar non-negative integer. The default is 0.
    FrameCounter = 0
    
    %SecuritySourceAddress Source address in auxiliary (security) header
    % Specify SecuritySourceAddress as a 16-character hexadecimal vector
    % indicating the 64-bit address of the device securing the frame. This
    % property applies only when ExtendedNonce is set to true. The default
    % is '0000000000000000'.
    SecuritySourceAddress = '0000000000000000'
    
    %KeySequence Key sequence number
    % Specify KeySequence as a scalar non-negative integer to express the
    % key sequence number of the network key used to secure the frame.
    % This property applies only when KeyIdentifier is set to 'Network'.
    % The default is 0.
    KeySequence = 0
  end
  
  properties(Constant, Hidden)
    KeyIdentifierValues = {'Data', 'Network', 'Key-transport', 'Key-load'}
  end
  
  methods
    function obj = SecurityConfig(varargin)
      % Apply constructor name value pairs:
      for i = 1:2:nargin
          obj.(varargin{i}) = varargin{i+1};
      end
    end
    
    % For auto-completion:
    function v = set(obj, prop)
      v = obj.([prop, 'Values']);
    end

    function obj = set.Security(obj, value)
      validateattributes(value, {'logical'}, {'scalar'}, '', 'Security');
      obj.Security = value;
    end
    
    function obj = set.DataEncryption(obj, value)
      validateattributes(value, {'logical'}, {'scalar'}, '', 'DataEncryption');
      obj.DataEncryption = value;
    end
    
    function obj = set.MICLength(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real'}, '', 'MICLength');
      if ~any(value == [0 32 64 128])
        error(message('lrwpan:ZigBee:InvalidMIC'));
      end
      obj.MICLength = value;
    end
    
    function obj = set.KeyIdentifier(obj, value)
      obj.KeyIdentifier = validatestring(value, obj.KeyIdentifierValues, '', 'KeyIdentifier');
    end
    
    function obj = set.ExtendedNonce(obj, value)
      validateattributes(value, {'logical'}, {'scalar'}, '', 'ExtendedNonce');
      obj.ExtendedNonce = value;
    end
    
    function obj = set.FrameCounter(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real'}, '', 'FrameCounter');
      obj.FrameCounter = value;
    end
    
    function obj = set.KeySequence(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real'}, '', 'KeySequence');
      obj.KeySequence = value;
    end
    
    function obj = set.SecuritySourceAddress(obj, value)
      value = convertStringsToChars(value);
      validateattributes(value, {'char'}, {'row', 'numel', 16}, '', 'SecuritySourceAddress');
      obj.SecuritySourceAddress = value;
    end
  end
  
  methods (Access=protected)
    
    function groups = getPropertyGroups(obj)
      
      propList1  = {'Security'; 'DataEncryption'; 'MICLength'; 'KeyIdentifier'; 'ExtendedNonce'; 'FrameCounter'; 'SecuritySourceAddress'; 'KeySequence'};
      title1 = getString(message('lrwpan:ZigBee:SecurityTitle'));
      activeIdx1 = true(size(propList1));
      

      for n = 1:numel(propList1)
          if isInactiveProperty(obj,propList1{n})
              activeIdx1(n) = false;
          end
      end
      groups = coder.nullcopy(repmat(matlab.mixin.util.PropertyGroup(propList1(activeIdx1)), 1, 1)); 
      groups(1) = matlab.mixin.util.PropertyGroup(propList1(activeIdx1), title1);
    end
    
    function flag = isInactiveProperty(obj, prop)
      % Controls the conditional display of properties

      flag = false;

      if any(strcmp(prop, {'DataEncryption', 'MICLength', 'KeyIdentifier', 'ExtendedNonce', 'FrameCounter', 'SecuritySourceAddress', 'KeySequence'}))
        flag = ~obj.Security;
        
        if strcmp(prop, 'SecuritySourceAddress')
          flag = ~obj.ExtendedNonce || flag;
        end
        
        if strcmp(prop, 'KeySequence')
          flag = ~strcmp(obj.KeyIdentifier, 'Network') || flag;
        end
      end
    end
  end
  
end

