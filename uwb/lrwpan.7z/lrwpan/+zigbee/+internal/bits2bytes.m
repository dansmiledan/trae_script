function bytes = bits2bytes(bits)
%BITS2BYTES Convert binary row/column to column-wise byte output

% Copyright 2017-2023 The MathWorks, Inc.

bytes = dec2hex(bit2int(bits(:), 8, false), 2);


