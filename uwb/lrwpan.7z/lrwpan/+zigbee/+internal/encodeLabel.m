function rateLabel = encodeLabel(label)

  %

  % Copyright 2017-2023 The MathWorks, Inc.

  unicodeValues = unicode2native(label, 'UTF-8'); % To get Unicode values of each character
  rateLabel = zeros(1, numel(unicodeValues)*8);
  for idx= 1:numel(unicodeValues)
    rateLabel(1+(idx-1)*8:idx*8) = int2bit(unicodeValues(idx), 8, false)';
  end
