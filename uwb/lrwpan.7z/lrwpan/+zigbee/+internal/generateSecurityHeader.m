function securityHeader = generateSecurityHeader(cfg)
%   CFG = generateSecurityHeader(NETFRAME) generates the auxiliary security
%   header of frame FRAME, according to the NET/APP-layer configuration
%   object CFG. This header is common for the ZigBee network- and
%   application-layers.
%
%   See also zigbee.NETFrameGenerator, zigbee.APPFrameGenerator

%   Copyright 2017-2023 The MathWorks, Inc.

if ~cfg.Security
  securityHeader = [];
  return
end

% else cfg.Security = true

% 1. Security control
securityControl = generateSecurityControl(cfg);

% 2. Frame counter
frameCounter = int2bit(cfg.FrameCounter, 4*8, false)';
 
% 3. Source address
[sourceAddress1, sourceAddress2, keySequenceNo] = deal([]);
if cfg.ExtendedNonce
  % two steps because of 2^53 limit in dec representation
  sourceAddress1 = int2bit(hex2dec(cfg.SecuritySourceAddress(9:end)),4*8, false)';
  sourceAddress2 = int2bit(hex2dec(cfg.SecuritySourceAddress(1:8)),  4*8, false)';
end
 
% 4. Key sequence
if strcmp(cfg.KeyIdentifier, 'Network')
  keySequenceNo = int2bit(cfg.KeySequence, 8, false)';
end

securityHeader = [securityControl frameCounter sourceAddress1 sourceAddress2 keySequenceNo];


function securityControl = generateSecurityControl(cfg)

if cfg.DataEncryption || cfg.MICLength > 0
  error(message('lrwpan:ZigBee:NoSecureFrames'));
end

% 0. Initialize
securityLevel = zeros(1, 3);

% 1. Security level
if cfg.MICLength == 128
  securityLevel(1:2) = [1 1];
else
  securityLevel(1:2) = int2bit(cfg.MICLength/32, 2, false)';
end
securityLevel(3) = double(cfg.DataEncryption);

% 2. Key identifier
if strcmp(cfg.KeyIdentifier, 'Data')
  keyID = [0 0];
elseif strcmp(cfg.KeyIdentifier, 'Network')
  keyID = [1 0];
elseif strcmp(cfg.KeyIdentifier, 'Key-transport')
  keyID = [0 1];
elseif strcmp(cfg.KeyIdentifier, 'Key-load')
  keyID = [1 1];
end

% 3. Extended Nonce
extendedNonce = double(cfg.ExtendedNonce);

securityControl = [securityLevel keyID extendedNonce 0 0];
