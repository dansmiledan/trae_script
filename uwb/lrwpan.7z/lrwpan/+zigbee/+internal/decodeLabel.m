function rateLabel = decodeLabel(label)

  %

  % Copyright 2017-2023 The MathWorks, Inc.

  lengthOfLabel = numel(label)/8 ; % Length of the message
  unicodeValues = zeros(1, lengthOfLabel);
  for idx= 1:lengthOfLabel
    unicodeValues(idx) = bit2int(label(1+(idx-1)*8:idx*8)', 8, false);
  end
  rateLabel = native2unicode(unicodeValues); % To get the actual message
