function [cfg, cnt] = decodeSecurityHeader(cfg, frame, cnt)
%   CFG = decodeSecurityHeader(NETFRAME) decodes the auxiliary security
%   header of frame FRAME. This header is common for the ZigBee network-
%   and application-layers. The NET/APP configuration object CFG is updated
%   accordingly, and so is the frame counter CNT.
%
%   See also zigbee.NETFrameDecoder, zigbee.APPFrameDecoder

%   Copyright 2017-2023 The MathWorks, Inc.

% 1. Security control

% 1a. SecurityLevel

% Length of message integrity code (MIC)
level = bit2int(frame(cnt+1:cnt+2)', 2, false);
if level < 3
  cfg.MICLength = 32*level;
else
  cfg.MICLength = 128;
end

% Data encryption
cfg.DataEncryption = frame(cnt+3) == 1;


% 1b. Key identifier
switch bit2int(frame(cnt+4:cnt+5)', 2, false)
  case 0
    cfg.KeyIdentifier = 'Data';
  case 1
    cfg.KeyIdentifier = 'Network';
  case 2
    cfg.KeyIdentifier = 'Key-transport';
  otherwise
    cfg.KeyIdentifier = 'Key-load';
end

% 1.c Extended nonce
cfg.ExtendedNonce = frame(cnt+6) == 1;

cnt = cnt+8;

% 2. FrameCounter
cfg.FrameCounter = bit2int(frame(cnt+1 : cnt+4*8)', 4*8, false);
cnt = cnt+4*8;

% 3. Source address
if cfg.ExtendedNonce
  if length(frame(cnt+1:end)) < 8*8
    warning(message('lrwpan:ZigBee:MalformedFrame'));
    return;
  end
  for idx = 1:16
    cfg.SecuritySourceAddress(16-idx+1) = dec2hex(bit2int(frame(cnt+1:cnt+4)', 4, false));
    cnt = cnt+4;
  end
end

if strcmp(cfg.KeyIdentifier, 'Network')
  if length(frame(cnt+1:end)) < 8
    warning(message('lrwpan:ZigBee:MalformedFrame'));
    return;
  end
  cfg.KeySequence = bit2int(frame(cnt+1:cnt+8)', 8, false);
  cnt = cnt+8;
end