classdef PriceFrameConfig < matlab.mixin.CustomDisplay
  % PriceFrameConfig Configuration for frames of the ZigBee Smart Energy Price cluster
  %   FRAMECONFIG = PriceFrameConfig creates a configuration object for
  %   frames of the ZigBee Smart Energy Price cluster.
  %
  %   FRAMECONFIG = PriceFrameConfig(Name,Value) creates a configuration
  %   object for a ZigBee frame of the Price cluster with the specified
  %   Name set to the specified Value. You can specify additional
  %   name-value pair arguments in any order as (Name1,Value1,...,NameN,ValueN).
  %
  %   PriceFrameConfig properties:
  %
  %   CommandType                   - Name of cluster command
  %   IdleReceiving                 - Option to activate radio when idle
  %   ProviderID                    - Identifier of commodity provider
  %   EventID                       - Identifier of pricing information
  %   GenerationTime                - Time of command generation
  %   PriceAcknowledgment          - Option to request price acknowledgment
  %   RateLabel                     - Label of current billing rate
  %   Unit                          - Unit of measurement
  %   UnitFormat                    - Format of unit
  %   Currency                      - Currency code according to ISO 4217
  %   PriceTier                     - Index of current price tier
  %   RegisterTier                  - Index of current register tier
  %   NumPriceTiers                 - Number of available price tiers
  %   StartTime                     - Time when price becomes valid
  %   Duration                      - Duration of price in minutes
  %   Price                         - Price of the commodity
  %
  %   See also zigbee.PriceFrameGenerator, zigbee.PriceFrameDecoder.
  
  %   Copyright 2017-2023 The MathWorks, Inc.
  
  properties
    %CommandType Name of cluster command
    % Specify the name of the cluster command as one of 'Get Current Price'
    % | 'Price Acknowledgment' | 'Publish Price'. The default is 'Get
    % Current Price'.
    CommandType = 'Get Current Price';
    
    %IdleReceiving Option to activate radio when idle
    % Specify IdleReceiving as a logical scalar. If true, the device does
    % not disable its receiver to conserve power during idle periods. The
    % default is false.
    IdleReceiving = false;
    
    %ProviderID Identifier of commodity provider
    % Specify ProviderID as a scalar non-negative real integer that is not
    % greater than 4294967296. The default is 0.
    ProviderID = 0;
    
    %EventID Identifier of pricing information
    % Specify EventID as a scalar non-negative real integer that is
    % not greater than 4294967296. The default is 0. The higher its value,
    % the more recently the price information was issued.
    EventID = 0;
    
    %GenerationTime Time of command generation
    % Specify GenerationTime as a scalar non-negative real integer
    % containing the number of seconds since midnight of 1-1-2000. The
    % default is 0.
    GenerationTime = 0;
        
    %PriceAcknowledgment Option to request price acknowledgment
    % Specify PriceAcknowledgment as a logical scalar. If true, the sender
    % requests Acknowledgment for the Publish Price command. The default
    % is false.
    PriceAcknowledgment = false;
    
    %RateLabel Label of current billing rate
    % Specify RateLabel as a vector containing no more than 12 characters.
    % RateLabel shall be encoded in the UTF-8 format. This property
    % provides distinction in case a commodity provider has multiple
    % pricing plans. The default is ''.
    RateLabel = '';
        
    %Unit Unit of measurement
    % Specify Unit as one of 'kW' | 'Cubic Meter' | 'Cubic Feet' | 'ccf' |
    % 'US gl' | 'IMP gl' | 'BTU' | 'Liters' | 'kPA (gauge)' | 'kPA
    % (absolute)' | 'mcf' | 'MJ' | 'Unitless'. The default is 'kW'.
    Unit = 'kW'
    
    %UnitFormat Format of unit
    % Specify UnitFormat as 'Binary' or 'BCD', i.e., binary-coded decimal.
    % The default is 'Binary'.
    UnitFormat = 'Binary'
    
    %Currency Currency code according to ISO 4217
    % Specify Currency as a scalar non-negative integer expressing a
    % currency's decimal code according to ISO 4217. The default is 840,
    % which corresponds to 'USD', i.e., US dollars.
    Currency = 840;
    
    %PriceTier Index of current price tier
    % Specify PriceTier as a scalar non-negative real integer smaller than
    % 49. The default is 1.
    PriceTier = 1;
    
    %NumPriceTiers Number of available price tiers
    % Specify NumPriceTiers as a scalar non-negative real integer smaller than 49.
    % The default is 0.
    NumPriceTiers = 0;
    
    %RegisterTier Register tier
    % Specify RegisterTier as a scalar non-negative real integer smaller than 49.
    % The default is 1.
    RegisterTier = 1;
        
    %StartTime Time when price becomes valid
    % Specify StartTime as a scalar non-negative real integer expressing
    % the number of seconds since midnight of 1-1-2000. The default is 0,
    % which is a special value denoting 'now'.
    StartTime = 0;  
    
    %Duration Duration of price in minutes
    % Specify Duration as a scalar non-negative real integer describing the
    % number of minutes that the price is valid (since StartTime). The
    % default is 0.
    Duration = 0;
        
    %Price Price of the commodity
    % Specify price as a floating point number. The price units are
    % specified via the Unit and UnitFormat properties. The default is 0.
    Price = 0;
  end
  
  properties(Constant, Hidden)
    CommandTypeValues = {'Get Current Price', 'Price Acknowledgment', 'Publish Price'};
    UnitValues = {'kW', 'Cubic Meter', 'Cubic Feet', 'ccf', 'US gl', 'IMP gl', 'BTU', ...
      'Liters', 'kPA (gauge)', 'kPA (absolute)', 'mcf', 'MJ', 'Unitless'};
    UnitFormatValues = {'Binary', 'BCD'}
  end
  
  methods
    function obj = PriceFrameConfig(varargin)
      % Apply constructor name value pairs:
      for i = 1:2:nargin
        obj.(varargin{i}) = varargin{i+1};
      end
    end
    
    % For auto-completion:
    function v = set(obj, prop)
      v = obj.([prop, 'Values']);
    end
    
    function obj = set.CommandType(obj, value)
      obj.CommandType = validatestring(value, obj.CommandTypeValues, '', 'CommandType');
    end
    
    function obj = set.ProviderID(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 4294967296}, '', 'ProviderID');
      obj.ProviderID = value;
    end
    
    function obj = set.RateLabel(obj, value)
      validateattributes(value, {'char'}, {'row'}, '', 'RateLabel');
      obj.RateLabel = value;
    end
    
    function obj = set.EventID(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 4294967296}, '', 'EventID');
      obj.EventID = value;
    end
    
    function obj = set.GenerationTime(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 4294967296}, '', 'GenerationTime');
      obj.GenerationTime = value;
    end
    
    function obj = set.Unit(obj, value)
      obj.Unit = validatestring(value, obj.UnitValues, '', 'Unit');
    end
    
    function obj = set.UnitFormat(obj, value)
      obj.UnitFormat = validatestring(value, obj.UnitFormatValues, '', 'UnitFormat');
    end
    
    function obj = set.Currency(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real'}, '', 'Currency');
      obj.Currency = value;
    end
    
    function obj = set.PriceTier(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<=', 48, '>=', 0}, '', 'PriceTier');
      obj.PriceTier = value;
    end
    
    function obj = set.RegisterTier(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<=', 48, '>=', 0}, '', 'RegisterTier');
      obj.RegisterTier = value;
    end
    
    function obj = set.NumPriceTiers(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<=', 48, '>=', 0}, '', 'NumPriceTiers');
      obj.NumPriceTiers = value;
    end
   
    function obj = set.StartTime(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 4294967296}, '', 'StartTime');
      obj.StartTime = value;
    end
    
    function obj = set.Duration(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'Duration');
      obj.Duration = value;
    end
    
    function obj = set.Price(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'nonnegative', 'real', '<', 4294967296}, '', 'Price');
      obj.Price = value;
    end     
    
    function obj = set.PriceAcknowledgment(obj, value)
      validateattributes(value, {'logical'}, {'scalar'}, '', 'PriceAcknowledgment');
      obj.PriceAcknowledgment = value;
    end
       
    function obj = set.IdleReceiving(obj, value)
      validateattributes(value, {'logical'}, {'scalar'}, '', 'IdleReceiving');
      obj.IdleReceiving = value;
    end
  end  
  
  methods (Access=protected)    
    
    function groups = getPropertyGroups(obj)
      
      propList1  = {'CommandType'; 'ProviderID'; 'RateLabel'; 'EventID'; ...
        'GenerationTime'; 'Unit'; 'UnitFormat'; 'Currency'; 'PriceTier'; 'RegisterTier'; 'NumPriceTiers'; ...
        'StartTime'; 'Duration'; 'Price'; 'PriceAcknowledgment'; 'IdleReceiving';};        
      activeIdx1 = true(size(propList1));
      
      for n = 1:numel(propList1)
        if isInactiveProperty(obj, propList1{n})
          activeIdx1(n) = false;
        end
      end
      groups = matlab.mixin.util.PropertyGroup(propList1(activeIdx1));
    end
    
    function flag = isInactiveProperty(obj, prop)
      % Controls the conditional display of properties
      
      flag = false;
      
      if strcmp(prop, 'IdleReceiving')
        flag = ~strcmp(obj.CommandType, 'Get Current Price');
      end
 
      if any(strcmp(prop, {'ProviderID', 'EventID', 'GenerationTime'}))
        flag = ~any(strcmp(obj.CommandType, {'Publish Price', 'Price Acknowledgment'}));
      end
      
      if strcmp(prop, 'PriceAcknowledgment')
        flag = ~strcmp(obj.CommandType, 'Price Acknowledgment');
      end
      
      if any(strcmp(prop, {'RateLabel', 'Unit', 'UnitFormat' 'Currency', 'PriceTier', 'RegisterTier', 'NumPriceTiers', ...
        'StartTime', 'Duration', 'Price'}))
        flag = ~strcmp(obj.CommandType, 'Publish Price');
      end
    end
  end  
end
