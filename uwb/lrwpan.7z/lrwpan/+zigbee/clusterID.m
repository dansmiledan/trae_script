function ID = clusterID( clusterName )
%CLUSTERID Get the ID of a ZigBee cluster

% Copyright 2017-2023 The MathWorks, Inc.

  % Home Automation
  if strcmpi(clusterName, 'On/Off')
    ID = '0006';
  elseif any(strcmpi(clusterName, {'IAS Zone', 'Intruder Alarm System Zone'}))
    ID = '0500';
  % Light Link
  elseif strcmpi(clusterName, 'Identify')
    ID = '0003';
  elseif strcmpi(clusterName, 'Color Control')
    ID = '0300';
  elseif strcmpi(clusterName, 'Scenes')
    ID = '0005';
  elseif strcmpi(clusterName, 'Level Control')
    ID = '0008';
  elseif strcmpi(clusterName, 'Groups')
    ID = '0004';
  elseif any(strcmpi(clusterName, {'DRLC', 'Demand Response Load Control', ...
      'Demand Response and Load Control', 'Demand Response & Load Control'}))
    ID = '0701';
  elseif strcmpi(clusterName, 'Messaging')
    ID = '0703';
  elseif strcmpi(clusterName, 'Price')
    ID = '0700';
  else
    ID = [];
  end
end

