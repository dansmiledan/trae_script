function cfg = DRLCFrameDecoder(commandType, zclPayload)
%DRLCFRAMEDECODER Decode frames of ZigBee Smart-Energy DRLC cluster
% CFG = DRLCFRAMEDECODER(ZCLCONFIG, ZCLPAYLOAD) decodes the ZigBee
% Smart-Energy frame ZCLPAYLOAD of the Demand Response Load Control cluster
% and outputs the corresponding configuration to the object CFG.
%
% See also zigbee.DRLCFrameConfig, zigbee.DRLCFrameGenerator.

% Copyright 2017-2023 The MathWorks, Inc.

% 0. Initializing configuration object
cfg = zigbee.DRLCFrameConfig('CommandType', commandType);

%zclPayload = zclPayload';
% convert bytes to bits
if ~isempty(zclPayload)
  zclPayloadBin = zigbee.internal.bytes2bits(zclPayload);
end

currPos = 1;
switch commandType
  % Load Control Event command
  case 'Load Control Event'
    % 1. Issuer Event ID (4-octets)
    cfg.EventID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+31)', 32, false), 8);
    currPos = currPos+32;
    
    % 2. Device Class bitmap (2-octets)
    cfg = decodeDeviceClassBitmap(cfg, zclPayloadBin(currPos:currPos+15));
    currPos = currPos+16;
    
    % 3. Utility Enrollment Group (1-octet)
    cfg.DeviceGroup = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);
    currPos = currPos+8;
    
    % 4. Start Time (4-octets)
    cfg.Time = bit2int(zclPayloadBin(currPos:currPos+31)', 32, false);
    currPos = currPos+32;
    
    % 5. Duration in Minutes (2-octets)
    cfg.Duration = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
    currPos = currPos+16;
    
    % 6. Criticality Level (1-octet)
    cfg = decodeCriticalityLevel(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;
    
    % 7. Cooling Temperature Offset (1-octet)
    cfg.CoolingOffset = double(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false)) / 10;
    currPos = currPos+8;
    
    % 8. Heating Temperature Offset (1-octet)
    cfg.HeatingOffset = double(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false)) / 10;
    currPos = currPos+8;
    
    % 9. Cooling Temperature Set-Point (2-octets)
    if ((double(typecast(uint16(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false)), 'int16')) / 100) == -327.68)
      % '-327.68' denotes this field is not being used. So, field is not
      % being filled.
    else
      cfg.CoolingSetPoint = ...
        double(typecast(uint16(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false)), 'int16')) / 100;
    end
    currPos = currPos+16;
    
    % 10. Heating Temperature Set-Point (2-octets)
    if ((double(typecast(uint16(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false)), 'int16')) / 100) == -327.68)
      % '-327.68' denotes this field is not being used. So, field is not
      % being filled.
    else
      cfg.HeatingSetPoint = ...
        double(typecast(uint16(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false)), 'int16')) / 100;
    end
    currPos = currPos+16;
    
    % 11. Average Load Adjustment Percentage (1-octet)
    currPos = currPos+8;
    
    % 12. Duty Cycle (1-octet)    
    currPos = currPos+8;
    
    % 13. Event Control (1-octet)
    cfg = decodeEventControl(cfg, zclPayloadBin(currPos:currPos+7));
    
  case 'Cancel Load Control Event'
    % 1. Issuer Event ID (4-octets)
    cfg.EventID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+31)', 32, false), 8);
    currPos = currPos+32;
    
    % 2. Device Class Bitmap (2-octets)
    cfg = decodeDeviceClassBitmap(cfg, zclPayloadBin(currPos:currPos+15));
    currPos = currPos+16;
    
    % 3. Utility Enrollment Group (1-octet)
    cfg.DeviceGroup = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);
    currPos = currPos+8;
    
    % 4. Cancel Control Bitmap (1-octet)
    cfg.RandomEnd = logical(zclPayloadBin(currPos));
    currPos = currPos+8;
    
    % 5. Effective Time (4-octets)
    cfg.Time = bit2int(zclPayloadBin(currPos:currPos+31)', 32, false);
    
  case 'Cancel All Load Control Events'
    % This command contains only one field
    
    % 1. Cancel Control Bitmap (1-octet)
    cfg.RandomEnd = logical(zclPayloadBin(currPos));
    
  case 'Report Event Status'
    % 1. Issuer Event ID (4-octets)
    cfg.EventID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+31)', 32, false), 8);
    currPos = currPos+32;
    
    % 2. Event Status (1-octet)
    cfg = decodeEventStatus(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;
    
    % 3. Event Status Time (4-octets)
    cfg.Time  = bit2int(zclPayloadBin(currPos:currPos+31)', 32, false);
    currPos = currPos+32;
    
    % 4. Criticality Level Applied (1-octet)
    cfg = decodeCriticalityLevel(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;
    
    % 5. Cooling Temperature Set-Point Applied (2-octets)
    if ((double(typecast(uint16(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false)), 'int16')) / 100) == -327.68)
      % '-327.68' denotes this field is not being used. So, field is not
      % being filled.
    else
      cfg.CoolingSetPoint = ...
        double(typecast(uint16(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false)), 'int16')) / 100;
    end
    currPos = currPos+16;
    
    % 6. Heating Temperature Set-Point Applied (2-octets)
    if ((double(typecast(uint16(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false)), 'int16')) / 100) == -327.68)
      % '-327.68' denotes this field is not being used. So, field is not
      % being filled.
    else
      cfg.HeatingSetPoint = ...
        double(typecast(uint16(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false)), 'int16')) / 100;
    end
    currPos = currPos+16;
    
    % 7. Average Load Adjustment Percentage (1-octet)   
    currPos = currPos+8;
    
    % 8. Duty Cycle (1-octet)
    currPos = currPos+8;
    
    % 9. Event Control Bitmap (1-octet)
    cfg = decodeEventControl(cfg, zclPayloadBin(currPos:currPos+7));
    
    % 10. Signature Type (1-octet)
    
    % 11. Signature (42-octets)
end

end

function cfg = decodeDeviceClassBitmap(cfg, bitmap)

index = find(bitmap, 1);
cfg.DeviceClass = zigbee.DRLCFrameConfig.DeviceClassValues{index};

end

function cfg = decodeCriticalityLevel(cfg, criticalityLevel)

index = bit2int(criticalityLevel(:), length(criticalityLevel), false);
cfg.CriticalityLevel = zigbee.DRLCFrameConfig.CriticalityLevelValues{index};
end

function cfg = decodeEventControl(cfg, eventControl)

% Bit-0 : Randomize Start Time
cfg.RandomStart = logical(eventControl(1));

% Bit-1 : Randomize End Time
cfg.RandomEnd = logical(eventControl(2));
end

function cfg = decodeEventStatus(cfg, eventStatus)

index = bit2int(eventStatus(:), length(eventStatus), false);
cfg.EventStatus = zigbee.DRLCFrameConfig.EventStatusValues{index};

end
