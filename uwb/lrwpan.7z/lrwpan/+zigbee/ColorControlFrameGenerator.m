function colorControlFrame = ColorControlFrameGenerator(cfg)
%COLORCONTROLFRAMEGENERATOR Generate frames for the Color Control ZigBee cluster
% COLORCONTROLFRAME = COLORCONTROLFRAMEGENERATOR(CFG) generates the Color Control
% cluster library frame COLORCONTROLFRAME corresponding to the configuration
% object CFG.
%
% See also zigbee.ColorControlFrameConfig, zigbee.ColorControlFrameDecoder.

% Copyright 2017-2023 The MathWorks, Inc.

switch cfg.CommandType
  % Move to Hue
  case 'Move to Hue'
    len = 8;
    colorControlFrame = generateMoveToHueCommand(cfg, len);
    
  case 'Enhanced Move to Hue'
    len = 2*8;
    colorControlFrame = generateMoveToHueCommand(cfg, len);

  % Move Hue
  case {'Move Hue', 'Move Saturation'}
    len = 8;
    colorControlFrame = generateMoveCommands(cfg, len);
    
  case 'Enhanced Move Hue'
    len = 2*8;
    colorControlFrame = generateMoveCommands(cfg, len);

  % Step Hue
  case {'Step Hue', 'Step Saturation'}
    
    len = 8;
    colorControlFrame = generateStepCommands(cfg, len);
    
  case 'Enhanced Step Hue'
    
    len = 2*8;
    colorControlFrame = generateStepCommands(cfg, len);

  % Move to Saturation
  case 'Move to Saturation'
    colorControlFrame = generateMoveToSaturation(cfg);

  % Move to Hue and Saturation
  case 'Move to Hue and Saturation'
    % 1. Hue (1 octet)
    hue = int2bit(cfg.Hue, 8, false);
    
    % 2 & 3. Saturation and Time
    colorControlFrame = generateMoveToSaturation(cfg);

    % 4. Putting it all together:
    colorControlFrame = [hue; colorControlFrame];
    
	% Enhanced Move to Hue and Saturation
  case 'Enhanced Move to Hue and Saturation'
    % 1. Enhanced Hue (2 octets)
    enhancedHue = int2bit(cfg.Hue, 16, false);
    
    % 2 & 3. Saturation and Time
    colorControlFrame = generateMoveToSaturation(cfg);

    % 4. Putting it all together:
    colorControlFrame = [enhancedHue; colorControlFrame];

  % Move to Color
  case 'Move to Color'
    % 1. ColorX (2 octets)
    colorX = int2bit(cfg.ColorX, 16, false);

    % 2. ColorY (2 octets)
    colorY = int2bit(cfg.ColorY, 16, false);

    % 3. Transition Time (2 octets)
    Time = int2bit(cfg.Time, 16, false);

    % 4. Putting it all together:
    colorControlFrame = [colorX; colorY; Time];

  % Move Color
  case 'Move Color'
    % 1. RateX (2 octets)
    rateX = int2bit(cfg.RateX, 16, false);

    % 2. RateY (2 octets)
    rateY = int2bit(cfg.RateY, 16, false);

    % 3. Putting it all together:
    colorControlFrame = [rateX; rateY];

  % Step Color
  case 'Step Color'
    % 1. StepX (2 octets)
    stepX = int2bit(cfg.StepX, 16, false);

    % 2. StepY (2 octets)
    stepY = int2bit(cfg.StepY, 16, false);

    % 3. Transition Time (2 octets)
    Time = int2bit(cfg.Time, 16, false);

    % 4. Putting it all together:
    colorControlFrame = [stepX; stepY; Time];

  % Move to Color Temperature
  case 'Move to Color Temperature'
    % 1. Color Temperature Mireds (2 octets)
    Mireds = int2bit(cfg.Mireds, 16, false);

    % 2. Transition Time (2 octets)
    Time = int2bit(cfg.Time, 16, false);

    % 2. Putting it all together:
    colorControlFrame = [Mireds; Time];

  % Color Loop Set
  case 'Color Loop Set'
    % 1. Update Flags (1 octet)
    updateFlags = generateUpdateFlags(cfg);

    % 2. Color Loop Action (1 octet)
    action = generateAction(cfg);

    % 3. Color Loop HueDirection (1 octet)
    loopDirection = generateLoopDirection(cfg);

    % 4. Time (2 octets)
    time = int2bit(cfg.Time, 16, false);

    % 5. Start Hue (2 octets)
    startHue = int2bit(cfg.StartHue, 16, false);

    % 6. Putting it all together:
    colorControlFrame = [updateFlags; action; loopDirection; time; startHue];

  % Stop Move Step
  case 'Stop Move Step'
    % This command doesn't have any Payload
    colorControlFrame = [];

  % Move Color Temperature
  case 'Move Color Temperature'
    % 1. Move Mode (1 octet)
    moveMode = generateMoveMode(cfg);

    % 2. Rate (2 octets)
    rate = int2bit(cfg.Rate, 16, false);

    % 3. Color Temperature Minimum Mireds (2 octets)
    MinMireds = int2bit(cfg.MinMireds, 16, false);

    % 4. Color Temperature Maximum Mireds (2 octets)
    MaxMireds = int2bit(cfg.MaxMireds, 16, false);

    % 5. Putting it all together:
    colorControlFrame = [moveMode; rate; MinMireds; MaxMireds];

  % Step Color Temperature
  case 'Step Color Temperature'
    % 1. Step Mode (1 octet)
    stepMode = generateStepMode(cfg);

    % 2. Step Size (2 octets)
    stepSize = int2bit(cfg.StepSize, 16, false);

    % 3. Transition Time (2 octets)
    Time = int2bit(cfg.Time, 16, false);

    % 4. Color Temperature Minimum Mireds (2 octets)
    MinMireds = int2bit(cfg.MinMireds, 16, false);

    % 5. Color Temperature Maximum Mireds (2 octets)
    MaxMireds = int2bit(cfg.MaxMireds, 16, false);

    % 6. Putting it all together:
    colorControlFrame = [stepMode; stepSize; Time; MinMireds; MaxMireds];
end
% Convert bits to bytes:
if ~isempty(colorControlFrame)
  colorControlFrame = zigbee.internal.bits2bytes(colorControlFrame);
end
end

function colorControlFrame = generateMoveToHueCommand(cfg, len)

  % 1. Hue (1 or 2 octets)
  hue = int2bit(cfg.Hue, len, false);

  % 2. HueDirection (1 octet)
  HueDirection = generateDirection(cfg);

  % 3. Transition Time (2 octets)
  Time = int2bit(cfg.Time, 16, false);

  % 4. Putting it all together:
  colorControlFrame = [hue; HueDirection; Time];
end

function colorControlFrame = generateMoveCommands(cfg, len)
  % 1. Move Mode (1 octet)
  moveMode = generateMoveMode(cfg);

  % 2. Rate (1 or 2 octets)
  rate = int2bit(cfg.Rate, len, false);

  % 3. Putting it all together:
  colorControlFrame = [moveMode; rate];
end

function colorControlFrame = generateStepCommands(cfg, len)
    % 1. Step Mode (1 octet)
    stepMode = generateStepMode(cfg);

    % 2. Step Size (1 or 2 octets)
    stepSize = int2bit(cfg.StepSize, len, false);

    % 3. Transition Time (1 or 2 octets)
    Time = int2bit(cfg.Time, len, false);

    % 4. Putting it all together:
    colorControlFrame = [stepMode; stepSize; Time];
end

function colorControlFrame = generateMoveToSaturation(cfg)
  % 1. Saturation (1 octet)
  saturation = int2bit(cfg.Saturation, 8, false);

  % 2. Transition Time (2 octets)
  Time = int2bit(cfg.Time, 16, false);

  % 3. Putting it all together:
  colorControlFrame = [saturation; Time];
end
    

function HueDirection = generateDirection(cfg)
switch cfg.HueDirection
  case 'Shortest distance'
    hd = 0;
  case 'Longest distance'
    hd = 1;
  case 'Up'
    hd = 2;
  case 'Down'
    hd = 3;
end
HueDirection = int2bit(hd, 8, false);
end

function moveMode = generateMoveMode(cfg)
switch cfg.MoveMode
  case 'Stop'
    mm = 0;
  case 'Up'
    mm = 1;
  case 'Down'
    mm = 3;
end
moveMode = int2bit(mm, 8, false);
end

function stepMode = generateStepMode(cfg)
switch cfg.StepMode
  case 'Up'
    sm = 1;
  case 'Down'
    sm = 3;
end
stepMode = int2bit(sm, 8, false);
end

function action = generateAction(cfg)
switch cfg.Action
  case 'De-activate'
    ac = 0;
  case 'Activate from StartHue'
    ac = 1;
  case 'Activate from current Hue'
    ac = 2;
end
action = int2bit(ac, 8, false);
end

function loopDirection = generateLoopDirection(cfg)
if strcmp(cfg.ColorLoopDirection, 'Decreasing')
    ld = 0;
else % Increasing
    ld = 1;
end
loopDirection = int2bit(ld, 8, false); 
end

function updateFlags = generateUpdateFlags(cfg)
% 0. Preallocate:
updateFlags = zeros(8, 1);

% 1. Update Action (1 Bit)
updateFlags(1) = double(cfg.UpdateAction);

% 2. Update HueDirection (1 Bit)
updateFlags(2) = double(cfg.UpdateDirection);

% 3. Update Time (1 Bit)
updateFlags(3) = double(cfg.UpdateTime);

% 4. Update Start Hue (1 Bit)
updateFlags(4) = double(cfg.UpdateStartHue);

% 5. Reserved (5 Bits)
end