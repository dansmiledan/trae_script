function cfg = IdentifyFrameDecoder(commandType, zclPayload)
%IDENTIFYFRAMEDECODER Decode frames of the Identify ZigBee cluster
% CFG = IDENTIFYFRAMEDECODER(COMMANDTYPE, ZCLPAYLOAD) decodes the ZigBee
% Cluster Library payload ZCLPAYLOAD for the command type COMMANDTYPE and
% outputs the corresponding Identify cluster frame configuration to the
% object CFG.
%
% See also zigbee.IdentifyFrameConfig, zigbee.IdentifyFrameGenerator.

% Copyright 2017-2023 The MathWorks, Inc.

% 0. Initializing configuration object
cfg = zigbee.IdentifyFrameConfig('CommandType', commandType);

% convert bytes to bits
if ~isempty(zclPayload)  
  zclPayloadBin = zigbee.internal.bytes2bits(zclPayload);
else
  % commandType = 'Identify Query' has no payload
  zclPayloadBin = [];
end

switch commandType
  % Identify
  case {'Identify', 'Identify Query Response'}
    % 1. Identify time (2 octets)
    cfg.IdentifyTime = bit2int(zclPayloadBin(:), length(zclPayloadBin), false);

  % Trigger effect
  case 'Trigger effect'
    % 1. Effect identifier (1 octet)
    cfg = decodeEffectIdentifier(cfg, zclPayloadBin(1:8));

    % 2. Effect Variant (1 octet) should be 0 (which corresponds to 'Default')
    if bit2int(zclPayloadBin(9:16)', 8, false) ~= 0
      warning(getString(message('lrwpan:ZigBee:ZCLInvalidEffectVariant')));
    end
end
end

function cfg = decodeEffectIdentifier(cfg, effectIdentifier)
switch dec2hex(bit2int(effectIdentifier(:), length(effectIdentifier), false), 2)
  case '00'
    cfg.EffectIdentifier = 'Blink';
  case '01'
    cfg.EffectIdentifier = 'Breathe';
  case '02'
    cfg.EffectIdentifier = 'Okay';
  case {'0b', '0B'}
    cfg.EffectIdentifier = 'Channel change';
  case {'fe', 'FE'}
    cfg.EffectIdentifier = 'Finish effect';
  case {'ff', 'FF'}
    cfg.EffectIdentifier = 'Stop effect';
  otherwise
    warning(getString(message('lrwpan:ZigBee:ZCLInvalidEffectIdentifier')));
end
end
