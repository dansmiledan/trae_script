function ID = profileID( profileName )
%PROFILEID Get the ID of a ZigBee application profile

% Copyright 2017-2023 The MathWorks, Inc.

  if any(strcmpi(profileName, {'ZigBee Home Automation', 'Home Automation'}))
    ID = '0104';
  elseif any(strcmpi(profileName, {'ZigBee Light Link', 'Light Link'}))
    ID = 'C05E';
  elseif any(strcmpi(profileName, {'ZigBee Smart Energy', 'Smart Energy'}))
    ID = '0109';
  else
    ID = [];
  end
end

