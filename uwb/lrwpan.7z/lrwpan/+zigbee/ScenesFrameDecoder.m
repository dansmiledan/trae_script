function cfg = ScenesFrameDecoder(commandType, zclPayload)
%SCENESFRAMEDECODER Decode frames of the Scenes ZigBee cluster
% CFG = SCENESFRAMEDECODER(ZCLCONFIG, ZCLPAYLOAD) decodes the Scenes ZigBee
% Cluster payload ZCLPAYLOAD for the command type COMMANDTYPE and outputs
% the corresponding Scenes cluster frame configuration to the object CFG.
%
% See also zigbee.ScenesFrameConfig, zigbee.ScenesFrameGenerator.

% Copyright 2017-2023 The MathWorks, Inc.

% 0. Initializing configuration object
cfg = zigbee.ScenesFrameConfig('CommandType', commandType);

% convert bytes to bits
if ~isempty(zclPayload)
  zclPayloadBin = zigbee.internal.bytes2bits(zclPayload);
end

currPos = 1;
switch commandType
	% Add Scene Commands
  case {'Add Scene', 'Enhanced Add Scene'}
    % 1. Group ID (2 octets)
    cfg.GroupID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    % 2. Scene ID (1 octet)
    cfg.SceneID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);
    currPos = currPos+8;

    cfg = decodeTimeNameExtField(cfg, zclPayloadBin, currPos);
    
  % View/Remove/Store/Recall Scene Commands
  case {'View Scene', 'Remove Scene', 'Store Scene', 'Recall Scene', 'Enhanced View Scene'}
    % 1. Group ID (2 octets)
    cfg.GroupID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    % 2. Scene ID (1 octet)
    cfg.SceneID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);

  % 'Remove All Scenes' / 'Get Scene Membership' Commands
  case {'Remove All Scenes', 'Get Scene Membership'}
    % 1. Group ID (2 octets)
    cfg.GroupID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);  

  % Copy Scene Command
  case 'Copy Scene'
    % 1. Copy All Scenes (1 bit)
    cfg.CopyAllScenes = logical(currPos);
    currPos = currPos+1;

    % Reserved bits in Mode field (7 bitS)
    currPos = currPos+7;

    % 2. Group ID From (2 octets)
    cfg.GroupIDFrom = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    % 3. Scene ID From (1 octet)
    cfg.SceneIDFrom = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);
    currPos = currPos+8;

    % 4. Group ID To (2 octets)
    cfg.GroupIDTo = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    % 5. Scene ID To (1 octet)
    cfg.SceneIDTo = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);
    
  % Add/Remove/Store Scene Response Command
  case {'Add Scene Response', 'Remove Scene Response', 'Store Scene Response', ...
        'Enhanced Add Scene Response'}
    % 1. Status (1 octet)
    cfg = decodeStatus(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 2. Group ID (2 octets)
    cfg.GroupID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    % 3. Scene ID (1 octet)
    cfg.SceneID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);

  % View Scene Response Command
  case {'View Scene Response', 'Enhanced View Scene Response'}
    % 1. Status (1 octet)
    cfg = decodeStatus(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 2. Group ID (2 octets)
    cfg.GroupID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    % 3. Scene ID (1 octet)
    cfg.SceneID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);
    currPos = currPos+8;

    if strcmp(cfg.Status, 'Success')
      cfg = decodeTimeNameExtField(cfg, zclPayloadBin, currPos);
    end
 
  % Remove All Scenes Response Command
  case 'Remove All Scenes Response'
    % 1. Status (1 octet)
    cfg = decodeStatus(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 2. Group ID (2 octets)
    cfg.GroupID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4); 

  % Get Scene Membership Response Command
  case 'Get Scene Membership Response'
    % 1. Status (1 octet)
    cfg = decodeStatus(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 2. Capacity (1 octet)
    cfg.Capacity = bit2int(zclPayloadBin(currPos:currPos+7)', 8, false);
    currPos = currPos+8;

    % 3. Group ID (2 octets)
    cfg.GroupID = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    if strcmp(cfg.Status, 'Success')
      % 4. Scene count (1 octet)
      cfg.SceneCount = bit2int(zclPayloadBin(currPos:currPos+7)', 8, false);
      currPos = currPos+8;

      % 5. Scenes list (sceneCount number of octets)
      sceneList = zeros(cfg.SceneCount, 1);
      for i = 1:cfg.SceneCount
        sceneList(i) = bit2int(zclPayloadBin(currPos:currPos+7)', 8, false);
        currPos = currPos+8;
        cfg.SceneList(i) = dec2hex(sceneList, 2);
      end
    end

  % Copy Scene Response Command
  case 'Copy Scene Response'
    % 1. Status (1 octet)
    cfg = decodeStatus(cfg, zclPayloadBin(currPos:currPos+7));
    currPos = currPos+8;

    % 2. Group ID (2 octets)
    cfg.GroupIDFrom = dec2hex(bit2int(zclPayloadBin(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    % 3. Scene ID (1 octet)
    cfg.SceneIDFrom = dec2hex(bit2int(zclPayloadBin(currPos:currPos+7)', 8, false), 2);

end

function cfg = decodeTimeNameExtField(cfg, zclPayloadBin, currPos)

 % 3. Transition time (2 octets)
  cfg.TransitionTime = bit2int(zclPayloadBin(currPos:currPos+15)', 16, false);
  currPos = currPos+16;

  % 4. Scene Name String length (1 octet)
  sceneNameStrLen = bit2int(zclPayloadBin(currPos:currPos+7)', 8, false);
  currPos = currPos+8;

  % 5. Scene Name (sceneNameStrLen octets)
  sceneName = zeros(1, sceneNameStrLen);
  for i = 1:sceneNameStrLen
    sceneName(i) = bit2int(zclPayloadBin(currPos:currPos+7)', 8, false);
    currPos = currPos+8;
  end
  cfg.SceneName = char(sceneName);

  % 6. Extension field sets
  cfg = decodeExtFieldSets(cfg, zclPayloadBin(currPos:end));


function cfg = decodeExtFieldSets(cfg, extFieldSet)

currPos = 1;

% Creating a structure with default values.(ID 'ffff' is not assigned to any cluster).  
ExtensionFieldSets = struct('ClusterID', 'ffff', ...
                        'Length', 0, ...
                        'ExtensionValues', '');
i = 1;

while currPos < numel(extFieldSet)
    % 1. Profile ID (2 octets)
    ExtensionFieldSets(i).ClusterID = dec2hex(bit2int(extFieldSet(currPos:currPos+15)', 16, false), 4);
    currPos = currPos+16;

    % 2. Length (1 octet)
    ExtensionFieldSets(i).Length = bit2int(extFieldSet(currPos:currPos+7)', 8, false);
    currPos = currPos+8;

    ExtensionFieldSets(i).Length;
    if (ExtensionFieldSets(i).Length > 0)
      % 3. Extension field set (cfg.Length octets)
      ExtensionFieldSets(i).ExtensionValues = dec2hex(bit2int(extFieldSet(currPos : ...
          currPos+(ExtensionFieldSets(i).Length*8)-1)', ExtensionFieldSets(i).Length*8, false), 4);
      currPos = currPos+(ExtensionFieldSets(i).Length*8);
    end
    i = i+1;
end
if(i > 1)
  cfg.ExtensionFieldSets = ExtensionFieldSets;
end


function cfg = decodeStatus(cfg, status)
switch dec2hex(bit2int(status(:), length(status), false), 2)
  case '00'
    cfg.Status = 'Success';
  case '85'
    cfg.Status = 'Invalid field';
  case '89'
    cfg.Status = 'No space';
  case {'8B', '8b'}
    cfg.Status = 'Not found';
  otherwise
    warning(getString(message('lrwpan:ZigBee:ZCLInvalidValue', 'Status')));
end
