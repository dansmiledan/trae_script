function levelCtrlFrame = LevelControlFrameGenerator(cfg)
%LEVELCONTROLFRAMEGENERATOR Generate frames of the Level Control ZigBee cluster
% LEVELCTRLFRAME = LEVELCONTROLFRAMEGENERATOR(CFG) generates the Level control
% cluster library frame LEVELCTRLFRAME corresponding to the configuration
% object CFG.
%
% See also zigbee.LevelControlFrameConfig, zigbee.LevelControlFrameDecoder.

% Copyright 2017-2023 The MathWorks, Inc.

switch cfg.CommandType
  % Move to Level | Move to Level (with On/Off)
  case {'Move to Level', 'Move to Level (with On/Off)'}
    % 1. Level (1 octet)
    level = int2bit(cfg.Level, 8, false);

    % 2. Transition Time (2 octets)
    transitionTime = int2bit(cfg.TransitionTime, 16, false);

    % 3. Putting it all together:
    levelCtrlFrame = [level; transitionTime];

  % Move | Move with On/Off
  case {'Move', 'Move (with On/Off)'}
    % 1. Move Mode (1 octet)
    if strcmp(cfg.MoveMode, 'Up')
      moveMode = int2bit(0, 8, false);
    else % Down
      moveMode = int2bit(1, 8, false);
    end

    % 2. Rate (1 Octet)
    rate = int2bit(cfg.Rate, 8, false);

    % 3. Putting it all together:
    levelCtrlFrame = [moveMode; rate];

  % Step | Step with On/Off
  case {'Step', 'Step (with On/Off)'}
    % 1. Step Mode (1 octet)
    if strcmp(cfg.StepMode, 'Up')
      stepMode = int2bit(0, 8, false);
    else % Down
      stepMode = int2bit(1, 8, false);
    end

    % 2. Step Size (1 Octet)
    stepSize = int2bit(cfg.StepSize, 8, false);

    % 3. Transition Time (2 octets)
    transitionTime = int2bit(cfg.TransitionTime, 16, false);

    % 4. Putting it all together:
    levelCtrlFrame = [stepMode; stepSize; transitionTime];

  % Stop | Stop with On/Off
  case {'Stop', 'Stop (with On/Off)'}
    levelCtrlFrame = [];
end

% Convert bits to bytes:
if ~isempty(levelCtrlFrame)
  levelCtrlFrame = zigbee.internal.bits2bytes(levelCtrlFrame);
end
