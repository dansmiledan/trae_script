classdef IdentifyFrameConfig < matlab.mixin.CustomDisplay
  %IDENTIFYFRAMECONFIG Configuration for frames of the Identify ZigBee cluster
  % FRAMECONFIG = IDENTIFYFRAMECONFIG creates a configuration object for
  % frames of the Identify ZigBee cluster.
  %
  % FRAMECONFIG = IDENTIFYFRAMECONFIG(Name, Value) creates a ZigBee
  % Identify Cluster frame configuration object with the specified property
  % Name set to the specified Value. You can specify additional name-value
  % pair arguments in any order as (Name1, Value1, ..., NameN, ValueN).
  %
  % IdentifyFrameConfig properties:
  %
  % CommandType       - Command type
  % IdentifyTime      - Remaining identification time (in seconds)
  % EffectIdentifier  - Identification effect
  % EffectVariant     - Variant of the identification effect
  %
  % See also zigbee.IdentifyFrameGenerator, zigbee.IdentifyFrameDecoder.
  
  % Copyright 2017-2023 The MathWorks, Inc.

properties
  %CommandType Command type
  % Specify CommandType as one of 'Identify' | 'Identify Query' |
  % 'Trigger effect' | 'Identify Query Response'. The default is 'Identify'.
  CommandType = 'Identify';

  %IdentifyTime Remaining identify time in seconds.
  % Specify IdentifyTime as a scalar, non-negative integer lesser than 2^16.
  % The default is 0. 
  IdentifyTime = 0;

  %EffectIdentifier Identification effect
  % Specify EffectIdentifier as one of 'Blink' | 'Breathe' | 'Okay' |
  % 'Channel change' | 'Finish effect' | 'Stop effect'. The default is 'Blink'.
  EffectIdentifier = 'Blink';
end

properties(Constant)
  %EffectVariant Variant of identification effect
  % As per the ZCL Specification 2016, EffectVariant must be default.
  EffectVariant = 'Default';
end

properties(Constant, Hidden)
  CommandTypeValues = {'Identify', 'Identify Query', 'Trigger effect', 'Identify Query Response'};
  EffectIdentifierValues = {'Blink', 'Breathe', 'Okay', 'Channel change', ...
                            'Finish effect', 'Stop effect'};
end

methods
  function obj = IdentifyFrameConfig(varargin)
    % Apply constructor name value pairs:
    for i = 1:2:nargin
      obj.(varargin{i}) = varargin{i+1};
    end
  end

  % For auto-completion:
  function v = set(obj, prop)
    v = obj.([prop, 'Values']);
  end

  function obj = set.CommandType(obj, value)
    obj.CommandType = validatestring(value, obj.CommandTypeValues, '', 'CommandType');
  end

  function obj = set.EffectIdentifier(obj, value)
    obj.EffectIdentifier = validatestring(value, obj.EffectIdentifierValues, '', 'EffectIdentifier');
  end

  function obj = set.IdentifyTime(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'IdentifyTime');
    obj.IdentifyTime = value;
  end
 end

methods (Access = protected)
  function groups = getPropertyGroups(obj)
    propList  = properties(obj);
    activeIdx1 = true(size(propList));

    for n = 1:numel(propList)
      if  isInactiveProperty(obj, propList{n})
        activeIdx1(n) = false;
      end
    end
    groups = matlab.mixin.util.PropertyGroup(propList(activeIdx1));
  end

  function flag = isInactiveProperty(obj, prop)
    flag = false;
    if strcmp(prop, 'IdentifyTime')
      flag = ~any(strcmp(obj.CommandType, {'Identify', 'Identify Query Response'}));
      
    elseif any(strcmp(prop, {'EffectIdentifier', 'EffectVariant'})) == 1
      flag = ~strcmp(obj.CommandType, 'Trigger effect');
    end
  end
end

end
