function identifyFrame = IdentifyFrameGenerator(cfg)
%IDENTIFYFRAMEGENERATOR Generate frames for the Identify ZigBee cluster
% IDENTIFYFRAME = IDENTIFYFRAMEGENERATOR(CFG) generates the Identify
% cluster library frame IDENTIFYFRAME corresponding to the configuration
% object CFG.
%
% See also zigbee.IdentifyFrameConfig, zigbee.IdentifyFrameDecoder.

% Copyright 2017-2023 The MathWorks, Inc.

switch cfg.CommandType
  % Identify
  case {'Identify', 'Identify Query Response'}
    % 1. Identify time (2 octets)
    identifyFrame = int2bit(cfg.IdentifyTime, 16, false);

  % Identify Query
  case 'Identify Query'
    identifyFrame = [];

  % Trigger effect
  case 'Trigger effect'
    % 1. Effect identifier (1 octet)
    effectIdentifier = effectIdentifier2bits(cfg.EffectIdentifier);

    % 2. Effect Variant (1 octet)
    % Effect variant can only be 'Default', which corresponds to a 0 value
    effectVarient = int2bit(0, 8, false);

    % 3. Putting it all together
    identifyFrame = [effectIdentifier; effectVarient];
end
% Convert bits to bytes:
if ~isempty(identifyFrame)
  identifyFrame = zigbee.internal.bits2bytes(identifyFrame);
end

function effectIdentifier = effectIdentifier2bits(effectIdentifier)
switch effectIdentifier
  case 'Blink'
    id = '00';
  case 'Breathe'
    id = '01';
  case 'Okay'
    id = '02';
  case 'Channel change'
    id = '0B';
  case 'Finish effect'
    id = 'FE';
  case 'Stop effect'
    id = 'FF';
end
effectIdentifier = int2bit(hex2dec(id), 8, false);
