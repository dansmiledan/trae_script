function commandName = commandName(commandID, frameType, varargin)
%COMMANDID Get the ZigBee command name corresponding to a hex ID

% Copyright 2017-2023 The MathWorks, Inc.

 if strcmp(frameType, 'Library-wide')
    commandName = decodeProfileWideCommandID(commandID);
  else
    clusterID = varargin{1};
    direction = varargin{2};
    commandName = decodeClusterSpecificCommandID(dec2hex(commandID, 2), clusterID, direction);
 end
  
function commandType = decodeProfileWideCommandID(commandID)

  commands = {'Read Attributes', ...
    'Read Attributes Response', ...
    'Write Attributes', ...
    'Write Attributes Undivided', ...
    'Write Attributes Response', ...
    'Write Attributes No Response', ...
    'Configure Reporting', ...
    'Configure Reporting Response', ...
    'Read Reporting Configuration', ...
    'Read Reporting Configuration Response', ...
    'Report Attributes', ...
    'Default Response', ...
    'Discover Attributes', ...
    'Discover Attributes Response', ...
    'Read Attributes Structured', ...
    'Write Attributes Structured', ...
    'Write Attributes Structured Response', ...
    'Discover Commands Received', ...
    'Discover Commands Received Response', ...
    'Discover Commands Generated', ...
    'Discover Commands Generated Response', ...
    'Discover Attributes Extended', ...
    'Discover Attributes Extended Response', ...
    };
  if commandID <= length(commands)
    commandType = commands{1+commandID};
  else
    warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
  end


function commandType = decodeClusterSpecificCommandID(commandID, clusterID, direction)

  if strcmp(clusterID, '0000') % 'Basic' cluster
    if strcmp(commandID, '00')
      commandType = 'Reset to Factory Defaults';
    else
      warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0006') % 'On-off' cluster
    switch commandID
      case '00'
        commandType = 'Off';
      case '01'
        commandType = 'On';
      case '02'
        commandType = 'Toggle';
      case '40'
        commandType = 'Off with effect';
      case '41'
        commandType = 'On with recall global scene';
      case '42'
        commandType = 'On with timed off';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0500') % Intruder Alarm System (IAS) Zone cluster
    switch commandID
      case '00'
        commandType = 'Zone Status Change Notification';
      case '01'
        commandType = 'Zone Enroll Request';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0502') % Intruder Alarm System (IAS) Warning Device cluster
    switch commandID
      case '00'
        commandType = 'Start warning';
      case '01'
        commandType = 'Squawk';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0015') % Commissioning cluster
    switch commandID
      case '00'
        if strcmp(direction, 'Uplink')
          commandType = 'Restart Device';
        else % Downlink
          commandType = 'Restart Device Response';
        end
      case '01'
        if strcmp(direction, 'Uplink')
          commandType = 'Save Startup Parameters';
        else % Downlink
          commandType = 'Save Startup Parameters Response';
        end
      case '02'
        if strcmp(direction, 'Uplink')
          commandType = 'Restore Startup Parameters';
        else % Downlink
          commandType = 'Restore Startup Parameters Response';
        end
      case '03'
        if strcmp(direction, 'Uplink')
          commandType = 'Reset Startup Parameters';
        else % Downlink
          commandType = 'Reset Startup Parameters Response';
        end
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0300') % Color control cluster
    switch lower(commandID)
      case '00'
        commandType = 'Move to Hue';
      case '01'
        commandType = 'Move Hue';
      case '02'
        commandType = 'Step Hue';
      case '03'
        commandType = 'Move to Saturation';
      case '04'
        commandType = 'Move Saturation';
      case '05'
        commandType = 'Step Saturation';
      case '06'
        commandType = 'Move to Hue and Saturation';
      case '07'
        commandType = 'Move to Color';
      case '08'
        commandType = 'Move Color';
      case '09'
        commandType = 'Step Color';
      case '0a'
        commandType = 'Move to Color Temperature';
      case '40'
        commandType = 'Enhanced Move to Hue';
      case '41'
        commandType = 'Enhanced Move Hue';
      case '42'
        commandType = 'Enhanced Step Hue';
      case '43'
        commandType = 'Enhanced Move to Hue and Saturation';
      case '44'
        commandType = 'Color Loop Set';
      case '47'
        commandType = 'Stop Move Step';
      case '4b'
        commandType = 'Move Color Temperature';
      case '4c'
        commandType = 'Step Color Temperature';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0004') % Group cluster
    switch commandID
      case '00'
        if strcmp(direction, 'Uplink')
          commandType = 'Add group';
        else % Downlink
          commandType = 'Add group response';
        end
      case '01'
        if strcmp(direction, 'Uplink')
          commandType = 'View group';
        else % Downlink
          commandType = 'View group response';
        end
      case '02'
        if strcmp(direction, 'Uplink')
          commandType = 'Get group membership';
        else % Downlink
          commandType = 'Get group membership response';
        end
      case '03'
        if strcmp(direction, 'Uplink')
          commandType = 'Remove group';
        else % Downlink
          commandType = 'Remove group response';
        end
      case '04'
        commandType = 'Remove all groups';
      case '05'
        commandType = 'Add group if identifying';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0003') % Identify cluster
    switch commandID
      case '00'
        if strcmp(direction, 'Uplink')
          commandType = 'Identify';
        else % Downlink
          commandType = 'Identify Query Response';
        end
      case '01'
        commandType = 'Identify Query';
      case '40'
        commandType = 'Trigger effect';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0008') % Level Control cluster
    switch commandID
      case '00'
        commandType = 'Move to Level';
      case '01'
        commandType = 'Move';
      case '02'
        commandType = 'Step';
      case '03'
        commandType = 'Stop';
      case '04'
        commandType = 'Move to Level with OnOff';
      case '05'
        commandType = 'Move with OnOff';
      case '06'
        commandType = 'Step with OnOff';
      case '07'
        commandType = 'Stop with OnOff';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0005') % Scenes cluster
    switch commandID
      case '00'
        if strcmp(direction, 'Uplink')
          commandType = 'Add Scene';
        else % Downlink
          commandType = 'Add Scene Response';
        end
      case '01'
        if strcmp(direction, 'Uplink')
          commandType = 'View Scene';
        else % Downlink
          commandType = 'View Scene Response';
        end
      case '02'
        if strcmp(direction, 'Uplink')
          commandType = 'Remove Scene';
        else % Downlink
          commandType = 'Remove Scene Response';
        end
      case '03'
        if strcmp(direction, 'Uplink')
          commandType = 'Remove All Scenes';
        else % Downlink
          commandType = 'Remove All Scenes Response';
        end
      case '04'
        if strcmp(direction, 'Uplink')
          commandType = 'Store Scene';
        else % Downlink
          commandType = 'Store Scene Response';
        end
      case '05'
        commandType = 'Recall Scene';
      case '06'
        if strcmp(direction, 'Uplink')
          commandType = 'Get Scene Membership';
        else % Downlink
          commandType = 'Get Scene Membership Response';
        end
      case '40'
        if strcmp(direction, 'Uplink')
          commandType = 'Enhanced Add Scene';
        else % Downlink
          commandType = 'Enhanced Add Scene Response';
        end
      case '41'
        if strcmp(direction, 'Uplink')
          commandType = 'Enhanced View Scene';
        else % Downlink
          commandType = 'Enhanced View Scene Response';
        end
      case '42'
        if strcmp(direction, 'Uplink')
          commandType = 'Copy Scene';
        else % Downlink
          commandType = 'Copy Scene Response';
        end
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '1000') % ZLL Commissioning cluster
    switch commandID
      case '00'
        commandType = 'Scan request';
      case '02'
        commandType = 'Device information request';
      case '06'
        commandType = 'Identify request';
      case '07'
        commandType = 'Reset to factory new request';
      case '10'
        commandType = 'Network start request';
      case '12'
        commandType = 'Network join router request';
      case '14'
        commandType = 'Network join end device request';
      case '16'
        commandType = 'Network update request';
      case '41'
        if strcmp(direction, 'Uplink')
          commandType = 'Get group identifiers request';
        else % Downlink
          commandType = 'Get group identifiers response';
        end
      case '42'
        if strcmp(direction, 'Uplink')
          commandType = 'Get endpoint list request';
        else % Downlink
          commandType = 'Get endpoint list response';
        end
      case '01'
        commandType = 'Scan response';
      case '03'
        commandType = 'Device information response';
      case '11'
        commandType = 'Network start response';
      case '13'
        commandType = 'Network join router response';
      case '15'
        commandType = 'Network join end device response';
      case '40'
        commandType = 'Endpoint information';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0701')  % Smart Energy - Demand Response and Load Control Cluster
    switch commandID
      case '00'
        if strcmp(direction, 'Uplink')
          commandType = 'Report Event Status';
        elseif strcmp(direction, 'Downlink')
          commandType = 'Load Control Event';
        end
      case '01'
        if strcmp(direction, 'Uplink')
          commandType = 'Get Scheduled Events';
        elseif strcmp(direction, 'Downlink')
          commandType = 'Cancel Load Control Event';
        end
      case '02'
        commandType = 'Cancel All Load Control Events';
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end
  
  elseif strcmp(clusterID, '0706')  % Smart Energy - Energy Management Cluster
    switch commandID
      case '00'
        if strcmp(direction, 'Uplink')
          commandType = 'Manage Event';
        elseif strcmp(direction, 'Downlink')
          commandType = 'Report Event Status';
        end
      otherwise
        warning(getString(message('lrwpan:ZigBee:InvalidCommandID')));
    end

  elseif strcmp(clusterID, '0703')% Messaging cluster
    switch commandID
      case '00'
        if strcmp (direction, 'Uplink')
          commandType = 'Get Last Message';
        else
          commandType = 'Display Message';
        end
      case '01'
        if strcmp (direction, 'Uplink')
          commandType = 'Message Confirmation';
        else
          commandType = 'Cancel Message';
        end
    end
    
  elseif strcmp(clusterID, '0700') % Price cluster
    
    switch commandID
      case '00'
        if strcmp (direction, 'Uplink')
          commandType = 'Get Current Price';
        else
          commandType = 'Publish Price';
        end
      case '02'
        commandType = 'Price Acknowledgment';
    end
  
  end



