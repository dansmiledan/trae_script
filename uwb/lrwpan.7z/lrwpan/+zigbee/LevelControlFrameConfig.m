classdef LevelControlFrameConfig < matlab.mixin.CustomDisplay
%LEVELCONTROLFRAMECONFIG Configuration for frames of the Level Control ZigBee cluster
% FRAMECONFIG = LEVELCONTROLFRAMECONFIG creates a configuration object for
% frames of the Level Control ZigBee cluster.
%
% FRAMECONFIG = LEVELCONTROLFRAMECONFIG(Name, Value) creates a ZigBee
% Level Control Cluster frame configuration object with the specified property
% Name set to the specified Value. You can specify additional name-value
% pair arguments in any order as (Name1, Value1, ..., NameN, ValueN).
%
% LevelControlFrameConfig properties:
%
% CommandType     - Command type
% Level           - Current level
% StepMode        - Step mode
% StepSize        - Amount of level change
% TransitionTime  - Time to perform step
% MoveMode        - Move mode
% Rate            - Rate of movement
%
% See also zigbee.LevelControlFrameGenerator, zigbee.LevelControlFrameDecoder.

% Copyright 2017-2023 The MathWorks, Inc.

properties
  %CommandType Command type
  % Specify CommandType as one of  'Move to Level' | 'Move' | 'Step' |
  % 'Stop' | 'Move to Level (with On/Off)' | 'Move (with On/Off)' |
  % 'Step (with On/Off)' | 'Stop (with On/Off)'. The default is 'Move to Level'.
  CommandType = 'Move to Level';

  %Level Current level
  % Specify Level as a scalar non-negative integer lesser than 256. The
  % default is 0.
  Level = 0;
  
  %StepMode Step mode
  % Specify StepMode as one of  'Up' | 'Down' . The default is 'Up'.
  StepMode = 'Up';

  %StepSize Amount of level change
  % Specify StepSize as a scalar non-negative integer lesser than 256. The
  % default is 1.
  StepSize = 1;
  
  %TransitionTime Time to perform step
  % Specify TransitionTime, in deciseconds (i.e., tenths of a second), as a
  % scalar non-negative integer lesser than 2^16. The default is 0.
  TransitionTime = 0;

  %MoveMode Move mode
  % Specify MoveMode as one of  'Up' | 'Down' . The default is 'Up'.
  MoveMode = 'Up';

  %Rate Rate of movement
  % Specify Rate as a scalar non-negative integer lesser than 256. The
  % default is 1.
  Rate = 1;
end

properties(Constant, Hidden)
  CommandTypeValues = {'Move to Level', 'Move', 'Step', 'Stop', ...
    'Move to Level (with On/Off)', 'Move (with On/Off)', 'Step (with On/Off)', 'Stop (with On/Off)'};
  MoveModeValues = {'Up', 'Down'};
  StepModeValues = {'Up', 'Down'};
end

methods
  function obj = LevelControlFrameConfig(varargin)
    % Apply constructor name value pairs:
    for i = 1:2:nargin
      obj.(varargin{i}) = varargin{i+1};
    end
  end

  % For auto-completion:
  function v = set(obj, prop)
    v = obj.([prop, 'Values']);
  end

  function obj = set.CommandType(obj, value)
    obj.CommandType = validatestring(value, obj.CommandTypeValues, '', 'CommandType');
  end

  function obj = set.StepMode(obj, value)
    obj.StepMode = validatestring(value, obj.StepModeValues, '', 'StepMode');
  end

  function obj = set.StepSize(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 256}, '', 'StepSize');
    obj.StepSize = value;
  end

  function obj = set.Level(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 256}, '', 'Level');
    obj.Level = value;
  end

  function obj = set.TransitionTime(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'TransitionTime');
    obj.TransitionTime = value;
  end

  function obj = set.MoveMode(obj, value)
    obj.MoveMode = validatestring(value, obj.MoveModeValues, '', 'MoveMode');
  end

  function obj = set.Rate(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 256}, '', 'Rate');
    obj.Rate = value;
  end
end

methods (Access = protected)
  function groups = getPropertyGroups(obj)
    propList  = properties(obj);
    activeIdx1 = true(size(propList));

    for n = 1:numel(propList)
      if  isInactiveProperty(obj, propList{n})
        activeIdx1(n) = false;
      end
    end
    groups = matlab.mixin.util.PropertyGroup(propList(activeIdx1));
  end

  function flag = isInactiveProperty(obj, prop)
    flag = false;
    if strcmp(prop, 'Level')
      flag = ~any(strcmp(obj.CommandType, {'Move to Level', 'Move to Level (with On/Off)'}));
      
    elseif strcmp(prop, 'TransitionTime')
      flag = ~any(strcmp(obj.CommandType, {'Move to Level', 'Move to Level (with On/Off)', ...
                                           'Step',          'Step (with On/Off)'}));
                                    
    elseif any(strcmp(prop, {'MoveMode', 'Rate'}))
      flag = ~any(strcmp(obj.CommandType, {'Move', 'Move (with On/Off)'}));
      
    elseif any(strcmp(prop, {'StepMode', 'StepSize'}))
      flag = ~any(strcmp(obj.CommandType, {'Step', 'Step (with On/Off)'}));
    end
  end
end

end
