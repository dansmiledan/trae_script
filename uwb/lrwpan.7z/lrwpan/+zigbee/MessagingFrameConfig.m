classdef MessagingFrameConfig < matlab.mixin.CustomDisplay
  % MessagingFrameConfig Configuration for ZigBee Smart Energy frames of the Messaging Cluster
  %   FRAMECONFIG = zigbee.MessagingFrameConfig creates a configuration
  %   object for frames of the ZigBee Smart Energy Messaging cluster.
  %
  %   FRAMECONFIG = MessagingFrameConfig(Name,Value) creates a
  %   configuration object for frames of the ZigBee Smart Energy Messaging
  %   cluster with the specified Name set to the specified Value. You can
  %   specify additional name-value pair arguments in any order as
  %   (Name1,Value1,...,NameN,ValueN).
  %
  %   MessagingFrameConfig properties:
  %
  %   CommandType         - Name of cluster command
  %   MessageID           - 32-bit numeric scalar identifier
  %   TransmissionType    - Message transmission type
  %   Priority            - Message priority
  %   MessageConfirmation - Option to request message confirmation  
  %   Duration            - Duration of message display
  %   Message             - Message string
  %   ConfirmationTime    - UTC time of user confirmation of message
  %
  %   See also zigbee.MessagingFrameGenerator, zigbee.MessagingFrameDecoder.
  
  %   Copyright 2017-2023 The MathWorks, Inc.
  
  properties
    %CommandType Name of cluster command
    % Specify the name of the cluster command as one of 'Display Message' |
    % 'Cancel Message' | 'Get Last Message' | 'Message Confirmation'.
    % The default is 'Display Message'.
    CommandType = 'Display Message';
    
    %MessageID 32-bit numeric scalar identifier
    % Specify MessageID as a scalar non-negative real integer that is
    % not greater than 4294967296. 
    % The default is 0.
    MessageID = 0;
    
    %TransmissionType Message transmission type
    % Specify TransmissionType as one of 'Normal Transmission Only' |
    % 'Normal and Inter-PAN Transmission' | 'Inter-PAN Transmission Only'
    % The default is 'Normal Transmission Only'.
    TransmissionType = 'Normal Transmission Only';
    
    %Priority Message priority
    % Specify Priority as one of 'Low' | 'Medium' | 'High' | 'Critical'
    % The default is 'Low'.
    Priority = 'Low';
      
    %MessageConfirmation Option to request message confirmation
    % Specify MessageConfirmation as a logical scalar. If true, the
    % message originator requests a confirmation of receipt. The default is
    % false.
    MessageConfirmation = false;
    
    %Duration Duration of message display
    % Specify Duration as a scalar non-negative real integer denoting the
    % number of minutes that the message is displayed. The default is 0.
    Duration = 0;    
        
    %Message Message string
    % Specify Message as a character array encoded in a UTF-8 format. The
    % default is the empty string.
    Message = '';       
    
    %ConfirmationTime UTC time of user confirmation of message
    % Specify ConfirmationTime as a scalar non-negative real integer
    % containing number of seconds since 00:00:00 on 1-1-2000. The default
    % is 0.
    ConfirmationTime = 0;
  end
  
  properties (Constant)
    %StartTime The time at which the message becomes valid
    % StartTime is a UTC Time data type that specifies when a particular
    % message is valid. A StartTime of 0 is a special value in the ZigBee
    % standard denoting 'now'.
    StartTime = 0;
  end
  
  properties(Constant, Hidden)
    TransmissionTypeValues = {'Normal Transmission Only', 'Normal and Inter-PAN Transmission', ...
      'Inter-PAN Transmission Only'};
    PriorityValues     = {'Low', 'Medium', 'High', 'Critical'};
    CommandTypeValues      = {'Display Message', 'Cancel Message', 'Get Last Message', ...
      'Message Confirmation'};
  end
  
  methods    
    function obj = MessagingFrameConfig(varargin)
      % Apply constructor name value pairs:
      for i = 1:2:nargin
        obj.(varargin{i}) = varargin{i+1};
      end
    end
    
    % For auto-completion:
    function v = set(obj, prop)
      v = obj.([prop, 'Values']);
    end
    
    function obj = set.CommandType(obj, value)
      obj.CommandType = validatestring(value, obj.CommandTypeValues, '', 'CommandType');
    end
        
    function obj = set.MessageID(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 4294967296}, '', 'MessageID');
      obj.MessageID = value;
    end
    
    function obj = set.TransmissionType(obj, value)
      obj.TransmissionType = validatestring(value, obj.TransmissionTypeValues, '', 'TransmissionType');
    end
    
    function obj = set.Priority(obj, value)
      obj.Priority = validatestring(value, obj.PriorityValues, '', 'Priority');
    end
        
    function obj = set.MessageConfirmation(obj, value)
      validateattributes(value, {'logical'}, {'scalar'}, '', 'MessageConfirmation');
      obj.MessageConfirmation = value;
    end
    
    function obj = set.Duration(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 65536}, '', 'Duration');
      obj.Duration = value;
    end
    
    function obj = set.Message(obj, value)
      value = convertStringsToChars(value);
      validateattributes(value, {'char'}, {'row'}, '', 'Message');
      obj.Message = value;
    end    
       
    function obj = set.ConfirmationTime(obj, value)
      validateattributes(value, {'numeric'}, {'scalar', 'integer', 'nonnegative', 'real', '<', 4294967296}, '', 'ConfirmationTime');
      obj.ConfirmationTime = value;
    end    
  end
  
  methods (Access=protected)    
    
    function groups = getPropertyGroups(obj)
      
      propList1  = properties(obj);
      activeIdx1 = true(size(propList1));
      
      for n = 1:numel(propList1)
        if isInactiveProperty(obj, propList1{n})
          activeIdx1(n) = false;
        end
      end
      groups = matlab.mixin.util.PropertyGroup(propList1(activeIdx1));
    end
    
    function flag = isInactiveProperty(obj, prop)
      % Controls the conditional display of properties
      
      flag = false;
      
      if strcmp(prop, 'MessageID')
        flag = strcmp(obj.CommandType, 'Get Last Message');
        
      elseif strcmp(prop, 'Message')
        flag = ~strcmp(obj.CommandType, 'Display Message');
        
      elseif any(strcmp(prop, {'TransmissionType', 'Priority', 'MessageConfirmation'}))
        flag = ~any(strcmp(obj.CommandType, {'Display Message', 'Cancel Message'}));
        
      elseif strcmp(prop, 'Duration')
        flag = ~strcmp(obj.CommandType, 'Display Message');
        
      elseif strcmp(prop, 'ConfirmationTime')
        flag = ~strcmp(obj.CommandType, 'Message Confirmation');
        
      elseif strcmp(prop, 'StartTime')
        flag = true;
      end
    end
  end  
  
end
