classdef IASZoneFrameConfig
  %IASZoneFrameConfig Configuration for Intruder Alarm System Zone cluster library frames
  %   FRAMECONFIG = IASZoneFrameConfig creates a configuration object for
  %   frames of the Intruder Alarm System Zone cluster library.
  %
  %   FRAMECONFIG = IASZoneFrameConfig(Name,Value) creates a ZigBee Cluster frame
  %   configuration object with the specified property Name set to the
  %   specified Value. You can specify additional name-value pair arguments
  %   in any order as (Name1,Value1,...,NameN,ValueN).
  %
  %   IASZoneFrameConfig properties:
  %
  %   FrameType               - Type of command frame
  %   ManufacturerCommand     - Manufacturer specific extension
  %   Direction               - Client/server direction
  %   DisableDefaultResponse  - Option to disable default response
  %   ManufacturerCode        - Manufacturer code for proprietary extensions
  %   SequenceNumber          - Transaction sequence number
  %   CommandType             - Command type
  %
  %   See also zigbee.IASZoneFrameGenerator, zigbee.IASZoneFrameDecoder.

  %   Copyright 2017-2023 The MathWorks, Inc.

  properties (Constant)
    %CommandType Command type    
    % This configuration object only supports 'Zone Status Change
    % Notification' commands.
    CommandType = 'Zone Status Change Notification';
  end
  properties
    %ZoneID Index of zone
    % Specify ZoneID as a scalar non-negative integer. The default
    % is 0.
    ZoneID = 0;
  
    %Alarm1 First Alarm
    % Specify Alarm1 as one of 'Alarmed' | 'Nor alarmed'. The default is
    % 'Not alarmed'.
    Alarm1 = 'Not alarmed'
    
    %Alarm2 Second Alarm
    % Specify Alarm2 as one of 'Alarmed' | 'Nor alarmed'. The default is
    % 'Not alarmed'.
    Alarm2 = 'Not alarmed'
    
    %Tampered Tampered indication
    % Specify Tampered as a logical scalar. The default is false.
    Tampered = false
    
    %LowBattery Low battery indication
    % Specify LowBattery as a logical scalar. The default is false.
    LowBattery = false
    
    %PeriodicReports Periodic issuance of Zone Status Change Notification commands
    % Specify PeriodicReports as a logical scalar. If true, the Zone issues
    % periodic Zone Status Change Notification commands. The default is false.
    PeriodicReports = false
    
    %RestoreReports Notification that alarm is no longer present
    % Specify RestoreReports as a logical scalar. If true, a Zone Status
    % Change Notification command will be sent to indicate that an alarm is
    % no longer present. The default is false.
    RestoreReports = false
    
    %Trouble Trouble/failure indication
    % Specify Trouble as a logical scalar. The default is false.
    Trouble = false
    
    %ACFault AC failure indication
    % Specify ACFault as a logical scalar. The default is false.
    ACFault = false
    
    %BatteryDefect Detection of defective battery
    % Specify BatteryDefect as a logical scalar. If true, the sensor
    % detected a defective battery; otherwise the battery is functioning
    % normally. The default is false.
    BatteryDefect = false
    
    %TestMode Operation in test mode
    % Specify TestMode as a logical scalar. If true, the sensor is in test
    % mode; otherwise it is in operational mode. The default is false.
    TestMode = false
    
    %Delay Number of quarter seconds between change and transmission
    % Specify Delay as a scalar non-negative integer. This value indicates
    % the time (in quarter seconds) between the moment a change takes place
    % and the transmission of a Zone Status Change Notification. The
    % default is 0.
    Delay = 0;
end

properties(Constant, Hidden)
  Alarm1TypeValues = {'Alarmed', 'Not alarmed'}
  Alarm2TypeValues = {'Alarmed', 'Not alarmed'}
end

methods
  function obj = IASZoneFrameConfig(varargin)
    % Apply constructor name value pairs:
    for i = 1:2:nargin
        obj.(varargin{i}) = varargin{i+1};
    end
  end

  % For auto-completion:
  function v = set(obj, prop)
    v = obj.([prop, 'Values']);
  end

  function obj = set.ZoneID(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'real', 'integer', 'nonnegative'}, '', 'ZoneID');
    obj.ZoneID = value;
  end
  
  function obj = set.Delay(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'real', 'integer', 'nonnegative'}, '', 'Delay');
    obj.Delay = value;
  end
  
  function obj = set.Tampered(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'Tampered');
    obj.Tampered = value;
  end
  
  function obj = set.LowBattery(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'LowBattery');
    obj.LowBattery = value;
  end
  
  function obj = set.PeriodicReports(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'PeriodicReports');
    obj.PeriodicReports = value;
  end
  
  function obj = set.RestoreReports(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'RestoreReports');
    obj.RestoreReports = value;
  end
  
  function obj = set.Trouble(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'Trouble');
    obj.Trouble = value;
  end
  
  function obj = set.ACFault(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'ACFault');
    obj.ACFault = value;
  end
  
  function obj = set.BatteryDefect(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'BatteryDefect');
    obj.BatteryDefect = value;
  end
  
  function obj = set.TestMode(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'TestMode');
    obj.TestMode = value;
  end

end

end

