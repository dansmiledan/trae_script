classdef ZCLFrameConfig < matlab.mixin.CustomDisplay 
  %ZCLFrameConfig Configuration for ZigBee Cluster Library frames
  %   FRAMECONFIG = ZCLFrameConfig creates a configuration object for
  %   ZigBee Cluster Library frames.
  %
  %   FRAMECONFIG = ZCLFrameConfig(Name,Value) creates a ZigBee Cluster frame
  %   configuration object with the specified property Name set to the
  %   specified Value. You can specify additional name-value pair arguments
  %   in any order as (Name1,Value1,...,NameN,ValueN).
  %
  %   ZCLFrameConfig properties:
  %
  %   FrameType               - Type of command frame
  %   ManufacturerCommand     - Manufacturer specific extension
  %   Direction               - Client/server direction
  %   DisableDefaultResponse  - Option to disable default response
  %   ManufacturerCode        - Manufacturer code for proprietary extensions
  %   SequenceNumber          - Transaction sequence number
  %   CommandType             - Command type
  %
  %   See also zigbee.ZCLFrameGenerator, zigbee.ZCLFrameDecoder.

  %   Copyright 2017-2023 The MathWorks, Inc.

  properties
    %FrameType Command type
    % Specify the type of cluster command as one of 'Library-wide' |
    % 'Cluster-specific'. Library-wide commands are common for all clusters
    % including manufacturer-specific clusters. The default is 'Library-wide'.
    FrameType = 'Library-wide';
  
    %ManufacturerCommand Manufacturer-specific command
    % Specify ManufacturerCommand as a scalar logical. A true value
    % indicates that this command refers to a manufacturer specific
    % extension. The default is false.
    ManufacturerCommand = false;
  
    %Direction Transmission direction.
    % Specify the transmission direction as 'Uplink' or 'Downlink'.
    % 'Uplink' denotes the client-to-server direction and 'Downlink'
    % denotes the server-to-client direction. The default is 'Uplink'.
    Direction = 'Uplink';

    %DisableDefaultResponse Disable default response
    % Specify DisableDefaultResponse as a logical scalar. If true, the
    % default response is disabled and the default response is returned
    % only when there is an error. The default is false.
    DisableDefaultResponse = false;

    %ManufacturerCode Manufacturer code
    % Specify the ZigBee assigned manufacturer code for proprietary
    % extensions to a profile as a two-character hexadecimal string. This
    % field shall only be included in the ZCL frame if ManufacturerCommand
    % is true. The default is '00'.
    ManufacturerCode = '00';

    %SequenceNumber Frame sequence number
    % Specify SequenceNumber as a scalar non-negative real integer. This field
    % enables the response commands to match with request commands.
    SequenceNumber = 0;

    %CommandType Command type.
    % Specify CommandType as a character array. The default is 'Read
    % Attributes'.
    CommandType = 'Read Attributes';
end

properties(Constant, Hidden)
  FrameTypeValues = {'Library-wide', 'Cluster-specific'}
  DirectionValues = {'Uplink', 'Downlink'}
end

methods
  function obj = ZCLFrameConfig(varargin)
    % Apply constructor name value pairs:
    for i = 1:2:nargin
        obj.(varargin{i}) = varargin{i+1};
    end
  end

  % For auto-completion:
  function v = set(obj, prop)
    v = obj.([prop, 'Values']);
  end
  
  function obj = set.FrameType(obj, value)
    obj.FrameType = validatestring(value, obj.FrameTypeValues, '', 'FrameType');
  end

  function obj = set.ManufacturerCommand(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'ManufacturerSpecific');
    obj.ManufacturerCommand = value;
  end

  function obj = set.Direction(obj, value)
    obj.Direction = validatestring(value, obj.DirectionValues, '', 'Direction');
  end

  function obj = set.DisableDefaultResponse(obj, value)
    validateattributes(value, {'logical'}, {'scalar'}, '', 'DisableDefaultResponse');
    obj.DisableDefaultResponse = value;
  end

  function obj = set.ManufacturerCode(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'nonnegative', '<', 65536}, '', 'ManufacturerCode');
    obj.ManufacturerCode = value;
  end

  function obj = set.SequenceNumber(obj, value)
    validateattributes(value, {'numeric'}, {'scalar', 'nonnegative', '<', 256}, '', 'SequenceNumber');
    obj.SequenceNumber = value;
  end

  function obj = set.CommandType(obj, value)
    value = convertStringsToChars(value);  
    validateattributes(value, {'char'}, {'row'}, '', 'CommandType');
    obj.CommandType = value;
  end
end
  

methods (Access=protected)
  
  function groups = getPropertyGroups(obj)

    propList1  = {'FrameType'; 'CommandType'; 'SequenceNumber'; 'ManufacturerCommand'; ...
                  'Direction'; 'DisableDefaultResponse'; 'ManufacturerCode'};
    activeIdx1 = true(size(propList1));

    for n = 1:numel(propList1)
        if isInactiveProperty(obj,propList1{n})
            activeIdx1(n) = false;
        end
    end    
    groups = matlab.mixin.util.PropertyGroup(propList1(activeIdx1));
  end
  
  function flag = isInactiveProperty(obj, prop)
    flag = false;
    if strcmp(prop, 'ManufacturerCode')
      flag = ~obj.ManufacturerCommand;
    end
  end
end


end

