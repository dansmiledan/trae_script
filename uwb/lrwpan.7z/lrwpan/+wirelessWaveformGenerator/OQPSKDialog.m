classdef OQPSKDialog < wirelessWaveformGenerator.WaveformConfigurationDialog

  %   Copyright 2021-2023 The MathWorks, Inc.

  properties (Dependent)
    Band
    SamplesPerChip   % Samples per Chip
  end  	

	properties (Hidden)
    TitleString = getString(message('lrwpan:LRWPAN:OQPSKTitle'))
    configFcn = @lrwpanOQPSKConfig
    configGenFcn = @lrwpanOQPSKConfig
    configGenVar = 'cfgOQPSK';

    BandType = 'text'
    BandLabel
    BandGUI
    SamplesPerChipType = 'edit'
    SamplesPerChipLabel
    SamplesPerChipGUI
  end

  methods % constructor

    function obj = OQPSKDialog(parent)
        obj@wirelessWaveformGenerator.WaveformConfigurationDialog(parent); % call base constructor
        
        obj.SamplesPerChipGUI.(obj.Callback)      = @(a,b) spcChanged(obj, []);
    end

    function restoreDefaults(obj)
      obj.Band = '2.38/2.45 GHz';
      obj.SamplesPerChip = 4;
    end
    function setupDialog(obj)
      setupDialog@wirelessWaveformGenerator.WaveformConfigurationDialog(obj);
      generationDialog = obj.Parent.GenerationDialog;
      generationDialog.NumBits = 1016/8; % OQPSK doesn't allow inputs greater than 1016
      generationDialog.InputValue = 'randi([0, 1], 127*8, 1)';
    end

    function props = props2ExcludeFromConfig(~)
      props = {'Band'};
    end
    function props = props2ExcludeFromConfigGeneration(~)
      props = {'Band'};
    end

    function config = getConfigurationForSave(obj)
      config.waveform = obj.getConfiguration; % lrwpanHRPConfig objects do not accept workspace variables (strings)
      config.generation = getConfigurationForSave(obj.Parent.GenerationDialog); 
    end

    function sr = getSampleRate(obj)
      cfg = getConfiguration(obj);
      sr = cfg.SampleRate;
    end

    function spcChanged(obj, ~)
      try
        val = obj.SamplesPerChip;
        validateattributes(val, {'numeric'}, {'scalar', 'positive', 'real', 'even', '>=', 2}, '', 'samples per chip');
      catch e
        obj.errorFromException(e);
      end
    end

    function n = get.Band(obj) 
      n = getTextVal(obj, 'Band');
    end
    function set.Band(obj, val) 
      setTextVal(obj, 'Band', val);
    end
    function n = get.SamplesPerChip(obj) 
      n = getEditVal(obj, 'SamplesPerChip');
    end
    function set.SamplesPerChip(obj, val) 
      setEditVal(obj, 'SamplesPerChip', val);
    end
   
    function waveform = generateWaveform(obj)
      % Get bits from MAC layer:
      generationDialog = obj.Parent.GenerationDialog;
      userDefined = strcmp(generationDialog.InputSource, 'User-defined');
      if userDefined
        MPDU = generationDialog.MPDU();
      else
        MPDU = generationDialog.MPDU(generationDialog.NumBits*8); % actually bytes
        MPDU = MPDU{:};
      end
      if isempty(MPDU)
        MPDU = zeros(0, 1); % still allow generation
      end

      numFrames = generationDialog.NumFrames;
      idleTime = generationDialog.IdleTime;

      % Generate PHY waveform:
      cfg = getConfiguration(obj);
      cfg.PSDULength = generationDialog.NumBits; % actually bytes
      waveform = lrwpanWaveformGenerator(MPDU, cfg, 'NumPackets', numFrames, 'IdleTime', idleTime);
    end


    %% Buy bit source
    function c = getSourceClass(~)
      c = 'wirelessAppContainer.sources.PacketizedPSDUSourceDialog';
    end
    function cellDialogs = getDialogsPerColumn(obj)
      cellDialogs{1} = {obj obj.Parent.GenerationDialog};
    end


    %% Visualizations
    function b = timeScopeEnabled(~)
      b = false; % eye diagram is shown by default
    end
    
    function b = offersConstellation(~)
      b = true;
    end
    function b = constellationEnabled(~)
      b = true;
    end
    function b = showConstellationTrajectory(~)
      b = true;
    end
    
    function b = offersEyeDiagram(~)
      b = true;
    end
    function b = eyeEnabled(~)
      b = true;
    end
    function sps = getSamplesPerSymbol(obj) % for eye visual
      % number of samples per eye diagram symbol
      sps = obj.SamplesPerChip;
    end
    function b = trimHalfEyeSymbols(~)
      b = true;
    end

    function addConfigCode(obj, sw)
      addConfigCode@wirelessWaveformGenerator.WaveformConfigurationDialog(obj, sw);

      % Get PSDULEn from Generation Configuration Dialog
      generationDialog = obj.Parent.GenerationDialog;      

      addcr(sw, [obj.configGenVar '.PSDULength = ' num2str(generationDialog.NumBits) ';']);
      addcr(sw);
    end

    function addGenerationCode(obj, sw)
      genDialog = obj.getGenerationDialog();
      addcr(sw, ['waveform = lrwpanWaveformGenerator(in, ' obj.configGenVar ', ...']);
      addcr(sw, ['''NumPackets'', '               genDialog.NumFramesGUI.(obj.EditValue) ', ...']);
      addcr(sw, ['''IdleTime'', '                 genDialog.IdleTimeGUI.(obj.EditValue) ');']);
    end

    function addInputCode(obj, sw)
      addInputCode(obj.Parent.GenerationDialog, sw);
    end

    function str = getCatalogPrefix(~)
      str = 'lrwpan:LRWPAN:';
    end

    % Export to Simulink:
    function [blockName, maskTitleName, waveNameText] = getMaskTextWaveName(obj)
        blockName = ['ZigBee//IEEE ' obj.Parent.WaveformGenerator.pCurrentExtensionType];
        maskTitleName = ['ZigBee/IEEE ' obj.Parent.WaveformGenerator.pCurrentExtensionType ' Waveform Generator'];
        waveNameText = 'ZigBee/IEEE 802.15.4 (OQPSK)';
    end
  end
end