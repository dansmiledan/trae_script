classdef HRPUWBDialog < wirelessWaveformGenerator.WaveformConfigurationDialog
  %

  %   Copyright 2021-2023 The MathWorks, Inc.

  properties (Dependent)
    ModeHPRF
    ModeBPRF
    Mode154a
    Mode       % Hidden
    Channel
    MeanPRF
    DataRate
    PHRDataRate
    SamplesPerPulse
    STSPacketConfiguration
    NumSTSSegments
    STSSegmentLength
    ExtraSTSGapLength
    ExtraSTSGapIndex
    CodeIndex
    PreambleMeanPRF
    PreambleDuration
    SFDNumber
    Ranging
    ConstraintLength
  end  	

	properties (Hidden)
    TitleString = getString(message('lrwpan:LRWPAN:HRPUWBTitle'))
    configFcn = @lrwpanHRPConfig
    configGenFcn = @lrwpanHRPConfig
    configGenVar = 'cfgHRPUWB';

    ModeHPRFType = 'radiobutton' 
    ModeHPRFLabel
    ModeHPRFGUI
    ModeBPRFType = 'radiobutton' 
    ModeBPRFLabel
    ModeBPRFGUI
    Mode154aType = 'radiobutton' 
    Mode154aLabel
    Mode154aGUI
    ModeType = 'text' 
    ModeLabel
    ModeGUI

    ChannelType = 'popupmenu'
    ChannelDropDown = cellfun(@num2str,num2cell([0:3 5:6 8:10 12:14]),'UniformOutput',false)
    ChannelLabel
    ChannelGUI
    MeanPRFType = 'popupmenu'
    MeanPRFDropDown = {'3.9', '15.6', '62.4', '124.8', '249.6'}
    MeanPRFLabel
    MeanPRFGUI
    DataRateType = 'popupmenu'
    DataRateDropDown = {'0.11', '0.85', '1.7', '6.81', '27.24'}
    DataRateLabel
    DataRateGUI
    PHRDataRateType = 'popupmenu'
    PHRDataRateDropDown = {'0.85', '6.81'}
    PHRDataRateLabel
    PHRDataRateGUI

    SamplesPerPulseType = 'edit'
    SamplesPerPulseLabel
    SamplesPerPulseGUI
    
    STSPacketConfigurationType = 'popupmenu'
    STSPacketConfigurationDropDown = {'0', '1', '2', '3'}
    STSPacketConfigurationLabel
    STSPacketConfigurationGUI
    NumSTSSegmentsType = 'popupmenu'
    NumSTSSegmentsDropDown = {'1', '2', '3', '4'}
    NumSTSSegmentsLabel
    NumSTSSegmentsGUI
    STSSegmentLengthType = 'popupmenu'
    STSSegmentLengthDropDown = {'16' '32' '64' '128' '256'}
    STSSegmentLengthLabel
    STSSegmentLengthGUI
    ExtraSTSGapLengthType = 'edit'
    ExtraSTSGapLengthLabel
    ExtraSTSGapLengthGUI
    ExtraSTSGapIndexType = 'popupmenu'
    ExtraSTSGapIndexDropDown = {'0', '1', '2', '3'}
    ExtraSTSGapIndexLabel
    ExtraSTSGapIndexGUI
    
    CodeIndexType = 'popupmenu'
    CodeIndexDropDown = cellfun(@num2str,num2cell([1:2 9:16 21:32]),'UniformOutput',false) % default for Channel 0
    CodeIndexLabel
    CodeIndexGUI

    PreambleMeanPRFType = 'popupmenu'
    PreambleMeanPRFDropDown = {'4.03', '16.1'}
    PreambleMeanPRFLabel
    PreambleMeanPRFGUI
    PreambleDurationType = 'popupmenu'
    PreambleDurationDropDown = cellfun(@num2str,num2cell([16 24 32 48 64 96 128 256 1024 4096]),'UniformOutput',false)
    PreambleDurationLabel
    PreambleDurationGUI
    SFDNumberType = 'popupmenu'
    SFDNumberDropDown = {'0', '1', '2', '3', '4'}
    SFDNumberLabel
    SFDNumberGUI
    RangingType = 'checkbox'
    RangingLabel
    RangingGUI

    ConstraintLengthType = 'popupmenu'
    ConstraintLengthDropDown = {'3', '7'}
    ConstraintLengthLabel
    ConstraintLengthGUI

    hrpWave = [];
    generationConfig = [];
  end

  methods (Static)
    function hPropDb = getPropertySet(~)
      hPropDb = extmgr.PropertySet(...
        'Visualizations',   'mxArray', {'HRP Frame Visualization'});
    end
  end

  methods % constructor

    function obj = HRPUWBDialog(parent)
        obj@wirelessWaveformGenerator.WaveformConfigurationDialog(parent); % call base constructor
       
        % create info panel
        className = 'wirelessWaveformGenerator.HRPUWBInfoDialog';
        if ~isKey(obj.Parent.DialogsMap, className)
          obj.Parent.DialogsMap(className) = eval([className '(obj.Parent)']); %#ok<*EVLDOT> 
        end

        obj.RadioGroup.SelectionChangedFcn            = @(a, b) modeChanged(obj);        
        obj.ChannelGUI.(obj.Callback)                 = @(a, b) updateCodes(obj);
        obj.MeanPRFGUI.(obj.Callback)                 = @(a, b) meanPRFChanged(obj);
        obj.SamplesPerPulseGUI.(obj.Callback)         = @(a, b) spcChanged(obj, []);
        obj.ExtraSTSGapLengthGUI.(obj.Callback)       = @(a, b) extraSTSGapLengthChanged(obj, []);
        obj.STSPacketConfigurationGUI.(obj.Callback)  = @(a, b) updateSTS(obj);

        % info update only:
        obj.CodeIndexGUI.(obj.Callback)               = @(a, b) updateInfo(obj);
        obj.PreambleMeanPRFGUI.(obj.Callback)         = @(a, b) updateInfo(obj);
        obj.ConstraintLengthGUI.(obj.Callback)        = @(a, b) updateInfo(obj);
        obj.DataRateGUI.(obj.Callback)                = @(a, b) updateInfo(obj);
        obj.PHRDataRateGUI.(obj.Callback)             = @(a, b) updateInfo(obj);

        modeChanged(obj); % trigger initial visibilities

        % reduce some unnecessary default margin, that occupies space:
        obj.ModeHPRFGUI.Position(1) = 2;
        obj.ModeBPRFGUI.Position(1) = 2;
        obj.Mode154aGUI.Position(1) = 2;

        set([obj.ModeLabel, obj.ModeGUI], 'Visible', false); % property is only used to enable Export to M Script
    end

    function adjustSpec(obj)
      obj.LabelWidth = 145; % need more space for labels
    end

    function props = props2ExcludeFromConfig(~)
      % these properties do not exist in lrwpanHRPConfig, only 1 'Mode'
      % exists. So don't try setting these to lrwpanHRPConfig
      props = {'ModeHPRF', 'ModeBPRF', 'Mode154a'};
    end
    function props = props2ExcludeFromConfigGeneration(obj)
      % these properties do not exist in lrwpanHRPConfig, only 1 'Mode'
      % exists. So don't try setting these to lrwpanHRPConfig
      props = {'ModeHPRF', 'ModeBPRF', 'Mode154a'};
      allProps = displayOrder(obj);
      cfg = getConfiguration(obj);
      for idx = 1:numel(allProps)
        thisProp = allProps{idx};
        if ~ismember(thisProp, props)
          if isInactivePropertyPublic(cfg, thisProp)
            props = [props thisProp]; %#ok<AGROW> 
          end
      end
    end
    end

    function config = getConfigurationForSave(obj)
      config.waveform = obj.getConfiguration;  % lrwpanHRPConfig objects do not accept workspace variables (strings)
      config.generation = getConfigurationForSave(obj.Parent.GenerationDialog);
    end
    function applyConfiguration(obj, config)
      % need to update many properties after mode changed
      obj.ModeHPRF = strcmp(config.Mode, 'HPRF');
      obj.ModeBPRF = strcmp(config.Mode, 'BPRF');
      obj.Mode154a = strcmp(config.Mode, '802.15.4a');
      modeChanged(obj);
      
      % set the rest
      applyConfiguration@wirelessWaveformGenerator.WaveformConfigurationDialog(obj, config);
    end

    function restoreDefaults(obj)
      obj.ModeHPRF = true;
      obj.ModeBPRF = false;
      obj.Mode154a = false;
      modeChanged(obj);

      % same defaults with lrwpanHRPConfig
      c = lrwpanHRPConfig; 
      obj.Channel                 = c.Channel;
      obj.MeanPRF                 = c.MeanPRF;
      obj.DataRate                = c.DataRate;
      obj.PHRDataRate             = c.PHRDataRate;
      obj.SamplesPerPulse         = c.SamplesPerPulse;
      obj.STSPacketConfiguration  = c.STSPacketConfiguration;
      obj.NumSTSSegments          = c.NumSTSSegments;
      obj.ExtraSTSGapLength       = c.ExtraSTSGapLength;
      obj.ExtraSTSGapIndex        = c.ExtraSTSGapIndex;
      obj.STSSegmentLength         = c.STSSegmentLength;
      obj.CodeIndex               = c.CodeIndex;
      obj.PreambleMeanPRF         = c.PreambleMeanPRF;
      obj.PreambleDuration        = c.PreambleDuration;
      obj.SFDNumber               = c.SFDNumber;
      obj.Ranging                 = c.Ranging;
      obj.ConstraintLength        = c.ConstraintLength;
    end
    function setupDialog(obj)
      setupDialog@wirelessWaveformGenerator.WaveformConfigurationDialog(obj);
      generationDialog = obj.Parent.GenerationDialog;
      generationDialog.NumBits = 1016/8; % OQPSK doesn't allow inputs greater than 1016
      generationDialog.InputValue = 'randi([0, 1], 127*8, 1)';
    end


    function sr = getSampleRate(obj)
      cfg = getConfiguration(obj);
      sr = cfg.SampleRate;
    end

    function modeChanged(obj)
      % Mean PRF
      if obj.ModeHPRF
        obj.MeanPRFGUI.(obj.DropdownValues) = {'124.8', '249.6'};
        obj.MeanPRF = 249.6;
      elseif obj.ModeBPRF
        obj.MeanPRFGUI.(obj.DropdownValues) = {'62.4'};
      else % 15.4a
        obj.MeanPRFGUI.(obj.DropdownValues) = {'3.9', '15.6', '62.4'};
        obj.MeanPRF = 15.6;
      end
      set([obj.MeanPRFLabel obj.MeanPRFGUI], 'Visible', uiservices.logicalToOnOff(~obj.ModeBPRF));
      meanPRFChanged(obj);

      % DataRate
      updateDataRate(obj);
      set([obj.DataRateLabel obj.DataRateGUI], 'Visible', uiservices.logicalToOnOff(obj.Mode154a));

      % PHRDataRate
      set([obj.PHRDataRateLabel obj.PHRDataRateGUI], 'Visible', uiservices.logicalToOnOff(obj.ModeBPRF));

      % STS properties      
      set([obj.STSPacketConfigurationLabel obj.STSPacketConfigurationGUI], 'Visible', uiservices.logicalToOnOff(~obj.Mode154a));
      updateSTS(obj); % more visibility

      % Code index
      updateCodes(obj);

      % PreambleDuration
      if obj.ModeHPRF
        obj.PreambleDurationGUI.(obj.DropdownValues) = {'16', '24', '32', '48', '64', '96', '128', '256'};
      else
        obj.PreambleDurationGUI.(obj.DropdownValues) = {'16', '64', '1024', '4096'};
      end

      % SFD
      if obj.ModeHPRF
        obj.SFDNumberGUI.(obj.DropdownValues) = {'0', '1', '2', '3', '4'};
      elseif obj.ModeBPRF
        obj.SFDNumberGUI.(obj.DropdownValues) = {'0', '2'};
      end
      set([obj.SFDNumberLabel obj.SFDNumberGUI], 'Visible', uiservices.logicalToOnOff(~obj.Mode154a));

      % Constraint Length:
      set([obj.ConstraintLengthLabel obj.ConstraintLengthGUI], 'Visible', uiservices.logicalToOnOff(obj.ModeHPRF));

      layoutUIControls(obj);

      updateInfo(obj);
    end

    function meanPRFChanged(obj)
      % update data rate
      updateDataRate(obj);

      % Code index
      updateCodes(obj);

      % Change to MeanPRF affects PreambleMeanPRF
      updatePreambleMeanPRF(obj);
      layoutUIControls(obj);

      updateInfo(obj);
    end

    function updateDataRate(obj)
      if obj.Mode154a % dropdown is hidden otherwise
        if obj.MeanPRF == 3.9
          obj.DataRateGUI.(obj.DropdownValues) = {'0.11', '0.85', '1.7', '6.81'};
        else
          obj.DataRateGUI.(obj.DropdownValues) = {'0.11', '0.85', '6.81', '27.24'};
        end
      end
    end

    function updateSTS(obj)
      % Basic STS visibility
      visible = obj.ModeHPRF && obj.STSPacketConfiguration>0;
      set([obj.NumSTSSegmentsLabel obj.NumSTSSegmentsGUI obj.STSSegmentLengthLabel obj.STSSegmentLengthGUI], ...
           'Visible', uiservices.logicalToOnOff(visible));

      % Extra STS visibility
      visible = obj.ModeHPRF && obj.STSPacketConfiguration==2;
      set([obj.ExtraSTSGapLengthLabel obj.ExtraSTSGapLengthGUI obj.ExtraSTSGapIndexLabel obj.ExtraSTSGapIndexGUI], 'Visible', uiservices.logicalToOnOff(visible));
      layoutUIControls(obj);

      updateInfo(obj); % visibility of Segments, Length
    end

    function updateCodes(obj)
      codeInd = [];
      if obj.MeanPRF < 62.4 % MHz
        if any(obj.Channel == [0 1 8 12])
          codeInd = [1 2];
        elseif any(obj.Channel == [2 5 9 13])
          codeInd = [3 4];
        else % [3 6 10 14]
          codeInd = [5 6];
        end
      elseif obj.MeanPRF == 62.4 % MHz
        codeInd = [9:16 21:24];
      end
      if ~obj.Mode154a % HRP-ERDEV
        codeInd = [codeInd 25:32];
      end
      obj.CodeIndexGUI.(obj.DropdownValues) = cellfun(@num2str,num2cell(codeInd),'UniformOutput',false);

      updateInfo(obj);
    end

    function updatePreambleMeanPRF(obj)
      visible = obj.MeanPRF < 62.4; % MHz;
      set([obj.PreambleMeanPRFLabel obj.PreambleMeanPRFGUI], 'Visible', uiservices.logicalToOnOff(visible));
    end

    function spcChanged(obj, ~)
      try
        val = obj.SamplesPerPulse;
        validateattributes(val, {'numeric'}, {'real', 'scalar', 'integer', '>', 1}, '', 'samples per pulse');

        updateInfo(obj);
      catch e
        obj.errorFromException(e);
      end
    end
    function extraSTSGapLengthChanged(obj, ~)
      try
        val = obj.ExtraSTSGapLength;
        validateattributes(val, {'numeric'}, {'real', 'scalar', 'integer', 'nonnegative', '<=', 127}, '', 'extra STS gap length');
      catch e
        obj.errorFromException(e);
      end
    end

    function updateInfo(obj)
      infoClass = 'wirelessWaveformGenerator.HRPUWBInfoDialog';
      if ~isKey(obj.Parent.DialogsMap, infoClass)
        return;
      end
      
      infoDialog = obj.Parent.DialogsMap(infoClass);

      if obj.ModeHPRF && obj.MeanPRF == 124.8
        infoDialog.PeakPRF = 249.6;
      else
        infoDialog.PeakPRF = 499.2;
      end
      infoDialog.MeanPRF = obj.MeanPRF;

      if obj.ModeHPRF
        if obj.ConstraintLength == 3
          if obj.MeanPRF == 249.6
            infoDialog.DataRate = 27.2;
            infoDialog.PHRDataRate = 15.6;
          else % 124.8
            infoDialog.DataRate = 6.8;
            infoDialog.PHRDataRate = 3.9;
          end
        else % CL=7
          if obj.MeanPRF == 249.6
            infoDialog.DataRate = 31.2;
            infoDialog.PHRDataRate = 31.2;
          else % 124.8
            infoDialog.DataRate = 7.8;
            infoDialog.PHRDataRate = 7.8;
          end
        end
      elseif obj.ModeBPRF
        infoDialog.DataRate = 6.81;
        infoDialog.PHRDataRate = obj.PHRDataRate;

        infoDialog.NumSTSSegments = 1;
        infoDialog.STSSegmentLength = 64;
      else % 15.4a
        infoDialog.DataRate = obj.DataRate;
        infoDialog.PHRDataRate = min(0.85, obj.DataRate);
      end
      
      % STS/BPRF
      set([infoDialog.NumSTSSegmentsLabel infoDialog.NumSTSSegmentsGUI infoDialog.STSSegmentLengthLabel infoDialog.STSSegmentLengthGUI], ...
            'Visible', uiservices.logicalToOnOff(obj.ModeBPRF && obj.STSPacketConfiguration>0));
      
      try
        cfg = getConfiguration(obj);
        infoDialog.SampleRate = cfg.SampleRate/1e9;
        if obj.ModeHPRF
          infoDialog.Modulation = 'HRP-ERDEV';
        else
          infoDialog.Modulation = 'BPM-BPSK';
  
          infoDialog.BurstsPerSymbol = cfg.BurstsPerSymbol;
          infoDialog.NumHopBursts = cfg.NumHopBursts;
        end
        % BPM-BPSK properties:
        set([infoDialog.BurstsPerSymbolLabel infoDialog.BurstsPerSymbolGUI infoDialog.NumHopBurstsLabel infoDialog.NumHopBurstsGUI], ...
              'Visible', uiservices.logicalToOnOff(~obj.ModeHPRF));
  
        infoDialog.ChipsPerPreambleSymbol   = cfg.ChipsPerSymbol(1);
        infoDialog.ChipsPerPayloadSymbol    = cfg.ChipsPerSymbol(end);
  
        infoDialog.PreambleCodeLength       = cfg.PreambleCodeLength;
        infoDialog.PreambleSpreadingFactor  = cfg.PreambleSpreadingFactor;
        infoDialog.ConvolutionalCoding      = uiservices.logicalToOnOff(cfg.ConvolutionalCoding);

        set([infoDialog.ConstraintLengthLabel infoDialog.ConstraintLengthGUI], ...
            'Visible', uiservices.logicalToOnOff(cfg.ConvolutionalCoding && ~obj.ModeHPRF));
      catch
        % best effort if configuration is invalid
      end

      if ~obj.ModeHPRF
        infoDialog.ConstraintLength = 3;
      end

      layoutUIControls(infoDialog);
    end

    function m = get.Mode(obj)
      if obj.ModeHPRF
        m = 'HPRF';
      elseif obj.ModeBPRF
        m = 'BPRF';
      else
        m = '802.15.4a';
      end
    end

    function b = get.ModeHPRF(obj)
      b = getRadioVal(obj, 'ModeHPRF');
    end
    function set.ModeHPRF(obj, value) 
      setRadioVal(obj, 'ModeHPRF', value);
    end
    function b = get.ModeBPRF(obj)
      b = getRadioVal(obj, 'ModeBPRF');
    end
    function set.ModeBPRF(obj, value) 
      setRadioVal(obj, 'ModeBPRF', value);
    end
    function b = get.Mode154a(obj)
      b = getRadioVal(obj, 'Mode154a');
    end
    function set.Mode154a(obj, value) 
      setRadioVal(obj, 'Mode154a', value);
    end


    function n = get.MeanPRF(obj)
      n = getDropdownNumVal(obj, 'MeanPRF');
    end
    function set.MeanPRF(obj, val) 
      setDropdownNumVal(obj, 'MeanPRF', val);
    end
    function n = get.PreambleMeanPRF(obj)
      n = getDropdownNumVal(obj, 'PreambleMeanPRF');
    end
    function set.PreambleMeanPRF(obj, val) 
      setDropdownNumVal(obj, 'PreambleMeanPRF', val);
    end
    function n = get.DataRate(obj)
      n = getDropdownNumVal(obj, 'DataRate');
    end
    function set.DataRate(obj, val) 
      setDropdownNumVal(obj, 'DataRate', val);
    end
    function n = get.PHRDataRate(obj)
      n = getDropdownNumVal(obj, 'PHRDataRate');
    end
    function set.PHRDataRate(obj, val) 
      setDropdownNumVal(obj, 'PHRDataRate', val);
    end
    function n = get.STSSegmentLength(obj)
      n = getDropdownNumVal(obj, 'STSSegmentLength');
    end
    function set.STSSegmentLength(obj, val) 
      setDropdownNumVal(obj, 'STSSegmentLength', val);
    end


    function n = get.Channel(obj)
      n = getDropdownNumVal(obj, 'Channel');
    end
    function set.Channel(obj, val) 
      setDropdownNumVal(obj, 'Channel', val);

      updateCodes(obj);
    end
    function n = get.STSPacketConfiguration(obj)
      n = getDropdownNumVal(obj, 'STSPacketConfiguration');
    end
    function set.STSPacketConfiguration(obj, val) 
      setDropdownNumVal(obj, 'STSPacketConfiguration', val);
    end
    function n = get.NumSTSSegments(obj)
      n = getDropdownNumVal(obj, 'NumSTSSegments');
    end
    function set.NumSTSSegments(obj, val) 
      setDropdownNumVal(obj, 'NumSTSSegments', val);
    end
    function n = get.ExtraSTSGapIndex(obj)
      n = getDropdownNumVal(obj, 'ExtraSTSGapIndex');
    end
    function set.ExtraSTSGapIndex(obj, val) 
      setDropdownNumVal(obj, 'ExtraSTSGapIndex', val);
    end
    function n = get.CodeIndex(obj)
      n = getDropdownNumVal(obj, 'CodeIndex');
    end
    function set.CodeIndex(obj, val) 
      setDropdownNumVal(obj, 'CodeIndex', val);
    end
    function n = get.PreambleDuration(obj)
      n = getDropdownNumVal(obj, 'PreambleDuration');
    end
    function set.PreambleDuration(obj, val) 
      setDropdownNumVal(obj, 'PreambleDuration', val);
    end
    function n = get.SFDNumber(obj)
      n = getDropdownNumVal(obj, 'SFDNumber');
    end
    function set.SFDNumber(obj, val) 
      setDropdownNumVal(obj, 'SFDNumber', val);
    end
    function n = get.ConstraintLength(obj)
      n = getDropdownNumVal(obj, 'ConstraintLength');
    end
    function set.ConstraintLength(obj, val) 
      setDropdownNumVal(obj, 'ConstraintLength', val);
    end


    function f = get.SamplesPerPulse(obj)
      f = getEditVal(obj, 'SamplesPerPulse');
    end
    function set.SamplesPerPulse(obj, value)
      setEditVal(obj, 'SamplesPerPulse', value);
    end
    function f = get.ExtraSTSGapLength(obj)
      f = getEditVal(obj, 'ExtraSTSGapLength');
    end
    function set.ExtraSTSGapLength(obj, value)
      setEditVal(obj, 'ExtraSTSGapLength', value);
    end

    function v = get.Ranging(obj)
      v = getCheckboxVal(obj, 'Ranging');
    end
    function set.Ranging(obj, val) 
      setCheckboxVal(obj, 'Ranging', val);
    end

   
    function waveform = generateWaveform(obj)
      % Get bits from MAC layer:
      generationDialog = obj.Parent.GenerationDialog;
      userDefined = strcmp(generationDialog.InputSource, 'User-defined');
      if userDefined
        MPDU = generationDialog.MPDU();
      else
        MPDU = generationDialog.MPDU(generationDialog.NumBits*8); % actually bytes
        MPDU = MPDU{:};
      end
      if isempty(MPDU)
        MPDU = zeros(0, 1); % still allow generation
      end

      numFrames = generationDialog.NumFrames;
      idleTime = generationDialog.IdleTime;

      % Generate PHY waveform:
      cfg = getConfiguration(obj);
      cfg.PSDULength = generationDialog.NumBits; % actually bytes
      waveform = lrwpanWaveformGenerator(MPDU, cfg, 'NumPackets', numFrames, 'IdleTime', idleTime);

      % cache for HRP frame visual (custom)
      obj.hrpWave = waveform;
      obj.generationConfig = cfg;
    end

    function mask = spectralMask(~)
      peakPRF = 499.2e6;
      Fc065 = 0.65*peakPRF;
      drop065 = -10; % dB
      Fc08  =  0.8*peakPRF;
      drop08 = -18; % dB
      
      spectralMask = SpectralMaskConfiguration;
      spectralMask.EnabledMasks='Upper';
      spectralMask.ReferenceLevel = 'Spectrum peak';
      spectralMask.UpperMask = [-inf drop08; -Fc08 drop08; -Fc08 drop065; -Fc065 drop065; -Fc065 0;
                                Fc065 0; Fc065 drop065; Fc08 drop065; Fc08 drop08; inf drop08];
      mask = spectralMask;
    end
    function lim = customSpectrumYLim(~)
      lim = [-100 0];
    end

    function customVisualizations(obj, varargin)
      visual = 'HRP Frame Visualization';
      % 1. Resource grid:
      if obj.getVisualState(visual) && ~isempty(obj.hrpWave)
        fig = obj.getVisualFig(visual);
                
        lrwpanPlotFrame(obj.hrpWave, obj.generationConfig, fig);
      end
    end

    function addConfigCode(obj, sw)
      addConfigCode@wirelessWaveformGenerator.WaveformConfigurationDialog(obj, sw);

      % Get PSDULEn from Generation Configuration Dialog
      generationDialog = obj.Parent.GenerationDialog;      

      addcr(sw, [obj.configGenVar '.PSDULength = ' num2str(generationDialog.NumBits) ';']);
      addcr(sw);
    end

    function addGenerationCode(obj, sw)
      genDialog = obj.getGenerationDialog();
      addcr(sw, ['waveform = lrwpanWaveformGenerator(in, ' obj.configGenVar ', ...']);
      addcr(sw, ['''NumPackets'', '               genDialog.NumFramesGUI.(obj.EditValue) ', ...']);
      addcr(sw, ['''IdleTime'', '                 genDialog.IdleTimeGUI.(obj.EditValue) ');']);
    end

    function addInputCode(obj, sw)
      addInputCode(obj.Parent.GenerationDialog, sw);
    end

    function b = supportsSDR(~)
      % UWB has a high sample rate (>= 1 GHz), which no SDR can support
      b = false;
    end

    %% Buy bit source
    function c = getSourceClass(~)
      c = 'wirelessAppContainer.sources.PacketizedPSDUSourceDialog';
    end
    function cellDialogs = getDialogsPerColumn(obj)
      cellDialogs{1} = {obj};
      cellDialogs{2} = {obj.Parent.GenerationDialog ...
                        obj.Parent.DialogsMap('wirelessWaveformGenerator.HRPUWBInfoDialog')};
    end

    function str = getCatalogPrefix(~)
      str = 'lrwpan:LRWPAN:';
    end

    % Export to Simulink:
    function [blockName, maskTitleName, waveNameText] = getMaskTextWaveName(obj)
        blockName = ['UWB IEEE ' strrep(obj.Parent.WaveformGenerator.pCurrentExtensionType,'/','//')];
        maskTitleName = ['UWB IEEE ' obj.Parent.WaveformGenerator.pCurrentExtensionType ' Waveform Generator'];
        waveNameText = 'UWB IEEE 802.15.4a/z';
    end
  end
end
