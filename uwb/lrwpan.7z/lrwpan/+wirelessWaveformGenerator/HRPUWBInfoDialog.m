classdef HRPUWBInfoDialog < wirelessWaveformGenerator.Dialog
%

  %   Copyright 2018-2023 The MathWorks, Inc.
  
  properties (Dependent)
    Modulation
    PeakPRF
    SampleRate
    MeanPRF
    DataRate
    PHRDataRate
    
    NumSTSSegments
    STSSegmentLength
        

    BurstsPerSymbol
    NumHopBursts
    ChipsPerPreambleSymbol
    ChipsPerPayloadSymbol
    
    PreambleCodeLength
    PreambleSpreadingFactor
    ConvolutionalCoding
    ConstraintLength
  end
  
  properties (Hidden)
    TitleString = getString(message('lrwpan:LRWPAN:HRPUWBInfoTitle'))
    PeakPRFType = 'text'
    PeakPRFLabel
    PeakPRFGUI
    MeanPRFType = 'text'
    MeanPRFLabel
    MeanPRFGUI
    DataRateType = 'text'
    DataRateLabel
    DataRateGUI
    PHRDataRateType = 'text'
    PHRDataRateLabel
    PHRDataRateGUI
    SampleRateType = 'text'
    SampleRateLabel
    SampleRateGUI
    ModulationType = 'text'
    ModulationLabel
    ModulationGUI

    NumSTSSegmentsType = 'text'
    NumSTSSegmentsLabel
    NumSTSSegmentsGUI
    STSSegmentLengthType = 'text'
    STSSegmentLengthLabel
    STSSegmentLengthGUI

    BurstsPerSymbolType = 'text'
    BurstsPerSymbolLabel
    BurstsPerSymbolGUI
    NumHopBurstsType = 'text'
    NumHopBurstsLabel
    NumHopBurstsGUI
    ChipsPerPreambleSymbolType = 'text'
    ChipsPerPreambleSymbolLabel
    ChipsPerPreambleSymbolGUI
    ChipsPerPayloadSymbolType = 'text'
    ChipsPerPayloadSymbolLabel
    ChipsPerPayloadSymbolGUI
    
    PreambleCodeLengthType = 'text'
    PreambleCodeLengthLabel
    PreambleCodeLengthGUI
    PreambleSpreadingFactorType = 'text'
    PreambleSpreadingFactorLabel
    PreambleSpreadingFactorGUI

    ConvolutionalCodingType = 'text'
    ConvolutionalCodingLabel
    ConvolutionalCodingGUI
    ConstraintLengthType = 'text'
    ConstraintLengthLabel
    ConstraintLengthGUI

    configFcn = @struct
    configGenFcn = '' % no MATLAB code generation for info dialogs
    configGenVar = ''
  end
  
  methods
    function obj = HRPUWBInfoDialog(parent)
      obj@wirelessWaveformGenerator.Dialog(parent); % call base constructor

      setupDialog(obj); % layout controls
    end

    function adjustSpec(obj)
      obj.LabelWidth = 155; % need more space for labels
    end

    function adjustDialog(obj)
      % Make sure all tags are unique. Otherwise there is a conflict with
      % editable properties in Main UWB panel
      props = properties(obj);
      for idx = 1:numel(props)
        obj.([props{idx} 'GUI']).Tag = [obj.([props{idx} 'GUI']).Tag '_Info'];
      end
    end

    function restoreDefaults(obj)
      obj.PeakPRF = '';
      obj.MeanPRF = '';
      obj.DataRate = '';
      obj.PHRDataRate = '';
      obj.SampleRate = '';
      obj.Modulation = '';

      obj.NumSTSSegments = '';
      obj.STSSegmentLength = '';
  
      obj.BurstsPerSymbol = '';
      obj.NumHopBursts = '';
      obj.ChipsPerPreambleSymbol = '';
      obj.ChipsPerPayloadSymbol = '';
      
      obj.PreambleCodeLength = '';
      obj.PreambleSpreadingFactor = '';
      obj.ConvolutionalCoding = '';
      obj.ConstraintLength = '';
    end
    
    function n = get.PeakPRF(obj) 
      n = getTextNumVal(obj, 'PeakPRF');
    end
    function set.PeakPRF(obj, val) 
      setTextVal(obj, 'PeakPRF', val)
    end
    function n = get.MeanPRF(obj) 
      n = getTextNumVal(obj, 'MeanPRF');
    end
    function set.MeanPRF(obj, val) 
      setTextVal(obj, 'MeanPRF', val)
    end
    function n = get.DataRate(obj) 
      n = getTextNumVal(obj, 'DataRate');
    end
    function set.DataRate(obj, val) 
      setTextVal(obj, 'DataRate', val)
    end
    function n = get.PHRDataRate(obj) 
      n = getTextNumVal(obj, 'PHRDataRate');
    end
    function set.PHRDataRate(obj, val) 
      setTextVal(obj, 'PHRDataRate', val)
    end
    function n = get.SampleRate(obj) 
      n = getTextNumVal(obj, 'SampleRate');
    end
    function set.SampleRate(obj, val) 
      setTextVal(obj, 'SampleRate', val)
    end
    function n = get.Modulation(obj) 
      n = getTextVal(obj, 'Modulation');
    end
    function set.Modulation(obj, val) 
      setTextVal(obj, 'Modulation', val)
    end

    
    function n = get.NumSTSSegments(obj)
      n = getTextVal(obj, 'NumSTSSegments');
    end
    function set.NumSTSSegments(obj, val) 
      setTextVal(obj, 'NumSTSSegments', val)
    end
    function n = get.STSSegmentLength(obj)
      n = getTextVal(obj, 'STSSegmentLength');
    end
    function set.STSSegmentLength(obj, val) 
      setTextVal(obj, 'STSSegmentLength', val)
    end


    function n = get.BurstsPerSymbol(obj) 
      n = getTextNumVal(obj, 'BurstsPerSymbol');
    end
    function set.BurstsPerSymbol(obj, val) 
      setTextVal(obj, 'BurstsPerSymbol', val)
    end
    function n = get.NumHopBursts(obj) 
      n = getTextNumVal(obj, 'NumHopBursts');
    end
    function set.NumHopBursts(obj, val) 
      setTextVal(obj, 'NumHopBursts', val)
    end
    function n = get.ChipsPerPreambleSymbol(obj) 
      n = getTextNumVal(obj, 'ChipsPerPreambleSymbol');
    end
    function set.ChipsPerPreambleSymbol(obj, val) 
      setTextVal(obj, 'ChipsPerPreambleSymbol', val)
    end
    function n = get.ChipsPerPayloadSymbol(obj) 
      n = getTextNumVal(obj, 'ChipsPerPayloadSymbol');
    end
    function set.ChipsPerPayloadSymbol(obj, val) 
      setTextVal(obj, 'ChipsPerPayloadSymbol', val)
    end

    function n = get.PreambleCodeLength(obj) 
      n = getTextNumVal(obj, 'PreambleCodeLength');
    end
    function set.PreambleCodeLength(obj, val) 
      setTextVal(obj, 'PreambleCodeLength', val)
    end
    function n = get.PreambleSpreadingFactor(obj) 
      n = getTextNumVal(obj, 'PreambleSpreadingFactor');
    end
    function set.PreambleSpreadingFactor(obj, val) 
      setTextVal(obj, 'PreambleSpreadingFactor', val)
    end
    function n = get.ConvolutionalCoding(obj) 
      n = getTextVal(obj, 'ConvolutionalCoding');
    end
    function set.ConvolutionalCoding(obj, val) 
      setTextVal(obj, 'ConvolutionalCoding', val)
    end
    function n = get.ConstraintLength(obj) 
      n = getTextNumVal(obj, 'ConstraintLength');
    end
    function set.ConstraintLength(obj, val) 
      setTextVal(obj, 'ConstraintLength', val)
    end

    function msg = getMsgString(~, id, varargin)
	    msgID = ['lrwpan:LRWPAN:' id];
	    msg = getString(message(msgID, varargin{:}));
	  end
  end
end