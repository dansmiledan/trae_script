classdef lrwpanOQPSKConfig < comm.internal.ConfigBase
%LRWPANOQPSKCONFIG Configuration object for OQPSK IEEE 802.15.4 (ZigBee)
%   CFG = lrwpanOQPSKConfig creates a configuration object for an OQPSK IEEE
%   802.15.4/ZigBee waveform.
%
%   CFG = lrwpanOQPSKConfig(Name,Value) creates an OQPSK IEEE 802.15.4/ZigBee
%   waveform configuration object with the specified property Name set to
%   the specified Value. You can specify additional name-value pair
%   arguments in any order as (Name1,Value1,...,NameN,ValueN).
%
%   lrwpanOQPSKConfig properties:
%
%   Band            - Center frequency of operating range
%   SamplesPerChip  - Number of samples per chip
%   PSDULength      - Length of PHY service data unit (in bytes)
%   SampleRate      - Sample rate of waveform
%
%   Example:
%      % Create an OQPSK IEEE 802.15.4 waveform.
%      psdu = randi([0, 1], 127*8, 1);
%      spc = 8;
%      cfg = lrwpanOQPSKConfig(SamplesPerChip=spc, PSDULength=length(psdu)/8);
%      waveOQPSK = lrwpanWaveformGenerator(psdu, cfg);
%      eyediagram(waveOQPSK(1+spc:end-spc), 2*spc);
%
%   See also lrwpanWaveformGenerator, lrwpanHRPConfig.

%   Copyright 2022-2023 The MathWorks, Inc.
  
%#codegen

  properties
    %Band Center frequency of operating range
    % Specify band center frequency in MHz as one of 780 | 868 | 915 | 2380
    % | 2450. This property determines the operating frequency in MHz,
    % spreading factor and filtering type. The default is 2450.
    Band (1, 1) {mustBeNumeric, mustBeMember(Band, [780, 868, 915, 2380, 2450])} = 2450;
    
    %SamplesPerChip Number of samples per chip pulse
    % Specify SamplesPerChip as an even positive integer scalar. This
    % property determines the oversampling factor, i.e., how many samples
    % are used to construct a filtered OQPSK chip. The default is 4.
    SamplesPerChip (1, 1) {mustBeNumeric, mustBePositive, mustBeInteger} = 4
    
    %PSDULength Length of PHY Service Data Unit in bytes
    % Specify PSDULength in bytes, as a positive scalar integer that is no
    % greater than 127. The default is 127.
    PSDULength (1, 1) {mustBeNumeric, mustBeGreaterThanOrEqual(PSDULength, 0), ...
      mustBeLessThanOrEqual(PSDULength, 127), mustBeInteger(PSDULength)} = 127;
  end
 
  properties (Dependent, SetAccess = 'private')
    %SampleRate Sample rate of output waveform
    % SampleRate provides the sample rate of the output signal in Hz. The
    % default is 4 MHz.
    SampleRate
  end

  methods
    function obj = lrwpanOQPSKConfig(varargin)
      obj@comm.internal.ConfigBase(varargin{:}); % call base constructor
    end
    
    function obj = set.SamplesPerChip(obj, val)
      validateattributes(val, {'numeric'}, {'even'}, '', 'SamplesPerChip');
      obj.SamplesPerChip = val;
    end

    function sr = get.SampleRate(obj)
      if obj.Band == 868 % Sec. 12.2.2
        bitRate = 100e3;
      else
        bitRate = 250e3;
      end
      numSymbols = 16;
      intSymRate = bitRate/log2(numSymbols);
      if any(obj.Band == [2380 2450]) % Sec 12.2.5
        chipsPerSymbol = 32;
      else
        chipsPerSymbol = 16;
      end
      chipRate = chipsPerSymbol*intSymRate;
      iqSymRate = chipRate/2; % OQPSK mod
      sr = iqSymRate * obj.SamplesPerChip;
    end
  end
  
end

