function [wave, varargout] = lrwpanWaveformGenerator(data, cfg, varargin)
%LRWPANWAVEFORMGENERATOR Create low-rate wireless personal area waveforms
%   WAVE = LRWPANWAVEFORMGENERATOR(DATA, CFG) creates an IEEE 802.15.4
%   low-rate wireless personal area waveform. 
%   When CFG is an <a
%   href="matlab:help('lrwpanHRPConfig')">lrwpanHRPConfig</a> object, WAVE is a high rate pulse  
%   repetition frequency (HRP) ultra-wide band (UWB) IEEE 802.15.4a/z
%   waveform. The Mode property of the lrwpanHRPConfig object CFG
%   determines if WAVE is an higher pulse repetition frequency (HPRF), base
%   pulse repetition frequency (BPRF) or an IEEE 802.15.4a waveform.
%   When CFG is an <a
%   href="matlab:help('lrwpanOQPSKConfig')">lrwpanOQPSKConfig</a> object, WAVE is an OQPSK IEEE 
%   802.15.4/ZigBee waveform.
%
%   DATA is column vector of information bits to be transmitted. Each
%   packet uses CFG.PSDULength bits from DATA. If the number of bits
%   required for all generated packets exceeds the length of DATA, then the
%   contents of DATA are repeated. This allows a short pattern to be
%   entered, e.g. [1;0;0;1].
%
%   WAVE = LRWPANWAVEFORMGENERATOR(...,Name,Value) specifies
%   additional name-value pair arguments described below. When a name-value
%   pair is not specified, its default value is used.
%
%   'NumPackets'      The number of packets to generate. It must be a
%                     positive integer. The default value is 1.
%
%   'IdleTime'        The length in seconds of an idle period after each
%                     generated packet. The default value is 0 seconds.
%
%   [WAVE, SYMBOLS] = LRWPANWAVEFORMGENERATOR(DATA, CFG) also returns the
%   HRP UWB signal before pulse shaping, i.e., after modulation (symbol
%   mapping) and after the preamble insertion. The second output applies
%   only when CFG is an lrwpanHRPConfig object. SYMBOLS has NumPackets
%   columns, one for each generated packet.
%
%   Example 1: 
%     % Create an OQPSK IEEE 802.15.4 waveform.
%     psdu = randi([0, 1], 127*8, 1);
%     spc = 8;
%     cfg = lrwpanOQPSKConfig(SamplesPerChip=spc, PSDULength=length(psdu)/8);
%     waveOQPSK = lrwpanWaveformGenerator(psdu, cfg);
%     eyediagram(waveOQPSK(1+spc:end-spc), 2*spc);
%
%   Example 2:
%     % Create an HPRF IEEE 802.15.4z waveform.
%     psdu = randi([0, 1], 200*8, 1);
%     cfgHPRF = lrwpanHRPConfig(Mode='HPRF', ...    % HPRF mode
%                  MeanPRF=124.8, ...               % 16 chips per payload symbol
%                  Channel=3, ...                   % Mandatory low-band channel 
%                  CodeIndex=27, ...                % One of the 91-symbols long SYNC codes
%                  PreambleDuration=32, ...         % Number of repetitions for spread SYNC code
%                  SFDNumber=1, ...                 % Choose a 4-symbol long SFD
%                  STSPacketConfiguration=1, ...    % Enable STS before payload
%                  NumSTSSegments=2, ...            % 2 STS segments
%                  STSSegmentLength=32, ...         % Each segment is 32*512=16384 chips long
%                  ConstraintLength=7, ...          % Optional convolutional encoder, no RS coding for payload 
%                  PSDULength=100);                 % PSDULength (100 bytes) indicates that half of the bit-input (200 bytes) will be used
%     waveHPRF = lrwpanWaveformGenerator(psdu, cfgHPRF);
%     sa = spectrumAnalyzer(SampleRate=cfgHPRF.SampleRate);
%     sa(waveHPRF);
%
%   Example 3:
%     % Create a multi-frame BPRF IEEE 802.15.4z waveform.
%     psdu = randi([0, 1], 100*8, 1);
%     cfgBPRF = lrwpanHRPConfig(Mode='BPRF', ...
%                  STSPacketConfiguration=0, ...    % Turn off STS
%                  PHRDataRate=6.81, ...            % PHR at 6.81Mbps (BPRF payload always at 6.81 Mbps)
%                  CodeIndex=9, ...                 % One of the 127-symbols long SYNC codes
%                  PSDULength=length(psdu)/8);      % Each packet will use the same PSDU
%      waveBPRF = lrwpanWaveformGenerator(psdu, cfgBPRF, NumPackets=3, IdleTime=1e-4);
%      ts = timescope(SampleRate=cfgBPRF.SampleRate, TimeSpanSource="property", ...
%                    TimeSpan=length(waveBPRF)/cfgBPRF.SampleRate, YLimits=1.1*[min(waveBPRF), max(waveBPRF)]);
%      ts(waveBPRF);
%
%   Example 4:
%     % Create an IEEE 802.15.4a waveform.
%     psdu = randi([0, 1], 50*8, 1);
%     cfg4a = lrwpanHRPConfig(Mode='802.15.4a', ...
%                  MeanPRF=15.6, ...                % 8 candidate bursts
%                  DataRate=27.24, ...              % 1 chip per burst (PHR at 850 kbps max)
%                  Channel=9, CodeIndex=3, ...      % 3rd code with length 31, high-band mandatory channel
%                  PreambleMeanPRF=4.03, ...        % PreambleSpreadingFactor = 64
%                  PSDULength=100);                 % Input bits (50 bytes) will be looped, and used twice
%     wave4a = lrwpanWaveformGenerator(psdu, cfg4a);
%     sa = spectrumAnalyzer(SampleRate=cfg4a.SampleRate);
%     sa(wave4a);
%
%   Example 5:
%     % Pass an IEEE 802.15.4z HPRF waveform through a multipath UWB channel.
%     psdu = randi([0, 1], 800, 1);
%     cfgHPRF = lrwpanHRPConfig;                 
%     waveHPRF = lrwpanWaveformGenerator(psdu, cfgHPRF);
% 
%     uwbChan = uwbChannel(Environment="Open outdoor", HasLOS = true, SampleRate=cfgHPRF.SampleRate);
%     mpathHPRF = uwbChan(waveHPRF);
%     scatterplot(mpathHPRF);
%
%   See also lrwpanHRPConfig, lrwpanOQPSKConfig, uwbChannel.

%   Copyright 2021-2023 The MathWorks, Inc.

%#codegen

%% Validation:
narginchk(2,6);
validateattributes(data,{'double','int8'},{'column','binary'},'','DATA');

validateattributes(cfg, {'lrwpanHRPConfig', 'lrwpanOQPSKConfig'}, {'scalar'}, '', 'CFG')

defaults = struct('NumPackets', 1, 'IdleTime', 0);
res = comm.internal.utilities.nvParser(defaults, varargin{:});
numPackets  = res.NumPackets;
idleTime    = res.IdleTime;

validateattributes(numPackets, {'numeric'}, ...
        {'scalar', 'real', 'nonnan', 'integer', 'positive'}, mfilename, 'NumPackets');
validateattributes(idleTime, {'numeric'}, ...
        {'scalar', 'real', 'nonnan', 'nonnegative'}, mfilename, 'IdleTime');

if isa(cfg, 'lrwpanHRPConfig')
  nargoutchk(0, 2);
  % if nargout == 2
  %   symbols = zeros(0, numPackets);
  %   coder.varsize("symbols", [1e6 100],  [true false]);
  % end
else
  nargoutchk(0, 1);
end


%% Bits preparation
if cfg.PSDULength*8 * numPackets > length(data)
  K = ceil(cfg.PSDULength*8*numPackets/length(data));
  dataRep = repmat(data, K, 1);
else
  dataRep = data;
end

%% Multi-frame generation:
symbolsCell = cell(1, numPackets);
SR = cfg.SampleRate;
[waveLen, idleTimeSamp, wave] = deal(nan); % init for codegen
for idx = 1:numPackets
  currBits = dataRep(1+(idx-1)*cfg.PSDULength*8:idx*cfg.PSDULength*8);

  %% HRP/UWB
  if isa(cfg, 'lrwpanHRPConfig')
    [singlePacket, symbolsCell{idx}] = lrwpan.internal.lrwpanHRPWaveformGenerator(currBits, cfg);
  
  %% OQPSK
  else % lrwpanOQPSKConfig
    singlePacket = lrwpan.internal.lrwpanOQPSKWaveformGenerator(currBits, cfg.SamplesPerChip, cfg.Band);
  end

  if idx == 1
    waveLen = length(singlePacket);
    idleTimeSamp = round(idleTime*SR);
    numSamples = (waveLen + idleTimeSamp)*numPackets;
    wave = complex(zeros(numSamples, 1));
  end
  offset = (idx-1)*(waveLen + idleTimeSamp);
  wave(offset+1:offset+waveLen) = complex(singlePacket);
end

% convert cell to a NxNumPackets matrix. 
if isa(cfg, 'lrwpanHRPConfig') && nargout == 2
  symbols = zeros(length(symbolsCell{1}), numPackets);
  for idx = 1:numPackets
    symbols(:, idx) = symbolsCell{idx};
  end
  varargout{1} = symbols;
end