function [cfg, varargout] = MACFrameDecoder(macFrame)
%MACFRAMEDECODER Decode 802.15.4 MAC frames
%   CFG = MACFRAMEDECODER(MACFRAME) decodes the MAC frame MACFRAME
%   and outputs all decoded information to the MACFrameConfig object CFG.
%
%   [CFG, PAYLOAD] = MACFRAMEDECODER(MACFRAME) is the same as the
%   syntax above, except that it additionally outputs the MAC frame
%   payload. This syntax is allowed only for data frame types.
%
%   See also lrwpan.MACFrameConfig, lrwpan.MACFrameGenerator.

%   Copyright 2017-2023 The MathWorks, Inc.

%#codegen

  varargout{1} = [];
  
  macFrame = macFrame'; % operate horizontally, i.e., row-wise

  % 6. MAC Footer (MFR) / CRC check
  MFR = macFrame(end-2*8+1:end);      % always the last 2 octets
  MHRwPayload = macFrame(1:end-2*8);  % crc bits calculated on MHR + payload
  
  % CRC check:
  crcCfg = crcConfig(Polynomial='x16 + x12 + x5 + 1');
  % generate bits:
  crcBits = crcGenerate(MHRwPayload', crcCfg)';

  MFR2 = crcBits(end-2*8+1:end);
  
  if ~isequal(MFR, MFR2)
    % CRC check failed. MAC frame must be rejected. Output empty structures
    cfg = [];
    varargout{1} = [];
    return;
  end

  % 0. Initialize:
  cfg = lrwpan.MACFrameConfig();

  % 1. Frame Control (first two octets)
  frameControl = macFrame(1 : 2*8);
  cfg = decodeFrameControl(cfg, frameControl);
  
  % 2. Sequence Number (3rd octet)
  cfg.SequenceNumber = bit2int(macFrame(1+2*8 : 3*8)', 8, false);
  
  % 3. Addressing fields  
  [cfg, cnt] = decodeAddressingFields(cfg, macFrame);
  
  % 4. Auxiliary security header
  if cfg.Security
    [cfg, cnt] = decodeSecurityHeader(cfg, macFrame, cnt);
  end
  
  % 5. MAC payload
  macPayload = macFrame(cnt:end-2*8); % last 2 octets are MFR
  if ~strcmp(cfg.FrameType, 'Data')
    cfg = decodeMACPayload(cfg, macPayload);
  else
    [cfg, dataPayload] = decodeMACPayload(cfg, macPayload);
    dataPayload = dec2hex(bit2int(dataPayload(:), 8, false));
    varargout{1} = dataPayload;
  end
  
end

function cfg = decodeFrameControl(cfg, frameControl)

  % 1. Frame type
  switch bit2int(frameControl(1:3)', 3, false)
    case 0
      cfg.FrameType = 'Beacon';
    case 1
      cfg.FrameType = 'Data';
    case 2
      cfg.FrameType = 'Acknowledgment';
    case 3
      cfg.FrameType = 'MAC command';
  end
  
  % 2. Security enabled -> security is not supported
  cfg.Security = frameControl(4);
  
  % 3. Frame pending
  cfg.FramePending = logical(frameControl(5));
  
  % 4. Acknowledgment request
  cfg.AcknowledgmentRequest = logical(frameControl(6));
  
  % 5. PAN ID compression
  cfg.PANIdentificationCompression = logical(frameControl(7));
  
  % 6 Bits 8-10 are reserved
  
  % 7. Destination addressing mode
  switch bit2int(frameControl(11:12)', 2, false)
    case 0
      cfg.DestinationAddressing = 'Not present';
    case 2
      cfg.DestinationAddressing = 'Short address';
    case 3
      cfg.DestinationAddressing = 'Extended address';
  end
    
  % 8. Frame version
  if frameControl(14)
    cfg.FrameVersion = '2011';
  else
    cfg.FrameVersion = '2003';
  end
  
  % 9. Source addressing mode
  switch bit2int(frameControl(15:16)', 2, false)
    case 0
      cfg.SourceAddressing = 'Not present';
    case 2
      cfg.SourceAddressing = 'Short address';
    case 3
      cfg.SourceAddressing = 'Extended address';
  end
end

function [cfg, cnt] = decodeAddressingFields(cfg, macFrame)
  
  cnt = 1 + 3*8;    % beginning of addressing fields

  % 3.1 Destination PAN Identifier (always 2 octets)
  if ~strcmp(cfg.DestinationAddressing, 'Not present')
    cfg.DestinationPANIdentifier = dec2hex(bit2int(macFrame(1+3*8 : 5*8)', 2*8, false), 4);
  end
  
  % 3.2 Destination address
  if     strcmp(cfg.DestinationAddressing, 'Short address')    % 2 octets
    cfg.DestinationAddress = dec2hex(bit2int(macFrame(1+5*8 : 7*8)', 2*8, false), 4);
    cnt = cnt + (2+2)*8; % skip PAN ID and short address
  elseif strcmp(cfg.DestinationAddressing, 'Extended address') % 8 octets
    cfg.DestinationAddress = dec2hex(double(bit2int(uint64(macFrame(1+5*8 : 13*8)'), 8*8, false)), 16);
    cnt = cnt + (2+8)*8; % skip PAN ID and extended address
  end
  
  % 3.3 Source PAN Identifier
  if ~strcmp(cfg.SourceAddressing, 'Not present') && ...
      ~(cfg.PANIdentificationCompression && ~strcmp(cfg.DestinationAddressing, 'Not present'))
    cfg.SourcePANIdentifier = dec2hex(bit2int(macFrame(cnt : cnt+2*8-1)', 2*8, false), 4);
    cnt = cnt + 2*8;
  end
  
  % 3.4 Source address
  if     strcmp(cfg.SourceAddressing, 'Short address')    % 2 octets
    cfg.SourceAddress = dec2hex(bit2int(macFrame(cnt : cnt+2*8-1)', 2*8, false), 4);
    cnt = cnt + 2*8; % skip PAN ID and short address
  elseif strcmp(cfg.SourceAddressing, 'Extended address') % 8 octets
    cfg.SourceAddress = dec2hex(double(bit2int(uint64(macFrame(cnt : cnt+8*8-1)'), 8*8, false)), 16);
    cnt = cnt + 8*8; % skip PAN ID and extended address
  end
end

function [cfg, cnt] = decodeSecurityHeader(cfg, macFrame, cnt)

  % 1. First octet is security control
  securityControl = macFrame(cnt:cnt+7);
  cnt = cnt + 8;
  
  % 1.1 Security level
  cfg.SecurityLevel = bit2int(securityControl(1:3)', 4, false);
  
  % 1.2 Key identifier mode
  cfg.KeyIdentifierMode = bit2int(securityControl(4:5)', 2, false);
  
  % bits 6:8 of security control are reserved

  
  % 2. Frame counter (next 4 octets)
  cfg.FrameCounter = bit2int(macFrame(cnt:cnt+4*8-1)', 4*8, false);
  cnt = cnt + 4*8;
  
  % 3. Key Identifier
  if cfg.KeyIdentifierMode ~= 0 % otherwise 0 octets for key identifier
    
    % 3.1 Key Source
    if cfg.KeyIdentifierMode == 1
      cfg.KeySource = '';      
      
    elseif cfg.KeyIdentifierMode == 2
      cfg.KeySource = dec2hex(bit2int(macFrame(cnt:cnt+4*8-1)', 4*8, false));
      cnt = cnt + 4*8;
      
    elseif cfg.KeyIdentifierMode == 3
      cfg.KeySource = dec2hex(bit2int(macFrame(cnt:cnt+8*8-1)', 8*8, false));
      cnt = cnt + 8*8;
    end
    
    % 3.2 Key Index
    cfg.KeyIndex = bit2int(macFrame(cnt:cnt+7)', 8, false);
    cnt = cnt + 8;
  end
end

function [cfg, varargout] = decodeMACPayload(cfg, macPayload)

  if strcmp(cfg.FrameType, 'Acknowledgment')
    % no-op, ACKs do not contain a MAC payload, macPayload input should be empty
    
  elseif strcmp(cfg.FrameType, 'Data')
    varargout{1} = macPayload; % 100% payload, no other fields
  
  elseif strcmp(cfg.FrameType, 'Beacon')
  
    cfg = decodeBeaconPayload(cfg, macPayload);
    
  elseif strcmp(cfg.FrameType, 'MAC command')
    
    cfg = decodeMACCommandPayload(cfg, macPayload);
  end
  
end

function cfg = decodeBeaconPayload(cfg, macPayload)
    
  % 1. Superframe specification (first 2 octets)
  superframeSpec = macPayload(1 : 2*8);

  % 1.1 Beacon order
  cfg.BeaconOrder = bit2int(superframeSpec(1:4)', 4, false);

  % 1.2 Superframe order
  cfg.SuperframeOrder = bit2int(superframeSpec(5:8)', 4, false);

  % 1.3 Final CAP slot
  cfg.FinalCAPSlot = bit2int(superframeSpec(9:12)', 4, false);

  % 1.4 Battery Life Extension
  cfg.BatteryLifeExtension = logical(superframeSpec(13));

  % 14th bit is reserved (0).

  % 1.5 PAN Coordinator
  cfg.PANCoordinator = logical(superframeSpec(15));

  % 1.5 Association permit
  cfg.PermitAssociation = logical(superframeSpec(16));

  
  % 2. GTS fields
  
  % 2.1 GTS Specification (1 octet)
  % 2.1.1 GTS Descriptor count:
  gtsSpec = macPayload(1 + 2*8 : 3*8);
  numGTS = bit2int(gtsSpec(1:3)', 3, false);
  
  % bits 4-7 are reserved
  
  % 2.2.2 GTS Permit
  cfg.PermitGTS = logical(gtsSpec(8));
  
  if numGTS > 0
    % 2.2 GTS directions
    gtsDirections = logical(macPayload(1+3*8: 3*8+numGTS ));
    
    % 2.3 GTS List
    offset = 1 + (2+1+1)*8;
    gtsCell = {};
    for idx = 1:numGTS
      gtsList = macPayload(offset + (idx-1)*3*8 : offset + idx*3*8 - 1);
      
      % 2.3.1 Device short address 
      gtsCell{idx, 1} = dec2hex(bit2int(gtsList(1:16)', 16, false), 4);
      
      % 2.3.2 GTS starting slot
      gtsCell{idx, 2} = bit2int(gtsList(17:20)', 4, false);
      
      % 2.3.3 GTS length
      gtsCell{idx, 3} = bit2int(gtsList(21:24)', 4, false);
      
      % 2.3.4 GTS direction
      gtsCell{idx, 4} = gtsDirections(idx);
    end
    
    cfg.GTSList = gtsCell;
  end
  
  
  % 3. Pending addresses
  offset = 1 + (2+1)*8 + (numGTS > 0)*8 + numGTS*3*8;
  
  % 3.1 Pending address specification (1 octet)
  pendingAddressSpec = macPayload(offset : offset + 8 - 1);
  
  % 3.1.1 Number of short addresses
  numShort    = bit2int(pendingAddressSpec(1:3)', 3, false);
  % 3.1.2 Number of extended addresses
  numExtended = bit2int(pendingAddressSpec(5:7)', 3, false);
  
  offset = offset + 8;
  
  % 3.2 Address list
  addresses = {};
  for idx = 1:numShort
    addresses{idx} = dec2hex(bit2int(macPayload(offset : offset + 2*8 - 1)', 2*8, false), 4);
    offset = offset + 2*8;
  end
  
  for idx = idx+1 : idx+numExtended
    addresses{idx} = dec2hex(bit2int(macPayload(offset : offset + 8*8 - 1)', 8*8, false), 16);
    offset = offset + 8*8;
  end
  cfg.PendingAddresses = addresses;
end

function cfg = decodeMACCommandPayload(cfg, macPayload)

  % 1. Command frame identifier (1 octet)
  ID = bit2int(macPayload(1:8)', 8, false);

  switch ID
    
    case 1
      
      cfg.MACCommand = 'Association request';
      capabilityInfo = macPayload(9:16);
      
      % 2.1 Device type
      cfg.FFDDevice = logical(capabilityInfo(2));
      
      % 2.2 Power source
      cfg.BatteryPowered = ~logical(capabilityInfo(3));
      
      % 2.3 Receive while idle
      cfg.IdleReceiving = logical(capabilityInfo(4));
      
      % 2.4 Security not supported
      
      % 2.5 Allocate address
      cfg.AllocateAddress = logical(capabilityInfo(8));
      
    case 2
      
      cfg.MACCommand = 'Association response';
      
      % 2. Short address
      cfg.ShortAddress = dec2hex(bit2int(macPayload(1+8 : 3*8)', 2*8, false), 4);
      
      % 3. Association status
      status = bit2int(macPayload(1+3*8 : 4*8)', 8, false);
      
      if status == 0
        cfg.AssociationStatus = 'Successful';
      elseif status == 1
        cfg.AssociationStatus = 'PAN at capacity';
      elseif status == 2
        cfg.AssociationStatus = 'PAN access denied';
      end
      
    case 3
      cfg.MACCommand = 'Disassociation notification';
      
      % 2. Disassociation reason
      status = bit2int(macPayload(1+8 : 2*8)', 8, false);
      
      if status == 1
        cfg.DisassociationReason = 'Coordinator';
      elseif status == 2
        cfg.DisassociationReason = 'Device';
      end
      
    case 4
      cfg.MACCommand = 'Data request';
      
    case 5
      cfg.MACCommand = 'PAN ID conflict notification';
      
    case 6
      cfg.MACCommand = 'Orphan notification';
      
    case 7
      cfg.MACCommand = 'Beacon request';
      
    % case 'Coordinator realignment' % Not supported
    
    case 9
      cfg.MACCommand = 'GTS request';
      
      % 2. GTS characteristics (2nd octet)
      gtsCharacteristics = macPayload(9:16);
      
      % 2.1 GTS length
      gtsLen = bit2int(gtsCharacteristics(1:4)', 4, false);
      
      % 2.2 GTS direction
      gtsDirection = logical(gtsCharacteristics(5));
      
      % 2.3 GTS type
      gtsType  = logical(gtsCharacteristics(6));
      
      cfg.GTSCharacteristics = {gtsLen, gtsDirection, gtsType};
  end
end