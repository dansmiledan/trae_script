classdef (StrictDefaults)MACReducedFunctionDevice < lrwpan.MACDevice
%MACREDUCEDFUNCTIONDEVICE An IEEE 802.15.4 MAC Reduced Function Device (RFD)
% A Reduced Function Device (RFD) is an endpoint of a WPAN MAC and performs
% lightweight operations. It can only associate with a single Full
% Function Device (FFD) at a time.
%
%  DEV = lrwpan.MACReducedFunctionDevice creates a Reduced Function MAC Device
%  object.
% 
%  DEV = lrwpan.MACReducedFunctionDevice(Name, Value) creates a Reduced
%  Function MAC Device object., with the specified property Name set to
%  the specified Value. You can specify additional name-value pair
%  arguments in any order as (Name1, Value1, ..., NameN, ValueN).
%
%  ReducedFunctionDevice properties:
% 
%  ExtendedAddress - 64-bit device address
%  ShortAddress    - 16-bit device address
%  PhysicalLayer   - Indication of used PHY
%  SamplesPerChip  - Number of samples per symbol
%  CarrierSenseThreshold - Carrier sense threshold
%  Verbosity       - Option to print detailed activity
%
%   See also lrwpan.MACFullFunctionDevice

%   Copyright 2017-2023 The MathWorks, Inc.
    
  
  properties(Hidden)
    pFFDShort    = '0000'             % The short address of the associated Full Function Device
    pFFDExtended = '0000000000000000' % The extended ddress of the associated Full Function Device
  end
  
  methods
    %CONSTRUCTOR
    function obj = MACReducedFunctionDevice(varargin)
      obj@lrwpan.MACDevice(varargin{:}); % call base constructor
      
      % call scan upon construction to find a PAN to associate
      active = true;
      scanDuration = 5;
      obj.scan(active, scanDuration);
    end
  end
  
  methods (Access = protected)    
    function flag = isInputComplexityMutableImpl(~, ~)
        flag = true;
    end
  end
  
end

