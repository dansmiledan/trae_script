function waveform = PHYGeneratorASK( MPDU, varargin )
%PHYGENERATORASK Transmit-side ASK physical layer of 802.15.4
%   WAVEFORM = PHYGENERATORASK( MPDU ) uses BPSK to modulate the SHR
%   (synchronization header, i.e., preamble and start-of-frame delimiter).
%   Then, the frame length and the MPDU bits are mapped to 20-bit (868 MHz)
%   or 5-bit (915 MHz) symbols. Subsequently, symbols are mapped to chips
%   using Parallel Sequence Spread Spectrum (PSSS) / Orthogonal Code
%   Division Multiplexing (OCDM). Chips are then ASK-modulated using a root
%   raised cosine filter.
%
%   See also lrwpanWaveformGenerator, LRWPAN.PHYDECODERASK,
%   LRWPAN.PHYGENERATORBPSK, LRWPAN.PHYGENERATORGFSK

%   Copyright 2017-2023 The MathWorks, Inc.

persistent rcosfilt % Persistent raised cosine filter, as one-time setup is the computational bottleneck

reservedValue = 0;

%% Validation
OSR = lrwpan.internal.generatorValidation(MPDU, nargin, varargin);

% frequency band specification
if nargin == 3
  band = validatestring(varargin{2},{'868 MHz', '915 MHz'},'','frequency band');
else
  band = '915MHz';
end


%% PSSS (Parallel Sequence Spread Spectrum) code tables
baseChipSeq = [-1 -1 -1 -1  1 -1 -1  1 -1  1  1 -1 -1  1  1  1  1  1 -1 -1 -1  1  1 -1  1  1  1 -1 1 -1  1 -1];

% 868 MHz
if strcmp(band, '868 MHz')

  codeTable = zeros(20, 64);
  codeTable(1, :) = repelem(baseChipSeq, 2);
  for idx = 2:20
    codeTable(idx, :) = circshift(codeTable(idx-1, :), 3);
    codeTable(idx, 1:3) = codeTable(idx-1, 60:62);
  end
  
  numPreambleRepeat = 2;
  symbolLen = 20;
  
else % 915 MHz
  codeTable = zeros(5, 32);
  codeTable(1, :) = baseChipSeq;
  for idx = 2:5
    codeTable(idx, :)   = circshift(codeTable(idx-1, :), 6);
    codeTable(idx, 1:6) = codeTable(idx-1, end-6 : end-1);
  end
  
  numPreambleRepeat = 6;
  symbolLen = 5;
end
chipLen = length(codeTable);

%% Synchronization header (SHR)

% Preamble
sequence0 = codeTable(0 + 1, :); % +1 for 1-based indexing
preamble = repmat(sequence0', numPreambleRepeat, 1);

% Start-of-frame delimiter (SFD)
SFD = fliplr(sequence0)';

SHR = [preamble; SFD];

%% BPSK modulation for SHR
% no-op, data are already -1 and 1

%% PHY Header (PHR)
frameLength = int2bit(length(MPDU)/8, 7, false);
PHR = [frameLength; reservedValue];
ASKbits = [PHR; MPDU];


%% Bits to symbol mapping
chips = zeros(OSR*chipLen*ceil(length(ASKbits)/symbolLen), 1);
for idx = 1:ceil(length(ASKbits)/symbolLen)
  if idx*symbolLen < length(ASKbits)
    symbol = ASKbits(1+(idx-1)*symbolLen : idx*symbolLen);
  else
    % zero-padding to fill symbol
    rem = idx*symbolLen - length(ASKbits);
    symbol = [ASKbits((idx-1)*symbolLen+1:end); zeros(rem, 1)];
  end
  
  %% Symbol to chip mapping
  symbol(symbol==0) = -1; % standard needs [0 1] -> [-1 1] mapping
  chipSeq = symbol'*codeTable;

  % Pre-coding operation
  % Step #1: add constant value to make max and min values symmetric about 0
  chipSeq = chipSeq - (max(chipSeq) + min(chipSeq))/2;

  % Step #2: scale so that maximum value equals 1
  chipSeq = chipSeq/max(chipSeq);
  
  chips(1+(idx-1)*chipLen : chipLen*idx, 1) = chipSeq';
end

%% Amplitude Shift Keying modulation (ASK) with Root Raised Cosine
if isempty(rcosfilt)
  rcosfilt = comm.RaisedCosineTransmitFilter('RolloffFactor', 0.2, ...
                'OutputSamplesPerSymbol', OSR); % default Shape is square root
elseif rcosfilt.OutputSamplesPerSymbol ~= OSR
  release(rcosfilt);
  rcosfilt.OutputSamplesPerSymbol = OSR;
end
askMod = rcosfilt(chips);
reset(rcosfilt); % reset persistent variable

waveform = [SHR; askMod];
