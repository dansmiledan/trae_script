function MPDU = PHYDecoderGFSK( waveform, varargin )
%PHYDECODERGFSK Receive-side GFSK physical layer of 802.15.4
%   MPDU = PHYDECODERGFSK( WAVEFORM ) decodes the GFSK waveform
%   WAVEFORM and returns the corresponding MAC protocol data unit bits
%   MPDU. The waveform is first GFSK demodulated and next the resulting
%   bits are de-whitened.
%
%   See also LRWPAN.PHYGENERATORGFSK, LRWPAN.PHYDECODEROQPSKNOSYNC, LRWPAN.PHYDECODERBPSK,
%   LRWPAN.PHYDECODERASK

%   Copyright 2017-2023 The MathWorks, Inc. 

% OSR specification
OSR = lrwpan.internal.osrValidation(nargin, varargin);

%% GFSK demodulation
gfskDemod = comm.CPMDemodulator('ModulationOrder', 2, 'FrequencyPulse', 'Gaussian', ...
                  'BandwidthTimeProduct', 0.5, 'ModulationIndex', 1, ...
                  'BitOutput', true, 'SamplesPerSymbol', OSR);
% underlying filtering introduces delay. Handle it by shifting output window
delay = gfskDemod.TracebackDepth;
waveformPadded = [waveform; zeros(delay*OSR, 1)];
demodulatedAll = gfskDemod(waveformPadded);
demodulated = demodulatedAll(1+delay:end);

%% Data whitening
shrLen = 4*8 + 8;
pn9 = comm.PNSequence('Polynomial',      commstr2poly('x^9 + x^5 + 1', 'descending'), ...
                      'SamplesPerFrame', length(demodulated)-shrLen, ...
                      'InitialConditions', ones(1, 9), 'Mask', 9);

dewhitened = double(xor( demodulated(1+shrLen:end), pn9() )); % SHR is not whitened

%% Remove PHY header (PHR)
PHRlen = 8;
MPDU = dewhitened(PHRlen+1:end);
