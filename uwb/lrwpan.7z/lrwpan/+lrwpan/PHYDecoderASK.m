function MPDU = PHYDecoderASK( waveform, varargin )
%PHYDECODERASK Receive-side ASK physical layer of 802.15.4
%   MPDU = PHYDECODERASK( WAVEFORM ) decodes the ASK waveform WAVEFORM and
%   returns the corresponding MAC protocol data unit bits MPDU. The
%   BPSK-modulated synchronization header (SHR) is first removed from the
%   waveform, which is then filtered with a root raised cosine filter. A
%   matrix multiplication then conducts the ASK demodulation and decoding
%   of Parallel Sequence Spread Spectrum (PSSS) / Orthogonal Code
%   Division Multiplexing (OCDM).
%
%   See also LRWPAN.PHYGENERATORASK, LRWPAN.PHYDECODEROQPSKNOSYNC, LRWPAN.PHYDECODERBPSK,
%   LRWPAN.PHYDECODERGFSK

%   Copyright 2017-2023 The MathWorks, Inc. 

persistent rcosfilt % Persistent raised cosine filter, as one-time setup is the tall performance pole.

% OSR specification
OSR = lrwpan.internal.osrValidation(nargin, varargin);

if nargin == 3
  band = validatestring(varargin{2},{'868 MHz', '915 MHz'},'','frequency band');
else
  band = '915 MHz';
end

%% Setup
% PSSS (Parallel Sequence Spread Spectrum) code tables
baseChipSeq = [-1 -1 -1 -1  1 -1 -1  1 -1  1  1 -1 -1  1  1  1  1  1 -1 -1 -1  1  1 -1  1  1  1 -1 1 -1  1 -1];

if strcmp(band, '868 MHz')
  
  codeTable = zeros(20, 64);
  codeTable(1, :) = repelem(baseChipSeq, 2);
  for idx = 2:20
    codeTable(idx, :) = circshift(codeTable(idx-1, :), 3);
    codeTable(idx, 1:3) = codeTable(idx-1, 60:62);
  end
  
  numPreambleRepeat = 2;
  symbolLen = 20;
  
else % 915 MHz
  
  codeTable = zeros(5, 32);
  codeTable(1, :) = baseChipSeq;
  for idx = 2:5
    codeTable(idx, :)   = circshift(codeTable(idx-1, :), 6);
    codeTable(idx, 1:6) = codeTable(idx-1, end-6 : end-1);
  end
  
  numPreambleRepeat = 6;
  symbolLen = 5;
end
chipLen = length(codeTable);

%% Remove preamble
preambleLen = numPreambleRepeat * chipLen;  % 4 octets
sfdLen = chipLen;
askWaveform = waveform(1+preambleLen+sfdLen:end);


%% Filtering
if isempty(rcosfilt)
  rcosfilt = comm.RaisedCosineReceiveFilter('RolloffFactor', 0.2, ...
            'InputSamplesPerSymbol', OSR, 'DecimationFactor', OSR); % default Shape is square root
elseif rcosfilt.InputSamplesPerSymbol ~= OSR
  release(rcosfilt);
  rcosfilt.InputSamplesPerSymbol = OSR;
  rcosfilt.DecimationFactor = OSR;
end
% Filtering introduces delay
delay = rcosfilt.FilterSpanInSymbols;
askWaveformPadded = [askWaveform; zeros(delay*OSR, 1)];
filtered = rcosfilt(askWaveformPadded);
chips = filtered(1+delay:end);
reset(rcosfilt); % reset persistent variable

%% ASK and DSSS / OCDM demodulation/decoding
MPDU = zeros(symbolLen*length(chips)/chipLen, 1);
for idx = 1:length(chips)/chipLen
  chipSeq = chips(1+(idx-1)*chipLen : idx*chipLen);
  metrics = codeTable * chipSeq; % the higher the product elements, the more likely the bits to be 1 instead of 0
  
  %% Symbol to bit mapping
  MPDU(1+(idx-1)*symbolLen : idx*symbolLen, 1) = metrics > 0; % slicing 
end

PHRlen = 8;
MPDU = MPDU(PHRlen+1:end); 
