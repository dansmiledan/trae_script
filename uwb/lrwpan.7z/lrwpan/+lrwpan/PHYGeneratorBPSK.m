function waveform = PHYGeneratorBPSK( MPDU, varargin )
%PHYGENERATORBPSK Transmit-side BPSK physical layer of 802.15.4
%   WAVEFORM = PHYGENERATORBPSK( MPDU ) uses BPSK and direct sequence
%   spread spectrum (DSSS) to generate the physical-layer waveform WAVEFORM
%   corresponding to the MAC protocol data unit MPDU. A synchronization
%   header is added, comprising a preamble and a "start-of-frame"
%   delimiter. The frame length is also encoded. The MPDU bits are
%   differentially encoded and mapped to chips. Chips are subsequently BPSK
%   modulated and filtered with a raised cosine filter.
%
%   See also lrwpanWaveformGenerator, LRWPAN.PHYDECODERBPSK,
%   LRWPAN.PHYGENERATORASK, LRWPAN.PHYGENERATORGFSK

%   Copyright 2017-2023 The MathWorks, Inc.

persistent rcosfilt % Persistent raised cosine filter, as one-time setup is the computational bottleneck

reservedValue = 0;

% OSR specification
OSR = lrwpan.internal.generatorValidation(MPDU, nargin, varargin);

%% Synchronization header (SHR)

% Preamble is 4 octets, all set to 0.
preamble = zeros(4*8, 1);

% Start-of-frame delimiter (SFD)
SFD = [1 1 1 0 0 1 0 1]'; % value from standard (see Fig. 68, IEEE 802.15.4, 2011 Revision)

SHR = [preamble; SFD];

%% PHY Header (PHR)
frameLength = int2bit(length(MPDU)/8, 7, false);
PHR = [frameLength; reservedValue];

%% PHY protocol data unit:
PPDU = [SHR; PHR; MPDU];


%% Differential Encoding
diffEnc = comm.DifferentialEncoder();
diffBits = diffEnc(PPDU);

%% Bit to chip mapping
chips = [1 1 1 1 0 1 0 1 1 0 0 1 0 0 0;  % Chip for 0 bit
         0 0 0 0 1 0 1 0 0 1 1 0 1 1 1]; % Chip for 1 bit
       
chipBits = zeros(length(chips), length(diffBits)); % preallocate
for idx = 1:length(diffBits)
  chipBits(:, idx) = chips(1+diffBits(idx), :); % +1 for 1-based indexing
end


%% BPSK modulation
iniPhase = pi; % 1 for positive pulse, 0 for negative pulse
modulated = pskmod(chipBits(:), 2, iniPhase);

%% Filtering
if isempty(rcosfilt)
  rcosfilt = comm.RaisedCosineTransmitFilter('RolloffFactor', 1, ...
                  'OutputSamplesPerSymbol', OSR, 'Shape', 'Normal');
elseif rcosfilt.OutputSamplesPerSymbol ~= OSR
  release(rcosfilt);
  rcosfilt.OutputSamplesPerSymbol = OSR;
end

waveform = rcosfilt(modulated);
reset(rcosfilt); % reset persistent variable

