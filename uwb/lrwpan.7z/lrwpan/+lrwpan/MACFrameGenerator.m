function macFrame = MACFrameGenerator(cfg, varargin)
%MACFRAMEGENERATOR Generate 802.15.4 MAC frames
%   MACFRAME = MACFRAMEGENERATOR(CFG) generates the MAC frame
%   MACFRAME corresponding to the MACFrameConfig configuration object CFG.
%   This syntax should be used for 3 out of the 4 allowed frame types
%   (beacon, acknowledgment, MAC command).
%
%   MACFRAME = MACFRAMEGENERATOR(CFG, PAYLOAD) generates the MAC
%   frame MACFRAME corresponding to the configuration CFG and containing
%   the payload PAYLOAD. This syntax should be used for the data frame type.
%
%   See also lrwpan.MACFrameConfig, lrwpan.MACFrameDecoder.

%   Copyright 2017-2023 The MathWorks, Inc.

  % Make sure that some fields take the only value allowed by the standard
  % for some FrameType/MACCommand configurations
  cfg = preprocessConfig(cfg);

  % Get MAC Header for current configuration:
  MHR = getMACHeader(cfg);

  % Create MAC Payload (possibly add some headers to input payload):
  MACPayload = getMACPayload(cfg, varargin);
  MHRwMACPayload = [MHR MACPayload];

  % Get MAC Footer (16-bit CRC on MAC Header and MAC Payload):
  MFR = getMACFooter(MHRwMACPayload);

  % Combine MAC Header, MAC Payload, and MAC Footer:
  macFrame = [MHR MACPayload MFR]';
end

function cfg = preprocessConfig(cfg)
  % Changes can also throw a warning
  if strcmp(cfg.FrameType, 'MAC command')
  
    if strcmp(cfg.MACCommand, 'Association request') 
      cfg.SourceAddressing              = 'Extended address';
      cfg.FramePending                  = false;
      cfg.AcknowledgmentRequest         = true;
      cfg.SourcePANIdentifier           = 'FFFF'; % broadcast;
      
    elseif strcmp(cfg.MACCommand, 'Association response')
      cfg.SourceAddressing              = 'Extended address';
      cfg.DestinationAddressing         = 'Extended address';
      cfg.FramePending                  = false;
      cfg.AcknowledgmentRequest         = true;
      cfg.PANIdentificationCompression  = true;
      
    elseif strcmp(cfg.MACCommand, 'Beacon request') 

      cfg.SourceAddressing              = 'Not present';
      cfg.DestinationAddressing         = 'Short address';
      cfg.DestinationPANIdentifier      = 'FFFF';
      cfg.DestinationAddress            = 'FFFF';
      cfg.FramePending                  = false;
      cfg.AcknowledgmentRequest         = false;
      cfg.Security                      = false;
    end
  end
end

function MHR = getMACHeader(cfg)

  % Get common MAC header parts:
  
  % 1. Frame control:
  frameControl = zeros(1, 16);
  mhrLen = (2+1)*8; % 2 octets for frame control, 1 octet for sequence num
  
  % 1.1 Frame type:
  switch cfg.FrameType
    case 'Beacon'
      frameControl(1:3) = [0 0 0];
    case 'Data'
      frameControl(1:3) = [1 0 0];
    case 'Acknowledgment'
      frameControl(1:3) = [0 1 0];
    case 'MAC command'
      frameControl(1:3) = [1 1 0];
    % first bit is "reserved", currently it can only be 0
  end
  % 1.2 Security enabled:
  if cfg.Security
    error(message('lrwpan:LRWPAN:UnsupportedSecurity'));
  end
  frameControl(4) = 0; % security is not supported by the frame generator
  
  % 1.3 Frame pending:
  frameControl(5) = double(cfg.FramePending);
  
  % 1.4 Acknowledgment request (AR):
  frameControl(6) = double(cfg.AcknowledgmentRequest);
  
  % 1.5 PAN ID compression:
  frameControl(7) = double(cfg.PANIdentificationCompression);
  
  % 1.6 Reserved
  frameControl(8:10) = [0 0 0];
  
  % 1.7 Destination addressing mode:
  if strcmp(cfg.DestinationAddressing, 'Not present')
    % Beacon only contains source address, not destination
    frameControl(11:12) = [0 0];
  elseif strcmp(cfg.DestinationAddressing, 'Extended address')
    frameControl(11:12) = [1 1];
    mhrLen = mhrLen + 2*8 + 8*8; % 2 octets for PAN ID, and 8 for address
  else %if strcmp(cfg.DestinationAddressing, 'Short address')
    frameControl(11:12) = [0 1];
    mhrLen = mhrLen + 2*8 + 2*8; % 2 octets for PAN ID, and 2 for address
  end
  
  % 1.8 Frame version:
  switch cfg.FrameVersion
    case '2003'
      frameControl(13:14) = [0 0];
    case '2011'
      frameControl(13:14) = [0 1];
  end  
  
  % 1.9 Source addressing mode:
  if strcmp(cfg.SourceAddressing, 'Not present')
    % Beacon only contains source address, not destination
    frameControl(15:16) = [0 0];
  else
    if ~cfg.PANIdentificationCompression || strcmp(cfg.DestinationAddressing, 'Not present')
      mhrLen = mhrLen + 2*8; % 2 octets for PAN ID
    end
    
    if strcmp(cfg.SourceAddressing, 'Extended address')
      frameControl(15:16) = [1 1];
      mhrLen = mhrLen + 8*8; % 8 octets for address
    else % 'Short address'
      frameControl(15:16) = [0 1];
      mhrLen = mhrLen + 2*8; % 2 octets for address
    end
  end

  if  strcmp(cfg.FrameType, 'Acknowledgment')
    mhrLen = 3*8; % 2 for Frame control and 1 for Seq#. No addressing fields
  end
  MHR = zeros(1, mhrLen);
  MHR(1:2*8) = frameControl;
  
  % 2. Sequence number
  MHR(2*8+1:3*8) = int2bit(cfg.SequenceNumber, 8, false);
  cnt = 3*8;
  
  % 3. Addressing fields
  if ~strcmp(cfg.DestinationAddressing, 'Not present')
    % 3.1 Destination PAN ID
    MHR(cnt+1:cnt+2*8) = int2bit(hex2dec(cfg.DestinationPANIdentifier), 2*8, false);
    cnt = cnt+2*8;
    
    % 3.2 Destination Address
    if strcmp(cfg.DestinationAddressing, 'Short address')
      MHR(cnt+1:cnt+2*8) = int2bit(hex2dec(cfg.DestinationAddress), 2*8, false);
      cnt = cnt+2*8;
    else % 'Extended address'
      % two steps because of 2^53 limit in dec representation
      MHR(cnt+1     : cnt+4*8) = int2bit(hex2dec(cfg.DestinationAddress(9:end)), 4*8, false);
      MHR(cnt+4*8+1 : cnt+8*8) = int2bit(hex2dec(cfg.DestinationAddress(1:8)),   4*8, false);
      cnt = cnt+8*8;
    end
  end
  
  if ~strcmp(cfg.SourceAddressing, 'Not present')
    
    % 3.3 Source PAN ID
    if ~cfg.PANIdentificationCompression || strcmp(cfg.DestinationAddressing, 'Not present')
      MHR(cnt+1:cnt+2*8) = int2bit(hex2dec(cfg.SourcePANIdentifier), 2*8, false);
      cnt = cnt+2*8;
    end
    
    % 3.4 Source Address
    if strcmp(cfg.SourceAddressing, 'Short address')
      MHR(cnt+1:cnt+2*8) = int2bit(hex2dec(cfg.SourceAddress), 2*8, false);
    else % 'Extended address'
      % two steps because of 2^53 limit in dec representation
      MHR(cnt+1     : cnt+4*8) = int2bit(hex2dec(cfg.SourceAddress(9:end)), 4*8, false);
      MHR(cnt+4*8+1 : cnt+8*8) = int2bit(hex2dec(cfg.SourceAddress(1:8)),   4*8, false);
    end
  end
  
  % 4. Auxiliary Security Header 
  % Not supported. 0 octets.
end

function MACPayload = getMACPayload(cfg, args)

  if strcmp(cfg.FrameType, 'Acknowledgment')
    MACPayload = [];
    
  elseif strcmp(cfg.FrameType, 'Data')
    
    if isempty(args)
      error(message('lrwpan:LRWPAN:MissingPaylod'));
    else
      MACPayload = args{1};
      if size(MACPayload, 2) ~= 2
        error(message('lrwpan:LRWPAN:InvalidMACPayloadLen'));
      end
      % convert bytes to bits
      temp = hex2dec(MACPayload);
      MACPayload = int2bit(temp(:), 8, false)';
    end
    
  elseif strcmp(cfg.FrameType, 'Beacon')
    
    MACPayload = getBeaconMACPayload(cfg);
    
  else % MAC command
    
    MACPayload = getCommandMACPayload(cfg);
  end
  
  if ~isempty(args) && ~strcmp(cfg.FrameType, 'Data')
    warning(message('lrwpan:LRWPAN:IgnoredPayload'));
  end
end

function MACPayload = getBeaconMACPayload(cfg)

  % 1. Superframe specification
  superframeSpec = zeros(1, 16);
  % 1.1 Beacon order 
  superframeSpec(1:4) = int2bit(cfg.BeaconOrder, 4, false);

  % 1.2 Superframe order 
  superframeSpec(5:8) = int2bit(cfg.SuperframeOrder, 4, false);

  % 1.3 Final CAP slot
  superframeSpec(9:12) = int2bit(cfg.FinalCAPSlot, 4, false);

  % 1.4 Battery Life Extension
  superframeSpec(13) = double(cfg.BatteryLifeExtension);

  superframeSpec(14) = 0; % reserved

  % 1.5 PAN Coordinator
  superframeSpec(15) = double(cfg.PANCoordinator);

  % 1.6 Association Permit
  superframeSpec(16) = double(cfg.PermitAssociation);


  % 2. GTS fields
  numGTS = size(cfg.GTSList, 1);
  if numGTS == 0 
    gtsLen = 8*1; % GTS specification only
  else
    % 1 octet for GTS specification, 1 for GTS directions and 3 for each
    % GTS entry:
    gtsLen = 8*(1+1+3*numGTS);
  end
  gtsFields = zeros(1, gtsLen);

  % 2.1 GTS Specification
  gtsSpecification = zeros(1, 8); % 1 octet
  % 2.1.1: GTS Descriptor count (num of GTS list entries)
  gtsSpecification(1:3) = int2bit(numGTS, 3, false);

  gtsSpecification(4:7) = [0 0 0 0]; % reserved

  % 2.1.3: GTS Permit:
  gtsSpecification(8) = double(cfg.PermitGTS);
  gtsFields(1:8) = gtsSpecification;


  if numGTS > 0
    % 2.2  GTS Directions
    gtsDirections = zeros(1, 8);
    gtsDirections(1:numGTS) = double([cfg.GTSList{:, 4}])';
    gtsFields(9:16) = gtsDirections;

    % 2.3
    gtsList = zeros(1, 3*8*numGTS);
    for idx = 1:numGTS
      % 2.3.1 Device Short Address
      thisStart = 1+(idx-1)*3*8;
      gtsList(thisStart : thisStart+2*8-1) = ...
        int2bit(hex2dec(cfg.GTSList{idx, 1}), 16, false);

      % 2.3.2 GTS Starting slot
      gtsList(thisStart+2*8 : idx*3*8-4) = int2bit(cfg.GTSList{idx, 2}, 4, false);

      % 2.3.3 GTS Length
      gtsList(idx*3*8-3 : idx*3*8) = int2bit(cfg.GTSList{idx, 3}, 4, false);
    end
    gtsFields(17:end) = gtsList;
  end

  % 3. Pending Address Fields
  lens = cellfun(@length, cfg.PendingAddresses);
  shortAddresses    = cfg.PendingAddresses(lens == 4);
  extendedAddresses = cfg.PendingAddresses(lens == 16);
  numShort    = length(shortAddresses);    % 4  hex digits -> 2 octets each
  numExtended = length(extendedAddresses); % 16 hex digits -> 8 octets each
  pendingLen  = 8*(1 + 2*numShort + 8*numExtended);
  pendingAddresses = zeros(1, pendingLen);

  % 3.1 Pending address specification
  pendingAddresses(1:3) = int2bit(numShort, 3, false);
  pendingAddresses(4)   = 0; % reserved
  pendingAddresses(5:7) = int2bit(numExtended, 3, false);
  pendingAddresses(8)   = 0; % reserved
  cnt = 8;
  % 3.2 Pending address specification
  for idx = 1:numShort
    % Short address
    pendingAddresses(cnt+1:cnt+2*8) = int2bit(hex2dec(shortAddresses{idx}), 2*8, false);
    cnt = cnt + 2*8;
  end
  for idx = 1:numExtended
    % Extended address
    pendingAddresses(cnt+1:cnt+8*8) = int2bit(hex2dec(extendedAddresses{idx}), 8*8, false);
    cnt = cnt + 8*8;
  end

  % 4. Beacon payload
  beaconPayload = zeros(1, 8); % contents are NULL. Choose 1 octet

  MACPayload = [superframeSpec gtsFields pendingAddresses beaconPayload];
end

function MACPayload = getCommandMACPayload(cfg)
  
  switch cfg.MACCommand
    case 'Association request'
      % 1. Command frame identifier
      commandID = int2bit(1, 8, false)';      
      
      % 2. Capability information
      capabilityInfo = zeros(1, 8);
      
      % capabilityInfo(1) = 0; reserved
      
      % 2.1 Device Type
      capabilityInfo(2) = double(cfg.FFDDevice);
      
      % 2.2 Power source
      capabilityInfo(3) = double(~cfg.BatteryPowered); % 1 if AC connected
      
      % 2.3 Receiver On When Idle
      capabilityInfo(4) = double(cfg.IdleReceiving);
      
      capabilityInfo(5:6) = [0 0]; % reserved
      
      % 2.4 Security
      capabilityInfo(7) = 0; % security not supported
      
      % 2.5 Allocate Address
      capabilityInfo(8) = double(cfg.AllocateAddress);
      
      MACPayload = [commandID capabilityInfo];
      
    case 'Association response'
      % 1. Command frame identifier
      commandID = int2bit(2, 8, false)';
      
      % 2. Short Address
      shortAddress = int2bit(hex2dec(cfg.ShortAddress), 2*8, false)';
      
      % 3. Association status
      switch cfg.AssociationStatus
        case 'Successful'
          status = zeros(1, 8);
        case 'PAN at capacity'
          status = [1 zeros(1, 7)];
        case 'PAN access denied'
          status = [0 1 zeros(1, 6)];
      end
      
      MACPayload = [commandID shortAddress status];
      
    case 'Disassociation notification'
      % 1. Command frame identifier
      commandID = int2bit(3, 8, false)';
      
      % 2. Disassociation reason:
      switch cfg.DisassociationReason
        case 'Coordinator'
          reason = [1 zeros(1, 7)];
        case 'Device'
          reason = [0 1 zeros(1, 6)];
      end
      
      MACPayload = [commandID reason];
      
    case 'Data request'
      % 1. Command frame identifier
      commandID = int2bit(4, 8, false)';
      
      MACPayload = commandID;
      
    case 'PAN ID conflict notification'
      % 1. Command frame identifier
      commandID = int2bit(5, 8, false)';
      
      MACPayload = commandID;
      
    case 'Orphan notification'
      % 1. Command frame identifier
      commandID = int2bit(6, 8, false)';
      
      MACPayload = commandID;
      
    case 'Beacon request'
      % 1. Command frame identifier
      commandID = int2bit(7, 8, false)';
      
      MACPayload = commandID;
      
    % case 'Coordinator realignment' % Not supported
    
    case 'GTS request'
      % 1. Command frame identifier
      commandID = int2bit(9, 8, false)';
      
      % 2. GTS Characteristics
      gtsCharacteristics = zeros(1, 8);
      
      % 2.1 GTS Length
      gtsCharacteristics(1:4) = int2bit(cfg.GTSCharacteristics{1}, 4, false)';
      
      % 2.2 GTS Direction
      gtsCharacteristics(5) = double(cfg.GTSCharacteristics{2});
      
      % 2.3 Characteristics type
      gtsCharacteristics(6) = double(cfg.GTSCharacteristics{3});
      
      % gtsCharacteristics(7:8) are reserved, i.e., 0
      
      MACPayload = [commandID gtsCharacteristics];
  end
end

function MFR = getMACFooter(MHRwMACPayload)

  % 16-bit ITU-T CRC from 802.15.4 standard:
  crcCfg = crcConfig(Polynomial='x16 + x12 + x5 + 1');
  % generate bits:
  crcBits = crcGenerate(MHRwMACPayload', crcCfg)';
  
  % trim original message:
  MFR = crcBits(1+length(MHRwMACPayload):end);
end