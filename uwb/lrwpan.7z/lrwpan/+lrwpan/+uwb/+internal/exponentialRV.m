function y = exponentialRV(lambda, randomStream, numRows, numCols, dataType) 
  %EXPONENTIALRV Generate exponentially distributed random numbers
  % Y = EXPONENTIALRV(LAMBDA, RANDOMSTREAM, NUMROWS, NUMCOLS) generates
  % NUMROWS x NUMCOLS exponential random numbers, with decay constant
  % LAMBDA. RANDOMSTREAM is the global or internal random stream. DATATYPE
  % can be 'double' or 'single'.

  % Copyright 2023 The MathWorks, Inc.

  u = (rand(randomStream, numRows, numCols, dataType));
  y = log(u)*(-1/lambda); % Exponential interarrival time (in ns), Inverse Transform Method
end