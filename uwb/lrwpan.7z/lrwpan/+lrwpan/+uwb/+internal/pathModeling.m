function [pathArrivalTimes, pathAveragePowers, pathPhases] = ...
  pathModeling(env, clusterArrivalTimes, clusterEnergies, minPathAveragePower, Fs, normalizePathGains, randStream, dataType)
%PATHMODELING Setup path arrival times and average powers
%   [ARRIVALS, AVGPOWERS, PHASES] = pathModeling(ENV, CLUSTERARRIVALS,
%   CLUSTERENERGIES, END_THR, FS, NORM, RANDSTREAM) determines the arrival
%   time and average power of each path, given an environmentConfig
%   environment description ENV, the cluster arrival times CLUSTERARRIVALS,
%   the cluster energies CLUSTERENERGIES, the threshold ratio of the last
%   path power to the first path power END_THR and the sample rate of the
%   channel Fs. CLUSTERARRIVALS and CLUSTERENERGIES are 1xL vectors, where
%   L is the number of clusters. ARRIVALS, AVGPOWERS and PHASES are 1xL
%   cell arrays; each cell element is a 1xK vector, where K is the number
%   of paths within that cluster. The average path powers are normalized if
%   NORM is true. RANDSTREAM is the global or internal random stream.
% 
%   References:
%   [1] - A. F. Molisch et al., "IEEE 802.15.4a Channel Model-Final
%   Report," Tech. Rep., Document IEEE 802.1504-0062-02-004a, 2005
%
%   See also uwbChannel, lrwpan.uwb.internal.environmentConfig.

%   Copyright 2022-2023 The MathWorks, Inc.

L = numel(clusterArrivalTimes);

continuousPDP = strcmp(env.Environment, 'Industrial') || (~env.HasLOS && strcmp(env.Environment, 'Indoor office')); 
singleAlternatePDP = ~env.HasLOS && any(strcmp(env.Environment, {'Indoor office', 'Industrial'}));

pathArrivalTimes = cell(1, L);
pathAveragePowers = cell(1, L);
pathPhases = cell(1, L);
for cluster = 1:L 
  pathArrivalTimes{cluster} = []; %#ok<*AGROW> 
  pathAveragePowers{cluster} = [];
  coder.varsize('pathArrivalTimes{1}');
  coder.varsize('pathAveragePowers{1}');
end % init everything first, for codegen

for cluster = 1:L 
  while true
    % Find arrival time of next path:
    % Asymptotic equivalence with Eq (18) in [1]:
    if ~continuousPDP
      u = rand(randStream, 1, 1);                %  uniform random variable in [0, 1]
      if u < env.MixtureProbability
        lambda = env.PathArrivalRate1;
      else
        lambda = env.PathArrivalRate2;
      end
      if isempty(pathArrivalTimes{cluster})
        % 1st path, by definition delay is 0
        thisInterArrival = zeros(1, 1, dataType);
      else
        thisInterArrival = lrwpan.uwb.internal.exponentialRV(lambda, randStream, 1, 1, dataType); % Exponential interarrival time (in ns), Inverse Transform Method
      end
      if ~isempty(pathArrivalTimes{cluster})
        thisPathDelay = sum([pathArrivalTimes{cluster}(end) thisInterArrival]);
      else
        thisPathDelay = thisInterArrival;
      end

    else % continuousPDP, NLOS Indoor office / Industrial
      % continuous multi-path -> regular tap spacings 
      stepSize = 1e9; % one second. Considering every sample time is computationally challenging
      thisPathDelay = stepSize * numel(pathArrivalTimes{cluster})/Fs;
    end

    % Find average power of next path:
    if ~singleAlternatePDP
      % Eq. (20) in [1]
      gamma = env.PathDecaySlope * clusterArrivalTimes(cluster) + env.PathDecayOffset; % intra-cluster power decay factor
      % Eq. (19) in [1]
      denominator = gamma * ( (1-env.MixtureProbability)*env.PathArrivalRate1 + env.MixtureProbability*env.PathArrivalRate2 + 1 );
      thisAveragePower = clusterEnergies(cluster) * exp(-thisPathDelay/gamma) / denominator;
    else
      % Eq. (22) in [1]
      thisAveragePower = clusterEnergies(cluster) * (1 -env.FirstPathAttenuation*exp(-thisPathDelay/env.PDPIncreaseFactor) ) * ...
        (exp(-thisPathDelay/env.PDPDecayFactor)) * ((env.PDPDecayFactor + env.PDPIncreaseFactor)/env.PDPDecayFactor) / (env.PDPDecayFactor + env.PDPIncreaseFactor*(1-env.FirstPathAttenuation));
    end
    
    if ~isempty(pathAveragePowers{cluster}) && thisAveragePower <= max(max(pathAveragePowers{cluster}))*minPathAveragePower/100 % double max just for codegen
      % cluster lost 95% of initial (or max for alternate PDP) power, declare end
      break;
    else
      pathArrivalTimes{cluster}  = [pathArrivalTimes{cluster} thisPathDelay];      % in ns
      pathAveragePowers{cluster} = [pathAveragePowers{cluster} thisAveragePower];
    end
  end

  % apply uniformly distributed (in [0, 2*pi]) phase -> complex baseband 
  K_L = numel(pathArrivalTimes{cluster});
  pathPhases{cluster} = 2*pi*rand(randStream, 1, K_L, dataType);
end
if normalizePathGains
  sumPower = sum(cell2mat(pathAveragePowers));
  pathAveragePowers = cellfun(@(x) x/sumPower, pathAveragePowers, 'UniformOutput', false);
  % all powers are in linear scale. In dB, the above normalization will give an average of 0 dB.
end

end

