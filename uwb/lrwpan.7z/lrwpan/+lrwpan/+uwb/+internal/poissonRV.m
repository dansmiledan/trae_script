function x = poissonRV(lambda, randStream, dataType)
%poissonRV Generate Poisson random variable
% P = poissonRV(LAMBDA, RANDSTREAM) returns the Poisson random variable P,
% given the Poisson parameter LAMBDA. RANDSTREAM is the global or internal
% random stream. DATATYPE can be 'double' or 'single'.

%   Copyright 2022-2023 The MathWorks, Inc.

%#codegen

    x = zeros(1, 1, dataType);
    p = zeros(1, 1, dataType);
    whileFlag = true;
    while (whileFlag)
      p = p - log(rand(randStream, 1, 1, dataType));
      if (p > lambda)
        whileFlag = false;
      else
        x = x + 1;
      end
    end
end
