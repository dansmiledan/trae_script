function [L, clusterArrivals, clusterEnergies] = clusterization(environment, LOS, Lbar, Lambda, sigma_cluster, Gamma, randStream, dataType)
%CLUSTERIZATION Setup clusters
%   [L, CLUSTERARRIVALS, CLUSTERENERGIES] = clusterization(environment,
%   LOS, LBAR, LAMBDA, SIGMA_CLUSTER, GAMMA, RANDSTREAM) determines cluster
%   characteristics such as the number of clusters L, the arrival time (ns)
%   of each cluster (contained in vector CLUSTERARRIVALS), and the energy
%   of each cluster (contained in vector CLUSTERENERGIES). CLUSTERARRIVALS
%   and CLUSTERENERGIES are 1xL vectors, where L is the number of clusters.
%   RANDSTREAM is the global or internal random stream. DATATYPE can be
%   'double' or 'single'.
%
%   See also uwbChannel, lrwpan.uwb.internal.environmentConfig.

%   Copyright 2022-2023 The MathWorks, Inc.

%% Number of clusters:
singleAlternatePDP = ~LOS && any(strcmp(environment, {'Indoor office', 'Industrial'}));
if ~singleAlternatePDP
  L = max(1, lrwpan.uwb.internal.poissonRV(Lbar, randStream, dataType));
else
  L = ones(1, 1, dataType); % single PDP shape
end

%% Cluster arrival times:
if ~singleAlternatePDP  
  interarrivals = lrwpan.uwb.internal.exponentialRV(Lambda, randStream, 1, L, dataType);
  clusterArrivals = cumsum(interarrivals);                    % in ns
else
  clusterArrivals = zeros(1, 1, dataType); % single-cluster case
end 

%% Cluster energies:
if strcmp(environment, 'Residential') || (LOS && strcmp(environment, 'Industrial'))
  Mcluster = randn(randStream, 1, L, dataType) * sigma_cluster;      % cluster shadowing
  Mcluster = 10.^(Mcluster/10);                              % convert dB to linear scale
else
  Mcluster = ones(1, 1, dataType); % no-op
end

if ~singleAlternatePDP
  clusterEnergies = exp(-clusterArrivals/Gamma).*Mcluster;
else
  clusterEnergies = ones(1, 1, dataType);
end

end

