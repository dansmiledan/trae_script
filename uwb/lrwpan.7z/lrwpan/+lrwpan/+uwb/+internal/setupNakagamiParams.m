function [nakagamiM, state] = setupNakagamiParams(env, pathArrivalTimes, randStream, dataType)
%NAKAGAMIM Find the Nakagami M parameter for each path
%   M = nakagamiM(ENV, PATHARRIVAL, RANDSTREAM) returns a cell array
%   containing one element for each cluster, which in turn contains a
%   vector containing all the Nakagami M parameter for each path in that
%   cluster. ENV is a environmentConfig object, conveying the environment
%   parameterization. RANDSTREAM is the random stream object. DATATYPE can
%   be 'double' or 'single'.
%
%   See also uwbChannel, lrwpan.uwb.internal.environmentConfig.

%   Copyright 2022-2023 The MathWorks, Inc.

  L = numel(pathArrivalTimes); % 1xL cell array, each cell item contains all the paths for a cluster
  
  nakagamiM = cell(1, L);
  for clusterIdx = 1:L
    K_L = numel(pathArrivalTimes{clusterIdx});    % number of paths per cluster
    nakagamiM{clusterIdx} = zeros(1, K_L, dataType);
  end % init everything first, for codegen
  
  for clusterIdx = 1:L
    K_L = numel(pathArrivalTimes{clusterIdx});    % number of paths per cluster
    for pathIdx = 1:K_L
      if clusterIdx==1 && pathIdx == 1 && env.HasLOS && strcmp(env.Environment, 'Industrial') % only for 1st cluster of Industrial LOS, as per Sec. II.H
        % 1st component is modeled differently, independent of path delay, see Eq. (29) in [1]
        nakagamiM{clusterIdx}(pathIdx) = env.FirstPathNakagamiMFactor;
      else	
        mu_m    = env.NakagamiMeanOffset      - env.NakagamiMeanSlope     *pathArrivalTimes{clusterIdx}(pathIdx);    % Eq. (27) in [1]
        sigma_m = env.NakagamiDeviationOffset - env.NakagamiDeviationSlope*pathArrivalTimes{clusterIdx}(pathIdx);    % Eq. (28) in [1]
        nakagamiM{clusterIdx}(pathIdx) = exp(mu_m + randn(randStream, 1, 1) * sigma_m);             %  log-normal random variable
      end
    end
  end

  state = randStream.State; % offer this within the extrinsic call, to offer a const value

end