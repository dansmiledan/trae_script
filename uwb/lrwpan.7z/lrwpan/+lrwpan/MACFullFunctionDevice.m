classdef (StrictDefaults)MACFullFunctionDevice < lrwpan.MACDevice
%MACFULLFUNCTIONDEVICE IEEE 802.15.4 MAC Full Function Device (FFD)
%  Full Function Devices (FFD) in the IEEE 802.15.4 MAC can serve as PAN
%  Coordinators or as simple coordinators. The PAN Coordinator is the single
%  device responsible for coordinating the entire WPAN. Coordinators are
%  able to provide synchronization services. Moreover, an FFD can be the
%  only device with which a Reduced Function Device (RFD) is allowed to
%  communicate.
%
%  COORD = lrwpan.MACFullFunctionDevice creates a Full Function MAC Device
%  object.
% 
%  COORD = lrwpan.MACFullFunctionDevice(Name, Value) creates a Full
%  Function MAC Device object., with the specified property Name set to
%  the specified Value. You can specify additional name-value pair
%  arguments in any order as (Name1, Value1, ..., NameN, ValueN).
%
%  FullFunctionDevice properties:
% 
%  ExtendedAddress - 64-bit device address
%  ShortAddress    - 16-bit device address
%  PANCoordinator  - Option to serve as PAN Coordinator
%  PANIdentifier   - The ID of the coordinated PAN
%  BeaconEnabled   - Indication of beacon-enabled MAC selection
%  PhysicalLayer   - Indication of used PHY
%  SamplesPerChip  - Number of samples per symbol
%  CarrierSenseThreshold - Carrier sense threshold
%  Verbosity       - Option to print detailed activity
%
%  See also lrwpan.MACReducedFunctionDevice

%   Copyright 2017-2023 The MathWorks, Inc.
  
  properties
    %PANCoordinator Operation as a PAN Coordinator.
    % Specify PANCoordinator as a scalar logical. If true, the device
    % initiates its own WPAN and broadcasts beacons for other devices to
    % join. The default is false.
    PANCoordinator = false
  end
  properties (Dependent)
    %PANIdentifier The PAN ID
    % Specify PANIdentifier as a 4-character hexadecimal array denoting the
    % 16-bit address of the WPAN initiated by this device, when it operates
    % as a PAN Coordinator. The default is '0000'.
    PANIdentifier = '0000'
  end
  properties (Constant)
    %BeaconEnabled Option to enable the superframe structure
    BeaconEnabled = false;
    % Specify BeaconEnabled as a logical scalar. If true, a superframe
    % structure is used between beacons; it consists of an active period
    % and an inactive period. The active period comprises a contention
    % access period (CAP) and a contention free period (CFP) of guaranteed
    % time slots. If BeaconEnabled is set to false, beacons are not
    % transmitted periodically and the superframe structure is not used. In
    % this case, access follows an unslotted CSMA-CA mechanism.
  end
  properties
    %NumActiveSlots Number of slots in active period
    % Specify NumActiveSlots as a real scalar nonegative integer that is
    % either 0 or a power of 2, and not greater than 2^14. NumActiveSlots
    % specifies the length of the superframe's active period. The default
    % is 0.
    NumActiveSlots = 0;
    
    %BeaconInterval Duration of beacon interval
    % Specify BeaconInterval as a real scalar positive integer that is a
    % power of 2, and not greater than 2^14. This number expresses the
    % number of time slots separating successive beacons. The default is
    % 2^14.
    BeaconInterval = 2^14;
  end
  
  properties(Hidden)
    pDevices = {} % cell array of addresses; 1 address per row
    pBeaconSequenceNumber = 0
    pPendingTransmissions = {}
  end
  
  methods
    %CONSTRUCTOR
    function obj = MACFullFunctionDevice(varargin)
      obj@lrwpan.MACDevice(varargin{:}); % call base constructor
    end

    function set.PANIdentifier(obj, value)
      obj.pPANID = value;      
    end
    function value = get.PANIdentifier(this)
      value = this.pPANID;
    end
    
    function start(obj)
      obj.addBeaconToQueue();
    end
  
    function addBeaconToQueue(obj)
      cfg = lrwpan.MACFrameConfig('FrameType', 'Beacon');
      % Sequence number:
      obj.pBeaconSequenceNumber = mod(obj.pBeaconSequenceNumber + 1, 2^8);
      cfg.SequenceNumber = obj.pBeaconSequenceNumber;
      if ~obj.BeaconEnabled
        cfg.BeaconOrder = 15;
        cfg.SuperframeOrder = 15;
      else
        cfg.BeaconOrder = log2(obj.BeaconInterval);
        cfg.SuperframeOrder = log2(obj.NumActiveSlots);
      end
      cfg.BatteryLifeExtension = true;
      cfg.PANCoordinator = true;
      if strcmpi(obj.ShortAddress, 'FFFE')
        cfg.SourceAddressing = 'Extended address';
        cfg.SourceAddress = obj.ExtendedAddress;
      else
        cfg.SourceAddressing = 'Short address';
        cfg.SourceAddress = obj.ShortAddress;
      end
      cfg.SourcePANIdentifier = obj.PANIdentifier;
      cfg.GTSList = {};
      
      % If generated beacon sets PermitAssociation to true, then
      % processMPDU should be updated to drop beacon requests

      % Generate association request MAC frame:
      beaconFrame = lrwpan.MACFrameGenerator(cfg);

      topOfList = true;
      obj.enqueue(beaconFrame, cfg, topOfList);
      obj.myFprintf([obj.ShortAddress ': ********* Adding Beacon frame to the queue\n'])
    end
    
    function associationResponse(obj, cfgReq)

      cfgRes = lrwpan.MACFrameConfig('FrameType', 'MAC command', 'MACCommand', 'Association response');
      cfgRes.SequenceNumber = getAndIncreaseDataSequenceNumber(obj);
      cfgRes.SourceAddressing               = 'Extended address';
      cfgRes.DestinationAddressing          = 'Extended address';
      cfgRes.FramePending                   = false;
      cfgRes.AcknowledgmentRequest          = true;
      cfgRes.PANIdentificationCompression   = true;

      cfgRes.DestinationPANIdentifier       = obj.PANIdentifier;
      cfgRes.DestinationAddress             = cfgReq.SourceAddress;
      cfgRes.SourceAddress                  = obj.ExtendedAddress;

      cfgRes.AssociationStatus              = 'Successful';
      % Assign a (random) short address to the device:
      if cfgReq.AllocateAddress
        shortAddressDec = randi([0 2^16-3]); % -2 because 'FFFF' and 'FFFE' have special meaning
        cfgRes.ShortAddress                 = dec2hex(shortAddressDec, 4);
        device = cfgRes.ShortAddress;
      else
        cfgRes.ShortAddress                 = 'FFFE';
        % Device will need to use its extended address
        device = cfgRes.ExtendedAddress;
      end
      obj.pDevices = [obj.pDevices; device];
      
      % Add association response to the pending transmissions. According to
      % the standard it is transferred with an indirect transmission.
      assocResponseFrame        = lrwpan.MACFrameGenerator(cfgRes);
      obj.pPendingTransmissions = [obj.pPendingTransmissions; {assocResponseFrame, cfgReq.SourceAddress, cfgRes}];
      obj.myFprintf([obj.ShortAddress ': ********* Adding Data response frame to the PENDING queue\n'])
    end

  end
  
  methods (Access = protected)

    function resetImpl(obj)
      resetImpl@lrwpan.MACDevice(obj);
      
      obj.pDevices              = {};
      obj.pPendingTransmissions = {};
    end
    
    function cfg = processMPDU(obj, MPDU, frameEndInSymbols)
      cfg = processMPDU@lrwpan.MACDevice(obj, MPDU, frameEndInSymbols);
      
      if ~isempty(cfg) && strcmp(cfg.FrameType, 'MAC command')
        
        if strcmp(cfg.MACCommand, 'Beacon request') && ...
          (strcmpi(cfg.DestinationAddress, 'FFFF') || strcmpi(cfg.DestinationAddress, obj.ShortAddress))

          if ~obj.BeaconEnabled
            obj.addBeaconToQueue();
          % else the standard says to transmit a beacon as scheduled
          end

        elseif strcmp(cfg.MACCommand, 'Association request') && obj.PANCoordinator
          % also enter if PermitAssociation == true; currently not implemented
          % also sufficient resources are always assumed; all requests are granted

          % acknowledge frame
          framePending = true;
          obj.acknowledgeFrame(cfg, framePending);

          % add association response to queue
          obj.associationResponse(cfg);

        elseif strcmp(cfg.MACCommand, 'Data request')

          if isempty(obj.pPendingTransmissions)
            return
          end

          % acknowledge frame
          % find number of pending frames:
          indices = ismember({obj.pPendingTransmissions{:, 2}}, cfg.SourceAddress);
          numPending = sum(indices);
          framePending = numPending > 1;
          obj.acknowledgeFrame(cfg, framePending);

          if numPending == 0
            % no stored frames to send
            return;
          end

          % transmit first frame for this device
          firstIndex = find(indices, 1, 'first');
          firstFrame = obj.pPendingTransmissions{firstIndex, 1};

          obj.myFprintf([obj.ShortAddress ': Moving frame for %s from pending queue to the transmission queue\n'], cfg.SourceAddress)
          obj.enqueue(firstFrame, obj.pPendingTransmissions{firstIndex, 3});
          
          obj.pPendingTransmissions(firstIndex, :) = [];
        end
      end
    end
    
    function flag = isInputComplexityMutableImpl(~, ~)
        flag = true;
    end

    function flag = isInactivePropertyImpl(obj, prop)
      flag = false;
      
      if any(strcmp(prop, {'NumActiveSlots', 'BeaconInterval'}) )
        flag = ~obj.BeaconEnabled;
        
      elseif strcmp(prop, 'PANIdentifier')
        flag = ~obj.PANCoordinator;
      end
    end
    
  end
  
end

