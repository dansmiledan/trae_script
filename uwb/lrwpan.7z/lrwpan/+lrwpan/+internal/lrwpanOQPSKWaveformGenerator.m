function waveform = lrwpanOQPSKWaveformGenerator( MPDU, varargin )
%PHYGENERATOROQPSK Transmit-side O-QPSK physical layer of 802.15.4
%   WAVEFORM = PHYGENERATOROQPSK( MPDU ) uses 16-ary offset QPSK
%   (O-QPSK) to generate the physical-layer waveform WAVEFORM corresponding
%   to the MAC protocol data unit MPDU. A synchronization header is added,
%   comprising a preamble and a "start-of-frame" delimiter. The frame
%   length is also encoded. The MPDU bits are spread to chips, which are
%   subsequently O-QPSK modulated and filtered.
%
%   See also lrwpanOQPSKConfig, LRWPAN.PHYDECODEROQPSK,
%   LRWPAN.PHYDECODEROQPSKNOSYNC, LRWPAN.PHYGENERATORBPSK,
%   LRWPAN.PHYGENERATORASK, LRWPAN.PHYGENERATORGFSK

%   Copyright 2017-2023 The MathWorks, Inc.

%#codegen

persistent rcosfilt780 rcosfilt868 % Persistent raised cosine filter, as one-time setup is the computational bottleneck

reservedValue = 0;

% OSR
if nargin >= 2
  OSR = varargin{1};
else
  OSR = 4;
end
% frequency band specification
if nargin == 3
  band = varargin{2};
else
  band = 2450;
end

if any(band == [2380, 2450])
  chipLen = 32;    
  % See Table 73 in IEEE 802.15.4,  2011 revision
  chipMap = ...
     [1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0;
      1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0;
      0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0;
      0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1;
      0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1;
      0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0;
      1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1;
      1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1;
      1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1;
      1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1;
      0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1;
      0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0;
      0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0;
      0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1;
      1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0;
      1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0];
else
  chipLen = 16;
  % See Table 74 in IEEE 802.15.4,  2011 revision
  chipMap =  [0 0 1 1 1 1 1 0 0 0 1 0 0 1 0 1;
              0 1 0 0 1 1 1 1 1 0 0 0 1 0 0 1;
              0 1 0 1 0 0 1 1 1 1 1 0 0 0 1 0;
              1 0 0 1 0 1 0 0 1 1 1 1 1 0 0 0;
              0 0 1 0 0 1 0 1 0 0 1 1 1 1 1 0;
              1 0 0 0 1 0 0 1 0 1 0 0 1 1 1 1;
              1 1 1 0 0 0 1 0 0 1 0 1 0 0 1 1;
              1 1 1 1 1 0 0 0 1 0 0 1 0 1 0 0;
              0 1 1 0 1 0 1 1 0 1 1 1 0 0 0 0;
              0 0 0 1 1 0 1 0 1 1 0 1 1 1 0 0;
              0 0 0 0 0 1 1 0 1 0 1 1 0 1 1 1;
              1 1 0 0 0 0 0 1 1 0 1 0 1 1 0 1;
              0 1 1 1 0 0 0 0 0 1 1 0 1 0 1 1;
              1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0;
              1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0;
              1 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1];
end


%% Synchronization header (SHR)

% Preamble is 4 octets, all set to 0.
preamble = zeros(4*8, 1);

% Start-of-frame delimiter (SFD)
SFD = [1 1 1 0 0 1 0 1]'; % value from standard (see Fig. 68, IEEE 802.15.4, 2011 Revision)

SHR = [preamble; SFD];

%% PHY Header (PHR)
frameLength = int2bit(length(MPDU)/8, 7, false);
PHR = [frameLength; reservedValue];

%% PHY protocol data unit:
PPDU = [SHR; PHR; MPDU];

% pre-allocate matrix for performance
chips = zeros(chipLen, length(PPDU)/4);
for idx = 1:length(PPDU)/4
  %% Bit to symbol mapping
  currBits = PPDU(1+(idx-1)*4 : idx*4);
  symbol = bit2int(currBits, 4, false);
  
  %% Symbol to chip mapping                            
	chips(:, idx) = chipMap(1+symbol, :)'; % +1 for 1-based indexing
end

%% O-QPSK modulation (part 1)
% split two 2 parallel streams, also map [0, 1] to [-1, 1]
oddChips  = chips(1:2:end)*2-1;
evenChips = chips(2:2:end)*2-1;


%% Filtering

% Filtering from standard (see Sec. 10.2.6, IEEE 802.15.4, 2011 Revision)
rrcInputOdd  = oddChips;  % not always needed, but declaring for codegen
rrcInputEven = evenChips;
if band ~= 780
  
  % Half-sine pulse filtering for 868 MHz, 915 MHz, 2450 MHz
  pulse = sin(0:pi/OSR:(OSR-1)*pi/OSR); % Half-period sine wave
  filteredReal = pulse' * oddChips;     % each column is now a filtered pulse
  filteredImag = pulse' * evenChips;    % each column is now a filtered pulse  
  
  if band == 868
    rrcInputOdd  = filteredReal(1, :); % indexing to help codegen
    rrcInputEven = filteredImag(1, :);
  end

else % if band == 780

  % Raised cosine pulse filtering: RRC is the only filtering for 780 MHz. 
  if coder.target('MATLAB')
    if isempty(rcosfilt780)
      rcosfilt780 = comm.RaisedCosineTransmitFilter('RolloffFactor', 0.8, ...
                'OutputSamplesPerSymbol', OSR, 'Shape', 'Normal');
    elseif rcosfilt780.OutputSamplesPerSymbol ~= OSR
      release(rcosfilt780);
      rcosfilt780.OutputSamplesPerSymbol = OSR;
    end
    filtered = rcosfilt780(rrcInputOdd' + 1i*rrcInputEven');
    filteredReal = real(filtered);
    filteredImag = imag(filtered);
    reset(rcosfilt780); % reset persistent variable
  else
    % codegen
    [filteredReal, filteredImag] = rrcFilterCodegen(OSR, rrcInputOdd' + 1i*rrcInputEven');
  end
end

if band == 868
  % For 868 MHz, both half-sine and RRC filtering are combined.
  % Repeat because of codegen
  if isempty(rcosfilt868)
    % oversampling happened during half-sine filtering; here only spectral mask needs to be applied
    rcosfilt868 = comm.RaisedCosineTransmitFilter('RolloffFactor', 0.2, ...
                'OutputSamplesPerSymbol', 1, 'Shape', 'Normal');
  end
  filtered = rcosfilt868(rrcInputOdd' + 1i*rrcInputEven');
  filteredReal = real(filtered);
  filteredImag = imag(filtered);
  reset(rcosfilt868); % reset persistent variable
end


%% O-QPSK modulation (part 2)
re = [filteredReal(:);         zeros(round(OSR/2), 1)];
im = [zeros(round(OSR/2), 1);  filteredImag(:)];
waveform = complex(re, im);


function [x, y] = rrcFilterCodegen(OSR, filterIn)
  
    % OutputSamplesPerSymbol must be constant 
    switch OSR
      case 2
        rrcFilt2 = comm.RaisedCosineTransmitFilter('RolloffFactor', 0.8, ...
                'OutputSamplesPerSymbol', 2, 'Shape', 'Normal');
        filt2 = rrcFilt2(filterIn);
        x = real(filt2);
        y = imag(filt2);
      case 4
        rrcFilt4 = comm.RaisedCosineTransmitFilter('RolloffFactor', 0.8, ...
                'OutputSamplesPerSymbol', 4, 'Shape', 'Normal');
        filt4 = rrcFilt4(filterIn);
        x = real(filt4);
        y = imag(filt4);
      case 6
        rrcFilt6 = comm.RaisedCosineTransmitFilter('RolloffFactor', 0.8, ...
                'OutputSamplesPerSymbol', 6, 'Shape', 'Normal');
        filt6 = rrcFilt6(filterIn);
        x = real(filt6);
        y = imag(filt6);
      case 8
        rrcFilt8 = comm.RaisedCosineTransmitFilter('RolloffFactor', 0.8, ...
                'OutputSamplesPerSymbol', 8, 'Shape', 'Normal');
        filt8 = rrcFilt8(filterIn);
        x = real(filt8);
        y = imag(filt8);
      case 10
        rrcFilt10 = comm.RaisedCosineTransmitFilter('RolloffFactor', 0.8, ...
                'OutputSamplesPerSymbol', 10, 'Shape', 'Normal');
        filt10 = rrcFilt10(filterIn);
        x = real(filt10);
        y = imag(filt10);
      otherwise
        coder.internal.error('lrwpan:LRWPAN:SpsCodegen');
    end
end

end