function [wave, symbols] = lrwpanHRPWaveformGenerator(PSDU, cfg)
%LRWPANHRPWAVEFORMGENERATOR Create IEEE 802.15.4a/z HRP UWB waveforms
% WAVE = LRWPANHRPWAVEFORMGENERATOR(PSDU, CFG) creates an HRP (high rate pulse
% repetition frequency) ultra-wide band waveform WAVE as per the IEEE
% 802.15.4a/z standard. CFG must be an <a
% href="matlab:help('lrwpanHRPConfig')">lrwpanHRPConfig</a> object. WAVE is
% either an HRPF (higher pulse repetition frequency), BPRF (base pulse
% repetition frequency) or an IEEE 802.15.4a waveform, according to the
% Mode property of the input configuration object CFG.
%
% PSDU is the PHY protocol data unit, which is provided by the upper (MAC)
% layer. Its length must be an integer multiple of 8 and must be no greater
% than 1016 for the BPRF and 802.15.4a modes, and no greater than 32760 for
% the HPRF mode. An empty PSDU ([]) is allowed. In all cases, the length of
% the PSDU must match the value of the PSDULength property in the CFG
% configuration object.
%
% [WAVE, SYMBOLS] = LRWPANHRPWAVEFORMGENERATOR(PSDU, CFG) also returns the HRP
% signal before pulse shaping, i.e., after modulation (symbol mapping) and
% after the preamble insertion.
%
%   See also lrwpanHRPConfig.

%   Copyright 2021-2024 The MathWorks, Inc.

%#codegen

validateConfig(cfg);
% validate PSDU length:
if strcmp(cfg.Mode, 'HPRF')
  numLenBits = 12;
else % BPRF, 15.4a
  numLenBits = 7;
end
PSDUlen = length(PSDU);

coder.internal.errorIf(PSDUlen > 8*(2^numLenBits-1), ...
  'lrwpan:LRWPAN:InvalidMPDULength', 8*(2^numLenBits-1));

if PSDUlen ~= 8*cfg.PSDULength
  coder.internal.warning('lrwpan:LRWPAN:PSDULenMismatchTX', PSDUlen, 8*cfg.PSDULength);
  PSDUlen = min(PSDUlen, 8*cfg.PSDULength);
  PSDU = PSDU(1:PSDUlen);
end
coder.internal.errorIf(cfg.SamplesPerPulse==1, 'lrwpan:LRWPAN:OSR1');

if strcmp(cfg.Mode, '802.15.4a') || cfg.STSPacketConfiguration ~= 3
  % In BPRF/HPRF modes, payload and PHR can be omitted and only STS transmitted
  
  %% 1. Reed-Solomon Encoding for the PSDU
  if ~strcmp(cfg.Mode, 'HPRF') || cfg.ConstraintLength ~= 7
    encoding = true;
    rsPSDU = lrwpan.internal.hrpRS(PSDU, encoding);
  else
    % no RS encoding when HPRF and constraint length = 7
    rsPSDU = PSDU;
  end

  %% 2. PHY Header and SECDED encoding
  PHR = createPHRwithSECDED(PSDUlen, cfg);

  %% 3. Convolutional Encoding
  convolCW = convolEnc(PHR, rsPSDU, cfg);

  %% 4. Symbol Mapper (Modulation)
  symbols = symbolMapper(convolCW, cfg);
else
  symbols = [];
end

%% 5. Preamble Insertion
SHR = createSHR(cfg);

%% 6. STS (Srambled Timestamp Sequence)
if ~strcmp(cfg.Mode, '802.15.4a') && cfg.STSPacketConfiguration ~= 0
  % STS only applies for BRPF/HPRF modes; when STS configuration is 1, 2 or 3
  STS = createSTS(cfg);  
  
  switch cfg.STSPacketConfiguration
    case 1
      symbols = [SHR; STS; symbols];
    case 2
      symbols = [SHR; symbols; STS];
    case 3
      symbols = [SHR; STS];
  end
else
  % No STS
  symbols = [SHR; symbols];
end
wave = complex(butterworthFilter(symbols, cfg.SamplesPerPulse));


%% Subfunctions:

%% 2. PHY Header and SECDED encoding
function phr = createPHRwithSECDED(PSDUlen, cfg)
% As per Sec. 15.2.7 in IEEE Std 802.15.4™‐2020

HPRF = strcmp(cfg.Mode, 'HPRF');

phr = zeros(13, 1);

if ~HPRF
  % 1. Data Rate
  rate = cfg.DataRateNum;
  if rate == 110
    phr(1:2) = [0; 0];
  elseif rate == 850
    phr(1:2) = [0; 1];
  elseif (rate == 6810 && cfg.MeanPRFNum ~= 3.9) || (rate == 1700 && cfg.MeanPRFNum == 3.9)
    phr(1:2) = [1; 0];
  elseif (rate == 27240 && cfg.MeanPRFNum ~= 3.9) || (rate == 6810 && cfg.MeanPRFNum == 3.9)
    phr(1:2) = [1; 1];
  % else error thrown by validateConfig
  end

  % 2. Frame Length
  len = PSDUlen/8;
  phr(3:9) = int2bit(len, 7);

  % 3. Ranging
  phr(10) = double(cfg.Ranging);

  % 4. Reserved
  phr(11) = 0;

  % 5. Preamble Duration
  preambleLen = cfg.PreambleDuration;
  if preambleLen == 16
    phr(12:13) = [0; 0];
  elseif preambleLen == 64
    phr(12:13) = [0; 1];
  elseif preambleLen == 1024
    phr(12:13) = [1; 0];
  elseif preambleLen == 4096
    phr(12:13) = [1; 1];
  % else not allowed by lrwpanHRPConfig
  end
  
else % HPRF  
  
  len = PSDUlen/8;
  if cfg.STSPacketConfiguration==2 && (cfg.ExtraSTSGapIndex>0 || cfg.ExtraSTSGapLength>0)
    phr(1:2) = int2bit(cfg.ExtraSTSGapIndex, 2);
  else
    phr(1) = bitget(len, 12);  % A1
    phr(2) = bitget(len, 11);  % A0
  end
  
  
  % 2. Payload length
  % call bitget to fetch 10 least significant bits, fliplr for left-msb
  phr(3:12) = fliplr(bitget(len, 1:10));
  
  % 3. Ranging:
  phr(13) = double(cfg.Ranging);
end

% END. Hamming coding - SECDED, i.e., Single error correction, double error detection
phr = lrwpan.internal.hrpSECDED(phr);

%% 3. Convolutional Encoding
function convolCW = convolEnc(PHR, rsPSDU, cfg)
% As per Sec. 15.3.3.3 in IEEE Std 802.15.4™‐2020

% Two zeros for ConstraintLength = 3, six for length = 7
tailField = zeros(cfg.ConstraintLength-1, 1);

if cfg.ConvolutionalCoding
  if ~strcmp(cfg.Mode, 'HPRF') || cfg.ConstraintLength == 3
    % Table 15-1
    convolIn = [PHR; rsPSDU; tailField];
    
  else % CL = 7
    % Sec. 15.3.3.3 in 15.4z: "separately appending six zero bits to both the PHR and the PSDU"
    convolIn = [PHR; tailField; rsPSDU; tailField];
  end
else
  % Table 15-2 (Part 1)
  % No PSDU coding for some cases, as per Table 15-3
  % PHR is always convolutionally encoded
  convolIn = [PHR; tailField];
end

% Rate 1/2 coding:
if ~(strcmp(cfg.Mode, 'HPRF') && cfg.ConstraintLength == 7)
  % Constraint length 3, as in 15.3.3.3 in 15.4a 
  trellis3 = poly2trellis(3, [2 5]);
  convolCW = convenc(convolIn, trellis3);
else
  % Constraint length 7, as in 15.3.3.3 in 15.4z amendment
  trellis7 = poly2trellis(7, [133 171]);
  convolCW = convenc(convolIn, trellis7);  % repeat for codegen
end

if ~cfg.ConvolutionalCoding
  % Table 15-2 (Part 2)
  % Pass the PSDU further, without any convolutional coding
  convolCW = [convolCW; rsPSDU];
end


%% 4. Symbol Mapper (Modulation)
function symbols = symbolMapper(convolCW, cfg)
% As per Sec. 15.3 in IEEE Std 802.15.4™‐2020

persistent pn % Persistent comm.PNSequence, as one-time setup is the computational bottleneck

% 0. Repackage input with 1 codeword per row
tmp = reshape(convolCW, 2, []);
cws = tmp';
numSym = size(cws, 1);
inHPRF = strcmp(cfg.Mode, 'HPRF');

phrLen = 19;
if ~inHPRF || cfg.ConstraintLength == 3
  numPHRsym = phrLen+2;
else % CL = 7 
  numPHRsym = phrLen+6;
end

% 2. Create spreading sequence obj
code = lrwpan.internal.HRPCodes(cfg.CodeIndex);
codeHat = code;
% a. Remove all zeros
codeHat(codeHat==0) = [];
% b. Replace all -1 with zeros
codeHat(codeHat==-1) = 0;
% c. Keep the 1st 15
codeHat = codeHat(1:15);
initialConditions = fliplr(codeHat); % fliplr because of the difference in convention

% do a single PN sequence call, to facilitate codegen (pass InitialConditions and SamplesPerFrame as inputs)
if ~inHPRF
  numChips = cfg.ChipsPerBurst;
else
  numChips = cfg.ChipsPerSymbol;
end
s = info(cfg);
if inHPRF || numChips(end) >= log2(s.NumHopBursts)
  numPNSym = numSym;
else
  % do as many extra clockings to guarantee sufficient burst pos calculation
  numPNSym = numSym + ceil( (log2(s.NumHopBursts)-numChips(end))/numChips(end) );
end

totalSamples = numPHRsym*numChips(1) + (numPNSym-numPHRsym)*numChips(end);
% The maximum value of totalSamples under all configurations is about 600K.
maxSamples = 6.1e5;

% A different notation is used between standard and comm.PNSequence. The
% standard has the extra connection (D^14) close to the register that is
% wrapped around, which is D^1 for comm.PNSequence
if isempty(pn)
  pn = comm.PNSequence(Polynomial = '1 + D + D15', ...
    InitialConditionsSource = 'Input port', ...
    VariableSizeOutput=true, ...
    MaximumOutputSize=[maxSamples 1], ...
    Mask = 15); % Skip the first 15 (initial conditions), see example in Table 15-10
end

allPNSamples = pn(initialConditions, totalSamples);
reset(pn);  % prepare for next-function call

% 3. Modulate each codeword/symbol
% 3a. The first 21 symbols (PHR) is modulated at most at 850 kb/s = at least 16 chips per burst
% 3b. The rest (numSym-21) are modulated with cfgObj.DataRate
samplesPerBurst = nan; % init in all code paths, for codegen
if ~inHPRF
  samplesPerBurst = cfg.ChipsPerBurst;
  sps = cfg.BurstsPerSymbol*samplesPerBurst;
else
  sps = cfg.ChipsPerSymbol*2*249.6/cfg.MeanPRFNum;
end
% sps is a 1 or 2-element vector. If 2-element, 1st value is for PHR, 2nd is for PSDU
PHRorPSDU = 1;
PHR_ID = 1;
PSDU_ID = length(sps);
symbols = zeros(numPHRsym*sps(PHR_ID)+(numSym-numPHRsym)*sps(PSDU_ID), 1);

for symIdx = 1:numSym
  % Transition from PHR to PSDU. If rates are different, then PN sequence
  % needs different parameterization
  if ((inHPRF && cfg.ConstraintLength == 3) || (~inHPRF && ~isscalar(cfg.ChipsPerBurst))) && symIdx == numPHRsym+1
    PHRorPSDU = 1+double(symIdx>numPHRsym);
  end
  
  % Get each codeword one by one and construct each symbol one by one
  if PHRorPSDU == 1
    offset = 0;
    currSym = symIdx;
  else
    offset = numPHRsym*numChips(1);
    currSym = symIdx-numPHRsym;
  end
  thisStart = offset+1+(currSym-1)*numChips(PHRorPSDU);
  spreadingSeq = allPNSamples(thisStart: thisStart+numChips(PHRorPSDU)-1, 1);
  systematicBit = cws(symIdx, 1);
  parityBit     = cws(symIdx, 2);
  
  thisSymbol = zeros(sps(PHRorPSDU), 1);

  if ~inHPRF
    % 3. Calculate burst hopping position
    m = log2(cfg.NumHopBursts);
    % Standard says that LFSR is not clocked more than ChipsPerBurst times,
    % when m > Ncpb; in this case PN chips from next symbol will be used
    spreadingSeqForPos = allPNSamples(thisStart: thisStart+m-1, 1);
    burstPos = (2.^(0:m-1))*spreadingSeqForPos(1:m);

    % 4. Create burst
    thisBurst = (1-2*parityBit)*(1-2*spreadingSeq');
    thisBurst = thisBurst(:);

    % 5. Place burst in the corresponding position
    burstNo = burstPos(1) + systematicBit*cfg.BurstsPerSymbol/2; % 0-based index; also, burstPos is scalar, but (1) helps codegen
    thisSymbol(1+burstNo*samplesPerBurst(PHRorPSDU):(burstNo+1)*samplesPerBurst(PHRorPSDU)) = thisBurst;
    
  else % HPRF
    len = 4*249.6/cfg.MeanPRFNum;
    symbolMap = lrwpan.internal.hrpHPRFSymbolMap(cfg.MeanPRFNum, cfg.ConstraintLength);
    
    if PHRorPSDU == 1 % PHR
      numBits = size(symbolMap, 2);
    else % PSDU
      numBits = 2*len;
    end
    
    thisMapping = symbolMap(1+bit2int([systematicBit parityBit]', 2, false), 1:numBits);
    scrambled = (1-2*thisMapping) .* (1-2*spreadingSeq');
    
    % add guardbands:
    scrambled = [reshape(scrambled, len, []); ...
                 zeros(len, numBits/len)];
    scrambled = scrambled(:);
    
    if cfg.MeanPRFNum == 124.8
        % add a zero every other element
        scrambled = [scrambled'; 
                     zeros(1, numBits*2)];
        scrambled = scrambled(:);
    end
    thisSymbol = scrambled';
    thisSymbol = thisSymbol(:);
  end
  if PHRorPSDU == 1 % PHR
    startSymbolPos = 1+(symIdx-1)*sps(PHR_ID);
  else % PSDU
    phrEnd = numPHRsym*sps(PHR_ID);
    startSymbolPos = phrEnd + 1 +(symIdx-1-numPHRsym)*sps(PSDU_ID);
  end
  endSymbolPos = startSymbolPos + sps(PHRorPSDU)-1;
  symbols(startSymbolPos:endSymbolPos) = thisSymbol;
end



%% 5. Preamble Insertion
function SHR = createSHR(cfg)

%% SYNC
% As per Sec. 15.2.6.2 in IEEE Std 802.15.4™‐2020
code = lrwpan.internal.HRPCodes(cfg.CodeIndex);
L = cfg.PreambleSpreadingFactor;
N = cfg.PreambleDuration;

% 1. Add L-1 zeros after each ternary (-1, 0, +1) symbol of the code
spread = zeros(L*length(code), 1);
spread(1:L:end) = code;

% 2. Repeat spread sequence N times (spread seq is also referred as a symbol)
SYNC = repmat(spread, N, 1);


%% SFD (Start of Frame delimiter)
% As per Sec. 15.2.6.3 in IEEE Std 802.15.4™‐2020
seq = lrwpan.internal.getSFD(cfg);
SFD = seq.*spread;
SFD = SFD(:);

SHR = [SYNC; SFD];


%% %% 6. STS (Srambled Timestamp Sequence)
function STS = createSTS(cfg)
% As per Sec. 15.2.9 in IEEE Std 802.15.4z™‐2020

len512 = 512; % chips
gap = zeros(len512, 1);
STS = gap; % all STS start with a gap

if strcmp(cfg.Mode, 'HPRF') && cfg.STSPacketConfiguration == 2
  % add extra gap
  STS = [STS; zeros(4*cfg.ExtraSTSGapLength, 1)];
end

if strcmp(cfg.Mode, 'BPRF') % BPRF
  numSegments = 1;
  segLen = 64*512; % STSSegmentLength is in units of 512 chips
  spreadingF = 8;
else % HPRF
  numSegments = cfg.NumSTSSegments;
  segLen = cfg.STSSegmentLength*512; % STSSegmentLength is in units of 512 chips
  spreadingF = 4;
end

singleDRBGlen = 128;

% Get DRBG bits already prepared for:
% key='4a5572bc90798c8e518d2449092f1b55',
% upper96 = '68debd3a599939dd57fdbb0e'
% lower32 = '2a10fac0'
% They are packed as uint8, so convert to bits:
s = coder.load('allDRBG_STS.mat');
allDRBG = s.allDRBG;

counter = 1;

for idx = 1:numSegments
  activeSTS = zeros(segLen, 1);
  
  numDBRG = (segLen/(singleDRBGlen*spreadingF));
  for idx2 = 1:numDBRG
    
    singleDRBG_uint8 = allDRBG(counter, :);
    tmp = int2bit(singleDRBG_uint8, 8);
    singleDRBG = double(tmp(:));
    
    % Change 0s to +1 and 1 to -1:
    singleDRBG(singleDRBG==1) = -1;
    singleDRBG(singleDRBG==0) = +1;
    
    % Spread by spreadingFactor (4 or 8):    
    spreadBits = [singleDRBG'; zeros(spreadingF-1, singleDRBGlen)];
    spreadBits = spreadBits(:);
    
    activeSTS(1+(idx2-1)*singleDRBGlen*spreadingF : idx2*singleDRBGlen*spreadingF) = spreadBits;

    counter = counter+1;
  end
  STS = [STS; activeSTS; gap]; %#ok<AGROW>
end


%% 7. Pulse shaping
function wave = butterworthFilter(symbols, spc)

% 1. Create a 4th-order Butterworth filter with 3-db bandwidth (cutoff) at 500 MHz
N = 4;
Fc = 500e6;
Fs = Fc*spc;
[b,a] = butter(N, Fc/Fs);

% 2. Pass impulses to the Butterworth filter to create Butterworth pulses
impulses = zeros(length(symbols)*spc, 1);
impulses(1:spc:end) = symbols;
wave = filter(b, a, impulses);
