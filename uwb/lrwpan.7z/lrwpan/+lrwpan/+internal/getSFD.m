function SFD = getSFD(cfg)
%lrwpan.internal.getSFD Get the applicable SFD sequence
%  SFD = lrpwan.internal.getSFD(CFG) returns the SFD sequence that applies
%  for the given operational mode (HPRF, BPRF, or 802.15.4a) and SFD index
%  or data rate, as specified in the input <a
%  href="matlab:help('lrwpanHRPConfig')">lrwpanHRPConfig</a> object CFG.
%  The length of the output sequence SFD is either 4, 8, 16, 32 or 64
%  symbols long.

%   Copyright 2021-2023 The MathWorks, Inc.

%#codegen

if ~strcmp(cfg.Mode, '802.15.4a')
  % Table 15-7c
  switch cfg.SFDNumber
    case 0
    	SFD = [0 +1 0 -1 +1 0 0 -1]; % legacy
    case 1
      SFD = [-1 -1 +1 -1];
    case 2
      SFD = [-1 -1 -1 +1 -1 -1 +1 -1];
    case 3
      SFD = [-1 -1 -1 -1 -1 +1 +1 -1 -1 +1 -1 +1 -1 -1 +1 -1];
    otherwise % case 4
      SFD = [-1 -1 -1 -1 -1 -1 -1 +1 -1 -1 +1 -1 -1 +1 -1 +1 -1 +1 ...
-1 -1 -1 +1 +1 -1 -1 -1 +1 -1 +1 +1 -1 -1];
  end  
  
else % 15.4a
  % Sec. 15.2.6.3
  if cfg.DataRateNum ~= 110
    SFD = [0 +1 0 -1 +1 0 0 -1]; % short SFD
  else % long SFD
    SFD = [0 +1 0 -1 +1 0 0 -1 0 +1 0 -1 +1 0 0 -1 -1 0 0 +1 0 -1 0 +1 0 +1 0 ...
      0 0 -1 0 -1 0 -1 0 0 +1 0 -1 -1 0 -1 +1 0 0 0 0 +1 +1 0 0 -1 -1 -1 +1 -1 ...
      +1 +1 0 0 0 0 +1 +1];
  end
end
