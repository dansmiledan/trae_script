function OSR = generatorValidation(MPDU, nargs, vargs)

%   Copyright 2017-2023 The MathWorks, Inc.

reservedValue = 0;

% binary input:
validateattributes(MPDU, {'numeric'}, {'binary'}, '', 'MPDU');

% input must be processed in octets
len = length(MPDU);
if mod(len, 8) ~= 0 || len > 8*(2^7-1)
  error(message('lrwpan:LRWPAN:InvalidMPDULength', 8*(2^7-1)));
end

% frame lengths 0-4 and 6-8 are reserved, i.e., all bits must be zeros
if len ~= 5 && len < 9 && any( MPDU ~= reservedValue )
  error(message('lrwpan:LRWPAN:InvalidMPDU'));
end

OSR = lrwpan.internal.osrValidation(nargs, vargs);
