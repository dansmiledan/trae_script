function OSR = osrValidation(nargs, vargs)

%   Copyright 2017-2023 The MathWorks, Inc.

% OSR specification
if nargs >= 2
  OSR = vargs{1};
  validateattributes(OSR, {'numeric'}, {'integer', 'positive', 'scalar', 'real'}, '', 'OSR');
else
  OSR = 10;
end
