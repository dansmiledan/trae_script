function MPDU = PHYDecoderBPSK( waveform, varargin )
%PHYDECODERBPSK Receive-side BPSK physical layer of 802.15.4
%   MPDU = PHYDECODERBPSK( waveform ) decodes a BPSK-modulated PPDU (PHY
%   protocol data unit). The waveform is filtered with a raised cosine
%   filter, and BPSK-demodulated. The chips are mapped to bits, which are
%   subsequently differentially decoded.
%
%   See also LRWPAN.PHYGENERATORBPSK, LRWPAN.PHYDECODEROQPSKNOSYNC, LRWPAN.PHYDECODERASK,
%   LRWPAN.PHYDECODERGFSK

%   Copyright 2017-2023 The MathWorks, Inc. 

% OSR specification
OSR = lrwpan.internal.osrValidation(nargin, varargin);

%% Raised cosine filtering
persistent rcosfilt % Persistent raised cosine filter, as one-time setup is the computational bottleneck
if isempty(rcosfilt)
  rcosfilt = comm.RaisedCosineReceiveFilter('RolloffFactor', 1, ...
            'InputSamplesPerSymbol', OSR, 'DecimationFactor', OSR, 'Shape', 'Normal');
          
elseif rcosfilt.InputSamplesPerSymbol ~= OSR
  release(rcosfilt);
  rcosfilt.InputSamplesPerSymbol = OSR;
  rcosfilt.DecimationFactor = OSR;
end
delay = rcosfilt.FilterSpanInSymbols;
paddedWaveform = [waveform; zeros(delay*OSR, 1)];
filtered = rcosfilt(paddedWaveform);
filtered = filtered(1+delay:end);
reset(rcosfilt); % reset persistent variable


%% BPSK demodulation
iniPhase = pi; % 1 for positive pulse, 0 for negative pulse
demodulated = pskdemod(filtered, 2, iniPhase);

%% Chip to bit mapping
chips = [1 1 1 1 0 1 0 1 1 0 0 1 0 0 0;  % Chip for 0 bit
         0 0 0 0 1 0 1 0 0 1 1 0 1 1 1]; % Chip for 1 bit
chipLen = length(chips);
bits = zeros(length(demodulated)/chipLen, 1);
for idx = 1:length(demodulated)/chipLen
  thisChip = demodulated(1+(idx-1)*chipLen : idx*chipLen);
  % find the bit corresponding to the closest chip sequence:
  [~, bits(idx)] = min(sum(xor(thisChip, chips')));
end
bits = bits - 1; % map 1-based indexing to 0s and 1s

%% Differential decoding
diffDec = comm.DifferentialDecoder();
diffBits = diffDec(bits);

%% Remove headers, output MPDU (MAC protocol data unit)
preambleLen = 4*8;  % 4 octets
SFDLen = 8;         % 1 octet
PHRLen = 8;         % 1 octet
offset = preambleLen + SFDLen + PHRLen;
MPDU = diffBits(1+offset:end);