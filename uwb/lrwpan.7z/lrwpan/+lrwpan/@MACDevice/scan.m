function scan(obj, isActive, scanDuration)

%   Copyright 2017-2023 The MathWorks, Inc. 

  if isActive
    cfg = lrwpan.MACFrameConfig('FrameType', 'MAC command', 'MACCommand', 'Beacon request');
    cfg.SequenceNumber = getAndIncreaseDataSequenceNumber(obj);
    
    cfg.SourceAddressing = 'Not present';
    cfg.DestinationAddressing = 'Short address';
    cfg.DestinationPANIdentifier = 'FFFF';
    cfg.DestinationAddress = 'FFFF';
    cfg.FramePending = false;
    cfg.AcknowledgmentRequest = false;
    cfg.Security = false;
    
    beaconReqFrame = lrwpan.MACFrameGenerator(cfg);
    obj.enqueue(beaconReqFrame, cfg, true);
    obj.myFprintf([obj.ShortAddress ': ********* Adding Beacon Request frame to the queue\n']);
    obj.pScanningState = 'Pending transmission';
  else
    obj.pScanningState = 'Pre-scanning';
    obj.pScanningResults = [];
  end
  % each base slot duration is 60 symbols which is 3 times the backoff
  % duration, i.e., 3 steps
  obj.pScanSteps = obj.NUMSTEPSPERBASESLOT * obj.NUMSUPERFRAMESLOTS * (2^scanDuration + 1);
  obj.myFprintf([obj.ShortAddress ': Passive scanning for %d steps\n'], obj.pScanSteps);
end