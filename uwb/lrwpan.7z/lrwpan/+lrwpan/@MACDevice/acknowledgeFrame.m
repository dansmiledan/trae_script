function acknowledgeFrame(obj, cfgFrame, framePending)

%   Copyright 2017-2023 The MathWorks, Inc. 

  cfgAck = lrwpan.MACFrameConfig('FrameType', 'Acknowledgment');
  cfgAck.SequenceNumber         = cfgFrame.SequenceNumber;
  cfgAck.DestinationAddressing  = 'Not present';
  cfgAck.SourceAddressing       = 'Not present';
  cfgAck.FramePending           = framePending;
  cfgAck.Security               = false;

  ackFrame = lrwpan.MACFrameGenerator(cfgAck);
  obj.myFprintf([obj.ShortAddress ': ********** Directly transmitting acknowledgement frame (no CSMA/CA)\n']);
  obj.directTransmission(ackFrame, cfgAck);
end

