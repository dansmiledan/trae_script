function processPendingAck(obj)
  
%   Copyright 2017-2023 The MathWorks, Inc.

if ~isempty(obj.pUnaknowledgedFrame)
  if obj.pAckWaitDuration <= 0
    % need to retransmit frame
    obj.myFprintf([obj.ShortAddress ': No acknowledgement within %d symbols.\n'], obj.pMAXAckWaitDuration);
        
    obj.pNumFrameReTries = obj.pNumFrameReTries + 1;
    if obj.pNumFrameReTries <= obj.MACMAXFRAMERETRIES
      obj.myFprintf([obj.ShortAddress ': Retransmitting. Attempt #%d\n'], obj.pNumFrameReTries + 1);
      if ~strcmp(obj.pUnaknowledgedFrame.FrameType, 'Data')
        unAckFrame = lrwpan.MACFrameGenerator(obj.pUnaknowledgedFrame);
      else
        unAckFrame = lrwpan.MACFrameGenerator(obj.pUnaknowledgedFrame, obj.pUnaknowledgedPayload);
      end
      obj.enqueue(unAckFrame, obj.pUnaknowledgedFrame);
    else
      obj.myFprintf([obj.ShortAddress ': Reached maximum number of transmission attempts (%d). Giving up.\n'], obj.MACMAXFRAMERETRIES);
      obj.pNumFrameReTries = 0;
    end
    obj.pUnaknowledgedFrame = [];
  else
    obj.pAckWaitDuration = obj.pAckWaitDuration - obj.SYMBOLSPERSTEP; 
    obj.myFprintf([obj.ShortAddress ': Decreasing ack wait durations by 20 symbols to %d\n'], obj.pAckWaitDuration);
  end
end