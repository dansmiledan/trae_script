function initSymbolRate(obj)
  % Set the symbol rate based on the used modulation and frequency band

%   Copyright 2017-2023 The MathWorks, Inc. 

  if strcmp(obj.PhysicalLayer, 'OQPSK')
    if obj.CenterFrequency > 868e6 && obj.CenterFrequency < 868.6e6 
      obj.pSymbolRate = 25000;
    else
      obj.pSymbolRate = 62500;
    end
    if obj.CenterFrequency > 2.4e9 && obj.CenterFrequency < 2484e6
      obj.pChipsPerSymbol = 32;
    else
      obj.pChipsPerSymbol = 16;
    end

    phySHRDuration = 10; % symbols
    symbolsPerOctet = 2;
    
  elseif strcmp(obj.PhysicalLayer, 'BPSK')
    if obj.CenterFrequency > 902e6 && obj.CenterFrequency < 928e6 
      obj.pSymbolRate = 40000;
    else
      obj.pSymbolRate = 20000;
    end
    obj.pChipsPerSymbol = 15;
    
    phySHRDuration = 32; % symbols
    symbolsPerOctet = 8;

  elseif strcmp(obj.PhysicalLayer, 'MPSK')
    obj.pSymbolRate = 62500;
    obj.pChipsPerSymbol = 16;
    symbolsPerOctet = 2;
    
    phySHRDuration = 10; % symbols

  elseif strcmp(obj.PhysicalLayer, 'GFSK')
    obj.pSymbolRate = 10000;
    obj.pChipsPerSymbol = 1;
    
    phySHRDuration = 32; % symbols
    symbolsPerOctet = 8;
  end
  
  % calculate wait duration for acknowledgements
  unitBackoffPeriod = 20; % symbols
  turnaroundTime = 12; % symbols
  % Equation in Sec. 6.4.3 of the 2011 IEEE 802.15.4 revision
  obj.pMAXAckWaitDuration = unitBackoffPeriod + turnaroundTime + ...
                            phySHRDuration + ceil(6*symbolsPerOctet);
end