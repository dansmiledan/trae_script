classdef MACDevice < matlab.System
%MACDEVICE A MAC-layer device of IEEE 802.15.4
% This class provides the common functionality between Full Function
% Devices (FFD) and Reduced Function Devices (RFD) of the IEEE 802.15.4 MAC.
%
%   See also lrwpan.MACFullFunctionDevice, lrwpan.MACReducedFunctionDevice

%   Copyright 2017-2023 The MathWorks, Inc.
  
  properties (Nontunable)
    % ExtendedAddress The 64-bit device address
    % Specify ExtendedAddress as a 16-character hexadecimal array, denoting
    % the unique 64-bit address of the device. The default is
    % '0000000000000000'.
    ExtendedAddress = '0000000000000000'
  end
  properties 
    % ShortAddress The 16-bit device address
    % Specify ShortAddress as a 4-character hexadecimal array, denoting
    % the 16-bit address of the device assigned by the PAN Coordinator. 
    % The default is '0000'.
    ShortAddress = '0000'
  end
  properties (Constant)
    % CenterFrequency The frequency of the tuned channel
    % Specify CenterFrequency as a positive scalar. The default is 2.48 GHz.
    CenterFrequency = 2480e6
    
    % PhysicalLayer The used physical layer 
    % Specify PhysicalLayer as one of 'OQPSK' | 'BPSK' | 'MPSK' | 'GFSK'.
    % The default is 'OQPSK'.
    PhysicalLayer = 'OQPSK'
  end
  properties 
    %SamplesPerChip Number of samples per chip
    % Specify SamplesPerChip as a positive even scalar that is greater than
    % 2. The default is 4.
    SamplesPerChip = 4
  end
  
  properties (Dependent)
    % CarrierSenseThreshold Carrier sensing threshold
    % Specify CarrierSenseThreshold as a non-negative amplitude value in
    % Watts.
    CarrierSenseThreshold
  end
  properties
    % Verbosity Option to print detailed information
    Verbosity = true
  end
  
  properties(Constant, Hidden)
    PhysicalLayerValues = {'OQPSK', 'BPSK', 'MPSK', 'GFSK'}
    BackOffPeriod = 20 % in symbols
    pStateValues = {'BackOff', 'InitTransmit', 'Transmit', 'CarrierSense', 'Idle'}
    pScanningStateValues = {'No scanning', 'Pre-scanning', 'Passive scanning', 'Pending transmission', 'Transmitting request'};
    MINBACKOFFEXPONENT = 3
    MAXBACKOFFEXPONENT = 5
    MAXNUMBACKOFFS = 4
    SYMBOLSPERSTEP = 20
    SIFS           = 12 % in symbols
    LIFS           = 40 % in symbols
    NUMSTEPSPERBASESLOT = 3
    NUMSUPERFRAMESLOTS = 16;
    MACRESPONSEWAITTIME = 2; % multiples of aBaseSuperFrameDuration (= 60 symbols x 16 slots)
    MACMAXFRAMERETRIES  = 3; % range is 0-7, implementation uses 1 value
  end
  
  properties(Access = protected)
    pClock            = 0
    pSymbolRate       = 0
    pNumBackoffs       = 0
    pBackoffDelay     = 0
    pBackoffExponent  = 3
    pCW0
    pContentionWindow = 0 
    pState            = 'Idle'
    pScanningState    = 'No scanning'
    pSlotted          = false
    pBatteryLifeExtension = false
    pChipsPerSymbol      % Chips per symbol
    pFrameQueue = {};
    pTxBuffer
    pTxIndex = 1;
    pDataSequenceNumber = 0
    pPHYDecoder
    pScanSteps = 0
    pScanningResults = []
    pPANID = []
    pSymbolsToWait = 0;
    pFrameToTransmit = [];
    pUnaknowledgedFrame = []; % cfg
    pUnaknowledgedPayload = [];
    pMAXAckWaitDuration
    pAckWaitDuration
    pNumFrameReTries = 0
  end
  
  methods
    function obj = MACDevice(varargin)
      setProperties(obj, nargin, varargin{:});
    end
    
    function set.CarrierSenseThreshold(this, value)
      if isempty(this.pPHYDecoder)
        setup(this, 0); % dummy input
        release(this);
      end
      this.pPHYDecoder.CarrierSenseThreshold = value;
    end    
    function value = get.CarrierSenseThreshold(this)
      if isempty(this.pPHYDecoder)
        setup(this, 0); % dummy input
        release(this);
      end
      value = this.pPHYDecoder.CarrierSenseThreshold;
    end
    
    function set.Verbosity(this, value)
      if isempty(this.pPHYDecoder) %#ok<MCSUP>
        setup(this, 0); % dummy input
        release(this);
      end
      this.pPHYDecoder.Verbosity = value; %#ok<MCSUP>
      this.Verbosity = value;
    end    
  end
    
  methods (Access = protected)
    function resetImpl(obj)
      obj.pClock              = 0;
      obj.pNumBackoffs        = 0;
      obj.pBackoffDelay       = 0;
      obj.pBackoffExponent    = obj.MINBACKOFFEXPONENT;
      obj.initContentionWindow();
      obj.pContentionWindow = 0;
      obj.pSlotted = false;
      obj.pBatteryLifeExtension = false;
      % obj.pFrameQueue = {}; % allow scan to be performed at constructor,
                              % do not clear queue at 1st step
      reset(obj.pPHYDecoder);
      obj.pScanningResults = [];
      obj.pSymbolsToWait = 0;
      obj.pFrameToTransmit = [];
      obj.pUnaknowledgedFrame = [];
      obj.pUnaknowledgedPayload = [];
      obj.pNumFrameReTries = 0;
    end
      
  
    
    function setupImpl(obj)
      obj.initSymbolRate();
      obj.initContentionWindow();
      obj.pPHYDecoder = lrwpan.PHYDecoderOQPSK('SamplesPerChip', obj.SamplesPerChip, ...
        'CoarseFrequencyCompensation', true, 'FineFrequencyCompensation', true, 'TimingRecovery', true, ...
        'Verbosity', obj.Verbosity);
    end
  end
    
  methods (Access = protected)
    
    out = stepImpl(this, rcv)
    
    cfg = processMPDU(obj, MPDU, frameEndInSymbols)
    
    function enqueue(obj, frame, cfg, varargin)
      if ~isempty(varargin) && varargin{1} == true
        topOfList = true;
      else
        topOfList = false;
      end
      if ~topOfList 
        obj.pFrameQueue = [obj.pFrameQueue; {frame, cfg}];
      else
        obj.pFrameQueue = [{frame, cfg}; obj.pFrameQueue];
      end
    end
    
    function addIFS(obj, bitLen, offset, ackException)
      if ~ackException && (bitLen/8 > 18) % 18 octets is the threshold between SIFS & LIFS
        % need LIFS
        obj.pSymbolsToWait = obj.LIFS - obj.SYMBOLSPERSTEP + offset;
        obj.myFprintf([obj.ShortAddress ': Need to wait for LIFS (40) symbols. Offset = %d, next IFS = %d\n'], offset, obj.pSymbolsToWait);
      else
        % need SIFS; acknowledgments included (need 5 octets)
        obj.pSymbolsToWait = obj.SIFS - obj.SYMBOLSPERSTEP + offset;
        obj.myFprintf([obj.ShortAddress ': Need to wait for SIFS (12) symbols. Offset = %d, next IFS = %d\n'], offset, obj.pSymbolsToWait);
      end
    end
    
    function processScanningResults(obj)
      % The IEEE 802.15.4 standard does not specify a mechanism for
      % selecting between different PANs. We implement an arbitrary
      % selection of the 1st PAN to transmit a beacon, with PermitAssociation = true.
      for idx = 1:length(obj.pScanningResults)
        beaconCfg = obj.pScanningResults(idx);
        if beaconCfg.PermitAssociation
          obj.associationRequest(beaconCfg);
          return;
        end
      end
    end        
    
    function initContentionWindow(obj)
      % Initialize initial contention window (pCW0)
      if obj.CenterFrequency > 950e6 && obj.CenterFrequency < 956e6 
        % Japanese band
        obj.pCW0 = 1;
      else
        obj.pCW0 = 2;
      end
    end
    
    function seqNo = getAndIncreaseDataSequenceNumber(obj)
      % Sequence number:
      seqNo = obj.pDataSequenceNumber;
      obj.pDataSequenceNumber = mod(obj.pDataSequenceNumber + 1, 2^8);
    end
                  
    function channelIdle = carrierSense(obj, receivedWaveform)
      channelIdle = ~any(abs(receivedWaveform) > obj.CarrierSenseThreshold);
    end
    
    function myFprintf(obj, str, varargin)
      if obj.Verbosity
        fprintf(join(str,''), varargin{:});
      end
    end
  end
  
end

