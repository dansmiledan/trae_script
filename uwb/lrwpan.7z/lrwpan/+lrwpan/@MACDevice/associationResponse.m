function associationResponse(obj)
  
  %   Copyright 2017-2023 The MathWorks, Inc. 
  
  cfgRes = lrwpan.MACFrameConfig('FrameType', 'MAC command', 'MACCommand', 'Association response');
  cfgRes.SourceAddressing               = 'Extended address';
  cfgRes.DestinationAddressing          = 'Extended address';
  cfgRes.FramePending                   = false;
  cfgRes.AcknowledgmentRequest          = true;
  cfgRes.PANIdentificationCompression   = true;
  
  cfgRes.DestinationPANIdentifier       = obj.PANIdentifier;
  cfgRes.DestinationAddress             = cfgReg.SourceAddress;
  cfgRes.SourceAddress                  = obj.ExtendedAddress;
  
  cfgRes.AssociationStatus              = 'Successful';
  % Assign a (random) short address to the device:
  shortAddressDec = randi([0 2^16-3]); % -2 because 'FFFF' and 'FFFE' have special meaning
  cfgRes.ShortAddress                   = dec2hex(shortAddressDec, 4);
end

