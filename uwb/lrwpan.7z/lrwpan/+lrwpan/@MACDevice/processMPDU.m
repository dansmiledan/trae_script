function cfg = processMPDU(obj, MPDU, frameEndInSymbols)
  
%   Copyright 2017-2023 The MathWorks, Inc. 

  cfg = lrwpan.MACFrameDecoder(MPDU);
  
  % Rejections
  if rejectFrame(obj, cfg)
    return
  end
  obj.myFprintf('CRC check passed for the MAC frame.\n');

  obj.myFprintf([obj.ShortAddress ': *********** Received frame type = %s\n'], cfg.FrameType);
  if strcmp(cfg.FrameType, 'MAC command')
    obj.myFprintf([obj.ShortAddress ': *********** Received MAC Command type = %s\n'], cfg.MACCommand);
  end

  if strcmp(cfg.FrameType, 'Beacon')  && strcmp(obj.pScanningState, 'Passive scanning')
    % add beacon (configuration) to scanning results
    obj.pScanningResults = [obj.pScanningResults cfg];
  end

  ackException = false;
  if strcmp(cfg.FrameType, 'Data') && cfg.AcknowledgmentRequest    
    ackException = true;
    obj.addIFS(length(MPDU), frameEndInSymbols, ackException);
    framePending = false;
    obj.acknowledgeFrame(cfg, framePending);
    
  elseif ~strcmp(cfg.FrameType, 'Acknowledgment')
    obj.addIFS(length(MPDU), frameEndInSymbols, ackException);
  end  
  
  if strcmp(cfg.FrameType, 'Acknowledgment')
    
    if ~isempty(obj.pUnaknowledgedFrame) && ...
        obj.pUnaknowledgedFrame.SequenceNumber == cfg.SequenceNumber

      obj.addIFS(length(obj.pUnaknowledgedPayload)*8, frameEndInSymbols, ackException);
      if strcmp(obj.pUnaknowledgedFrame.FrameType, 'MAC command') && ...
         strcmp(obj.pUnaknowledgedFrame.MACCommand, 'Association request') 
       
       obj.pSymbolsToWait = obj.MACRESPONSEWAITTIME * obj.NUMSUPERFRAMESLOTS * ...
                            obj.NUMSTEPSPERBASESLOT * obj.SYMBOLSPERSTEP; % in symbols
       
       obj.requestData(obj.pUnaknowledgedFrame); % request the association response for this assoc request
      end
      obj.pUnaknowledgedFrame = [];
      obj.pNumFrameReTries = 0;
    end
  end
  
  
  if strcmp(cfg.FrameType, 'MAC command')

    if strcmp(cfg.MACCommand, 'Association response') 
      
      if strcmp(cfg.AssociationStatus, 'Successful')
        obj.myFprintf([obj.ShortAddress ': *********** Association successful, changing short address to = %s\n'], cfg.ShortAddress);
        obj.ShortAddress = cfg.ShortAddress;
        obj.myFprintf([obj.ShortAddress ': *********** Association successful, associated to PAN = %s\n'], cfg.DestinationPANIdentifier);
        obj.pPANID = cfg.DestinationPANIdentifier;
        obj.pFFDExtended = cfg.DestinationAddress;
        
        % acknowledge frame
        framePending = false;
        obj.acknowledgeFrame(cfg, framePending);
      end
    end
  end    
end