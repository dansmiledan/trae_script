function bool = rejectFrame(obj, cfg)

%   Copyright 2017-2023 The MathWorks, Inc. 

  bool = true;

  if isempty(cfg)
    % drop all frames with failing CRC check
    return;
  end
  
  if strcmp(obj.pScanningState, 'Passive scanning') && ~strcmp(cfg.FrameType, 'Beacon')
    % discard all non-beacon frames during passive scanning
    return;
  end
  
  if ~strcmp(cfg.DestinationAddressing, 'Not present')
    if ~strcmpi(cfg.DestinationPANIdentifier, 'FFFF') && ~strcmpi(cfg.DestinationPANIdentifier, obj.pPANID) 
      if ~strcmp(cfg.MACCommand, 'Association response') % needed to set PANID
        return
      end
    end
  end
  if strcmp(cfg.DestinationAddressing, 'Short address') && ...
      ~(strcmpi(cfg.DestinationAddress, 'FFFF') || strcmpi(cfg.DestinationAddress, obj.ShortAddress)) 
    % Frame not for this device
    return;
  end
  if strcmp(cfg.DestinationAddressing, 'Extended address') && ...
      ~(strcmpi(cfg.DestinationAddress, repmat('F', 1, 16)) || strcmpi(cfg.DestinationAddress, obj.ExtendedAddress)) 
    % Frame not for this device
    return;
  end
  if strcmp(cfg.SourceAddressing, 'Short address') && strcmpi(cfg.SourceAddress, obj.ShortAddress)
    % Received my frame (full-duplex).
    return;
  end
  if strcmp(cfg.SourceAddressing, 'Extended address') && strcmpi(cfg.SourceAddress, obj.ExtendedAddress)
    % Received my frame (full-duplex)
    return;
  end

  if ~strcmp(obj.pScanningState, 'Passive scanning') && ...
        strcmp(cfg.DestinationAddressing, 'Not present') && ~strcmp(cfg.SourceAddressing, 'Not present')
    if ~(isa(obj, 'lrwpan.MACFullFunctionDevice')  && obj.PANCoordinator && strcmpi(cfg.SourcePANIdentifier, obj.pPANID) ) 
      return
    end
  end
  bool = false;
end