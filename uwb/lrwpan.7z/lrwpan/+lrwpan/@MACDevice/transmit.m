function transmittedWaveform = transmit(obj)

%   Copyright 2017-2023 The MathWorks, Inc.

samplesPerStep = obj.SamplesPerChip * obj.pChipsPerSymbol * obj.SYMBOLSPERSTEP/2;  
transmittedWaveform = zeros(samplesPerStep, 1);

IFSsamples = max(0, obj.SamplesPerChip * obj.pChipsPerSymbol * obj.pSymbolsToWait /2);

if ~strcmp(obj.pState, 'Transmit') 
  return
end

if IFSsamples >= samplesPerStep
  obj.pSymbolsToWait = obj.pSymbolsToWait - obj.SYMBOLSPERSTEP;  
  return
end

numTxSamples = min(samplesPerStep - IFSsamples, length(obj.pTxBuffer)- obj.pTxIndex + 1 - IFSsamples);
obj.myFprintf([obj.ShortAddress ': IFS offset = %d samples\n'], IFSsamples);
obj.myFprintf([obj.ShortAddress ': Transmitting %d-%d of %d\n'], obj.pTxIndex, obj.pTxIndex+numTxSamples-1, length(obj.pTxBuffer));
transmittedWaveform(1+IFSsamples:numTxSamples+IFSsamples) = ...
  obj.pTxBuffer(obj.pTxIndex:obj.pTxIndex + numTxSamples -1);
obj.pSymbolsToWait = 0; % reset IFS
obj.pTxIndex = obj.pTxIndex + numTxSamples;
if obj.pTxIndex > length(obj.pTxBuffer)
  obj.myFprintf([obj.ShortAddress ': Finished transmission\n']);
  % End of transmission

  if obj.pFrameToTransmit.AcknowledgmentRequest
    obj.pUnaknowledgedFrame = obj.pFrameToTransmit;

    obj.pAckWaitDuration = obj.pMAXAckWaitDuration + obj.pSymbolsToWait;
    obj.myFprintf([obj.ShortAddress ': will wait for ack for %d symbols additional to IFS = %d\n'], obj.pMAXAckWaitDuration, obj.pSymbolsToWait);
  else
    offsetSymbols = round((numTxSamples+IFSsamples) * 2 /(obj.SamplesPerChip * obj.pChipsPerSymbol));
    txBitLen = length(obj.pTxBuffer)*2*4/(obj.SamplesPerChip*obj.pChipsPerSymbol);
    obj.addIFS(txBitLen, offsetSymbols, false);
  end
  obj.pFrameToTransmit = [];

  obj.pTxIndex = 1;
  obj.pTxBuffer = [];
  obj.pState = 'Idle';      

  if any(strcmp(obj.pScanningState, {'Transmitting request', 'Pre-scanning'}))
    obj.myFprintf([obj.ShortAddress ': Entering passive scanning\n']);
    obj.pScanningState = 'Passive scanning';
  end
end

