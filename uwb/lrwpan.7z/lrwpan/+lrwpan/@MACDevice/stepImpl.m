function transmittedWaveform = stepImpl(obj, receivedWaveform)
  % Execute a unit time period equal to a single backoff duration (20
  % symbols). This is the 1/3 of a time slot duration (60 symbols).

%   Copyright 2017-2023 The MathWorks, Inc. 
  
  % inject random data frames
  obj.injectRandomData();

  % INIT TRANSMIT
  obj.idleProcessing();

  % CSMA/CA: MAKE ONE STEP
  obj.CSMAStateMachine(receivedWaveform);
  
  % DECODE RECEIVED WAVEFORM
  obj.decodeReceived(receivedWaveform);

  % HANDLE PENDING ACKNOWLEDGMENTS
  obj.processPendingAck();
  
  % TRANSMIT
  transmittedWaveform = obj.transmit();
  
  % clock update
  obj.pClock = obj.pClock + obj.SYMBOLSPERSTEP/obj.pSymbolRate;
end