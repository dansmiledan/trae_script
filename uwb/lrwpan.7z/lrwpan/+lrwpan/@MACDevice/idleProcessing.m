function idleProcessing(obj)
  
  %   Copyright 2017-2023 The MathWorks, Inc.
  
  % INIT TRANSMIT
  % Add new packets to queue
  if strcmp(obj.pState, 'Idle') && ~strcmp(obj.pScanningState, 'Passive scanning') ...
      && isempty(obj.pUnaknowledgedFrame)
    
    if obj.pSymbolsToWait < obj.SYMBOLSPERSTEP
      if isempty(obj.pTxBuffer)
        if ~isempty(obj.pFrameQueue)
          obj.myFprintf([obj.ShortAddress ': Processing next frame from the queue\n'])

          cfgOQPSK = lrwpanOQPSKConfig(SamplesPerChip=obj.SamplesPerChip, PSDULength=length(obj.pFrameQueue{1, 1})/8);
          obj.pTxBuffer = lrwpanWaveformGenerator(obj.pFrameQueue{1, 1}, cfgOQPSK);
          obj.pFrameToTransmit = obj.pFrameQueue{1, 2};
          obj.pFrameQueue(1, :) = [];
          obj.pState = 'InitTransmit';
        end
      end
    else
      obj.pSymbolsToWait = obj.pSymbolsToWait - obj.SYMBOLSPERSTEP;
      obj.myFprintf([obj.ShortAddress ': Decreased wait time by 20 symbols to %d\n'], obj.pSymbolsToWait);
    end
  end
end

