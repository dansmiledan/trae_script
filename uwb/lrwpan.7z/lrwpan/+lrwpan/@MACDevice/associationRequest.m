function associationRequest(obj, beaconConfig)

%   Copyright 2017-2023 The MathWorks, Inc. 

  cfg = lrwpan.MACFrameConfig('FrameType', 'MAC command', 'MACCommand', 'Association request');
  % Capability information:
  cfg.FFDDevice = isa(obj, 'lrwpan.MACFullFunctionDevice');
  % security level = 0
  cfg.BatteryPowered = ~cfg.FFDDevice; % assumption that FFDs only are mains powered
  cfg.AllocateAddress = true; % allocate a short address 
  cfg.IdleReceiving = cfg.FFDDevice; 
  % Addressing fields
  cfg.DestinationAddressing     = beaconConfig.SourceAddressing;
  cfg.DestinationAddress        = beaconConfig.SourceAddress;
  if strcmp(cfg.DestinationAddressing, 'Short address')
    obj.pFFDShort = cfg.DestinationAddress;
  end
  cfg.DestinationPANIdentifier  = beaconConfig.SourcePANIdentifier;
  cfg.SourceAddressing          = 'Extended address';
  cfg.SourceAddress             = obj.ExtendedAddress;
  cfg.SourcePANIdentifier       = 'FFFF'; % broadcast;
  % Sequence number:
  cfg.SequenceNumber = getAndIncreaseDataSequenceNumber(obj);
  
  cfg.AcknowledgmentRequest = true;
  cfg.FramePending = false;

  % Generate association request MAC frame:
  assocReqFrame = lrwpan.MACFrameGenerator(cfg);
  obj.myFprintf([obj.ShortAddress ': ********* Adding Association request frame to the queue\n']);
  obj.enqueue(assocReqFrame, cfg);
end
