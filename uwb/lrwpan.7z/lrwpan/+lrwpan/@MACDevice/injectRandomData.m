function injectRandomData(obj)
  
  %   Copyright 2017-2023 The MathWorks, Inc.
  
  % transmit data frames, randomly between devices
  r = randi([0 1e4-1], 1, 1);
  
  if r >= 1e4-1
    % Random transmission activated
    
    if isa(obj, 'lrwpan.MACReducedFunctionDevice')
      if isempty(obj.pPANID)
        return
      end
      % RFD can only talk to FFD
      dest = obj.pFFDShort;
      
    else % This is a coordinator
      if isempty(obj.pDevices)
        return
      end
      % choose one of the associated devices
      r = randi([0 size(obj.pDevices, 1)-1], 1, 1) + 1;
      dest = obj.pDevices{r, :};
    end
    
    cfg = lrwpan.MACFrameConfig('FrameType', 'Data');
    cfg.SequenceNumber = obj.getAndIncreaseDataSequenceNumber();
    cfg.AcknowledgmentRequest = true;
    cfg.SourceAddressing = 'Short address';
    cfg.DestinationAddressing = 'Short address';
    cfg.SourceAddress = obj.ShortAddress;
    cfg.DestinationAddress = dest;
    cfg.PANIdentificationCompression = true;
    cfg.DestinationPANIdentifier = obj.pPANID;
    
    numOctets = 50;
    payload = dec2hex(randi([0 2^8-1], numOctets, 1), 2);
    dataFrame = lrwpan.MACFrameGenerator(cfg, payload);
    obj.enqueue(dataFrame, cfg);
    obj.pUnaknowledgedPayload = payload;
    obj.myFprintf([obj.ShortAddress ': ********* (t=%f) Injecting data frame to the queue. From: %s -> To: %s \n'], obj.pClock, cfg.SourceAddress, dest);
  end
end

