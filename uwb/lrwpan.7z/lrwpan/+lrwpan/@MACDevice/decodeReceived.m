function decodeReceived(obj, receivedWaveform)

  %   Copyright 2017-2023 The MathWorks, Inc.
  
  [MPDU, frameEndInSamples] = obj.pPHYDecoder(receivedWaveform);  
  frameEndInSymbols = round(frameEndInSamples * 2/ (obj.SamplesPerChip * obj.pChipsPerSymbol));
  if ~isempty(MPDU)
    obj.myFprintf([obj.ShortAddress ': PHY decoded IEEE 802.15.4 frame\n']);    
    
    % wait for interframe spacing before next transmission
    obj.processMPDU(MPDU, frameEndInSymbols);
    
    obj.pSymbolsToWait = max(obj.pSymbolsToWait, 0);
    obj.myFprintf([obj.ShortAddress ': next IFS = %d\n'], obj.pSymbolsToWait);
  end

  if strcmp(obj.pScanningState, 'Passive scanning')
    obj.pScanSteps = obj.pScanSteps - 1;
%         obj.myFprintf('Scanning for %d steps more\n', obj.pScanSteps);
    if obj.pScanSteps == 0
      obj.myFprintf([obj.ShortAddress ': Scanning finished\n']);
      obj.pScanningState = 'No scanning';
      obj.processScanningResults();
    end
  end
  
end

