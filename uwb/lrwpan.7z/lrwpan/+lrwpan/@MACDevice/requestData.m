function requestData(obj, assocReq)
  
  %   Copyright 2017-2023 The MathWorks, Inc.
  
  cfg = lrwpan.MACFrameConfig('FrameType', 'MAC command', 'MACCommand', 'Data request');
  cfg.SequenceNumber = getAndIncreaseDataSequenceNumber(obj);
  
  cfg.FramePending = false;
  cfg.AcknowledgmentRequest = true;
  
  cfg.DestinationAddressing     = assocReq.DestinationAddressing;
  cfg.DestinationAddress        = assocReq.DestinationAddress;
  cfg.DestinationPANIdentifier  = assocReq.DestinationPANIdentifier;
  
  cfg.SourceAddressing          = 'Extended address';
  cfg.SourceAddress             = obj.ExtendedAddress;
  cfg.PANIdentificationCompression = true;
  
  % Generate data request MAC frame:
  dataReqFrame = lrwpan.MACFrameGenerator(cfg);
  obj.myFprintf([obj.ShortAddress ': *********** Adding Data request frame to the queue\n']);
  obj.enqueue(dataReqFrame, cfg);
end

