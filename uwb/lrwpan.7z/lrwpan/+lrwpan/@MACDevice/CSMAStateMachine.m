function CSMAStateMachine(obj, receivedWaveform)

%   Copyright 2017-2023 The MathWorks, Inc. 

  % INIT TRANSMIT
  if strcmp(obj.pState, 'InitTransmit')
    % Initialize variables
    obj.pNumBackoffs = 0;
    if ~(obj.pSlotted && obj.BatteryLifeExtension)
      obj.pBackoffExponent = obj.MINBACKOFFEXPONENT;
    else
      obj.pBackoffExponent = min(2, obj.MINBACKOFFEXPONENT);
    end

    if obj.pSlotted 
      obj.pContentionWindow = obj.pCW0;
    end

    obj.pBackoffDelay = randi([0 2^obj.pBackoffExponent-1], 1, 1);
    obj.myFprintf([obj.ShortAddress ': Initializing transmission; backoff delay = %d steps\n'], obj.pBackoffDelay);
    obj.pState = 'BackOff';
  end

  % BACK OFF
  if strcmp(obj.pState, 'BackOff')
    if obj.pBackoffDelay == 0
      % carrier sense in the next slot
      obj.pState = 'CarrierSense';
    else
      obj.myFprintf([obj.ShortAddress ': Backoff delay = %d steps -> %d steps\n'], obj.pBackoffDelay, obj.pBackoffDelay-1);
      obj.pBackoffDelay = obj.pBackoffDelay - 1;
    end

  % CARRIER SENSE  
  elseif strcmp(obj.pState, 'CarrierSense')

    channelIdle = obj.carrierSense(receivedWaveform); % carrier sense for the last backoff duration
    resultStrings = {'busy', 'idle'};
    obj.myFprintf([obj.ShortAddress ': Carrier sensing: Medium is %s.\n'], resultStrings{1+channelIdle});
    if channelIdle % CHANNEL IDLE

      if obj.pSlotted % SLOTTED
        obj.pContentionWindow = obj.pContentionWindow - 1;
        if obj.pContentionWindow == 0
          % clear to tranmit
          obj.myFprintf([obj.ShortAddress ': Clear to transmit\n']);
          obj.pState = 'Transmit';
        else
           % Carrier-sense one more time
           obj.myFprintf([obj.ShortAddress ': Need one more successful carrier sensing\n']);
          obj.pState = 'CarrierSense';
        end

      else % UNSLOTTED
        % clear to tranmit
        obj.myFprintf([obj.ShortAddress ': Clear to transmit\n']);
        obj.pState = 'Transmit';

        if strcmp(obj.pScanningState, 'Pending transmission')
          obj.myFprintf([obj.ShortAddress ': Transmitting Beacon Request\n']);
          obj.pScanningState = 'Transmitting request';
        end
      end

    else % CHANNEL OCCUPIED

      obj.pNumBackoffs = obj.pNumBackoffs + 1;
      obj.pBackoffExponent = min(obj.pBackoffExponent+1, obj.MAXBACKOFFEXPONENT);
      if obj.pSlotted 
        obj.pContentionWindow = obj.pCW0;
      end

      if obj.pNumBackoffs > obj.MAXNUMBACKOFFS
        % failure, stop attempting transmissions
        % should notify the next layer (NET)
        obj.pState = 'Idle';
        obj.myFprintf([obj.ShortAddress ': Reached maximum number of attempts. Giving up\n']);
      else
        % try again
        obj.pBackoffDelay = randi([0 2^obj.pBackoffExponent-1]);
        obj.pState = 'BackOff';
        obj.myFprintf([obj.ShortAddress ': Try backoff attempt = %d out of %d (max)\n'], obj.pNumBackoffs, obj.MAXNUMBACKOFFS);
      end
    end

  % IDLE
  elseif strcmp(obj.pState, 'Idle')
    % do nothing
  end
end