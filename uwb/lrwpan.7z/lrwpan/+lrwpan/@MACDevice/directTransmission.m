function directTransmission(obj, frame, cfg)
  
  %   Copyright 2017-2023 The MathWorks, Inc.

  cfgOQPSK = lrwpanOQPSKConfig(SamplesPerChip=obj.SamplesPerChip, PSDULength=length(frame)/8);
  obj.pTxBuffer = lrwpanWaveformGenerator(frame, cfgOQPSK);
  obj.pTxIndex = 1;
  obj.pFrameToTransmit = cfg;
  obj.pState = 'Transmit';
end

