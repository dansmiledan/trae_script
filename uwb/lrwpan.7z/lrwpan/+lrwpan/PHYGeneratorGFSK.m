function waveform = PHYGeneratorGFSK( MPDU, varargin )
%PHYGENERATORGFSK Transmit-side GFSK physical layer of 802.15.4
%   WAVEFORM = PHYGENERATORGFSK( MPDU ) whitens the PHY header (PHR)
%   and the MAC protocol data unit MPDU with the PN9 sequence. Then, the
%   entire PHY protocol data unit (PPDU) is GFSK modulated.
%
%   See also lrwpanWaveformGenerator, LRWPAN.PHYDECODERGFSK, 
%   LRWPAN.PHYGENERATORBPSK, LRWPAN.PHYGENERATORASK

%   Copyright 2017-2023 The MathWorks, Inc.

OSR = lrwpan.internal.generatorValidation(MPDU, nargin, varargin);

%% Synchronization header (SHR)
% Preamble is 4 octets, all set to [0 1 0 1 0 1 0 1].
preamble = repmat([0 1 0 1 0 1 0 1]', 4, 1);

% Start-of-frame delimiter (SFD)
SFD = [1 1 1 0 0 1 0 1]'; % value from standard (see Fig. 68, IEEE 802.15.4, 2011 Revision)

SHR = [preamble; SFD];

%% PHY Header (PHR)
frameLength = int2bit(length(MPDU)/8, 7, false);
reservedValue = 0;
PHR = [frameLength; reservedValue];


%% Data whitening
pn9 = comm.PNSequence('Polynomial',      commstr2poly('x^9 + x^5 + 1', 'descending'), ...
                      'SamplesPerFrame', length(MPDU)+8, ...
                      'InitialConditions', ones(1, 9), 'Mask', 9);
whitened = xor( [PHR; MPDU], pn9() );

%% PHY protocol data unit:
PPDU = [SHR; whitened]; % no whitening for SHR

%% GFSK modulation
gfskMod = comm.CPMModulator('ModulationOrder', 2, 'FrequencyPulse', 'Gaussian', ... 
               'BandwidthTimeProduct', 0.5, 'ModulationIndex', 1, ...
               'BitInput', true, 'SamplesPerSymbol', OSR);
waveform = gfskMod(PPDU);
  
