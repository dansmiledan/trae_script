classdef (StrictDefaults)PHYDecoderOQPSK < matlab.System
%PHYDECODEROQPSK IEEE 802.15.4 OQPSK PHY Decoder
%
%   PHYDecoderOQPSK properties:
%   
%   Band                        - Used frequency band (780 MHz, 868 MHz, 900 MHz, 2.4 GHz)
%   SamplesPerChip              - Number of samples per chip
%   CoarseFrequencyCompensation - Option to coarsely compensate frequency offsets
%   FineFrequencyCompensation   - Option to finely compensate frequency offsets
%   TimingRecovery              - Option to perform timing recovery
%   CarrierSenseThreshold       - Carrier sense threshold
%
%   See also lrwpan.MACFullFunctionDevice, lrwpan.MACReducedFunctionDevice.

% Copyright 2017-2023 The MathWorks, Inc.
  
  
  properties (Nontunable)    
    %SamplesPerChip Samples per chip
    % Specify the used frequency band as one of '780 MHz' | '868 MHz' |
    % '900 MHz' | '2.4 GHz'. The OQPSK PHY employs a different spreading
    % technique for the 2.4 GHz band. The default is '2.4 GHz'.
    Band = '2.4 GHz'
    %SamplesPerChip Samples per chip
    % Specify the number of samples that represent each chip as an even
    % integer-valued real positive scalar. The chip rate equals 1 MHz in
    % the 2450 band, 500 kHz in the 780 and 900 MHz bands, and 200 kHz in
    % the 868 band. The default is 4.
    SamplesPerChip = 4
    %CoarseFrequencyCompensation Coarsely compensate frequency offset
    % Specify CoarseFrequencyCompensation as a logical scalar. If true, the
    % decoder coarsely compensates for frequency offsets. The default is
    % false.
    CoarseFrequencyCompensation = false
    %FineFrequencyCompensation Finely compensate frequency offset
    % Specify FineFrequencyCompensation as a logical scalar. If true, the
    % decoder finely compensates for frequency offsets. This property
    % applies when CoarseFrequencyCompensation is true. The default is
    % false.
    FineFrequencyCompensation = false
    %TimingRecovery Perform symbol synchronization
    % Specify TimingRecovery as a logical scalar. If true, the decoder
    % performs timing recovery. This property applies when
    % CoarseFrequencyCompensation and FineFrequencyCompensation are both
    % true. The default is false.
    TimingRecovery = false
    % CarrierSenseThreshold Carrier sensing threshold
    % Specify CarrierSenseThreshold as a non-negative amplitude value in
    % Watts.
    CarrierSenseThreshold = 0.2
  end
  properties
    % Verbosity Option to print detailed information
    Verbosity = true
  end
  
  properties(Access = private, Nontunable)
    pSampleRate
    pReceiveFilterHalfSine
    pReceiveFilterRRC
    pCoarseFrequencyCompensator
    pFineFrequencyCompensator
    pSymbolSynchronizer
    pChipLen
    pChipMap
    pPrevInput % cache previous input for preamble detection
    pFoundPreamble = false
    pRemainingFrameBits = 0
    pMPDUBuffer
    pRotation = 0
    pNextStart
    pNextStop
    pMargin = 32 % indexing margin to account for var-size outputs of comm.SymbolSynchronizer
  end
  
  properties(Constant, Hidden)
    BandSet = matlab.system.StringSet({'780 MHz', '868 MHz', '900 MHz', '2.4 GHz'});
  end
  
  methods
    function obj = PHYDecoderOQPSK(varargin)
      setProperties(obj, nargin, varargin{:});
    end
  end
  
  methods (Access = protected)
    
    function setupImpl(obj)
      
      setupRates(obj);
      
      setupSpreading(obj);
      
      setupFiltering(obj);
      
      setupSynchronizers(obj);
      
      % Each input is a backoff duration, i.e., 20 (unspreaded) symbols. Each symbol is
      % 4 (unspreaded) bits. Each bit is 8 chips, which is 4 OQPSK chips.
      obj.pPrevInput = [];
    end
    
    function setupRates(obj)
      
      if strcmp(obj.Band, '2.4 GHz' )
        chipRate = 1e6;
      elseif any(strcmp(obj.Band, {'780 MHz' , '900 MHz'}))
        chipRate = 5e5;
      else % 868 MHz
        chipRate = 2e5;
      end
      obj.pSampleRate = obj.SamplesPerChip * chipRate;
    end
    
    function setupFiltering(obj)
      spc = obj.SamplesPerChip;
      if any(strcmp(obj.Band, {'780 MHz', '868 MHz'}))
        % Raised cosine pulse filtering
        if strcmp(band, '780 MHz')
          rolloff = 0.8;
        else
          rolloff = 0.2;
        end
        obj.pReceiveFilterRRC = comm.RaisedCosineTransmitFilter('RolloffFactor', rolloff, ...
                          'OutputSamplesPerSymbol', spc, 'Shape', 'Normal');
      end
      if ~strcmp(obj.Band, '780 MHz')
        % 2450 MHz, 915 MHz, 868 MHz
        halfSinePulse = sin(0:pi/spc:(spc)*pi/spc);
        decimationFactor = 1;
        obj.pReceiveFilterHalfSine = dsp.FIRDecimator(decimationFactor, halfSinePulse);
      end
    end
    
    function setupSynchronizers(obj)
      if obj.CoarseFrequencyCompensation
        
        obj.pCoarseFrequencyCompensator = comm.CoarseFrequencyCompensator('Modulation', 'OQPSK', ...
          'SamplesPerSymbol', obj.SamplesPerChip, 'SampleRate', obj.pSampleRate, 'FrequencyResolution', 100);
        
        if obj.FineFrequencyCompensation
          
          obj.pFineFrequencyCompensator = comm.CarrierSynchronizer('Modulation', 'OQPSK', ...
            'SamplesPerSymbol', obj.SamplesPerChip);
          
          if obj.TimingRecovery
            
            obj.pSymbolSynchronizer = comm.SymbolSynchronizer('Modulation', 'OQPSK', ...
              'SamplesPerSymbol', obj.SamplesPerChip);
          end
        end
      end
    end
    
    function setupSpreading(obj)
    
      if strcmp(obj.Band, '2.4 GHz')
        obj.pChipLen = 32;    
        % See Table 73 in IEEE 802.15.4,  2011 revision
        obj.pChipMap =  flipud(...
           [1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0;
            1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0;
            0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0;
            0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1;
            0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1;
            0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0;
            1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1;
            1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1;
            1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1;
            1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1;
            0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1;
            0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0;
            0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0;
            0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1;
            1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0;
            1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0]);
          
      else
        obj.pChipLen = 16;
        % See Table 74 in IEEE 802.15.4,  2011 revision
        obj.pChipMap =  flipud(...
                   [0 0 1 1 1 1 1 0 0 0 1 0 0 1 0 1;
                    0 1 0 0 1 1 1 1 1 0 0 0 1 0 0 1;
                    0 1 0 1 0 0 1 1 1 1 1 0 0 0 1 0;
                    1 0 0 1 0 1 0 0 1 1 1 1 1 0 0 0;
                    0 0 1 0 0 1 0 1 0 0 1 1 1 1 1 0;
                    1 0 0 0 1 0 0 1 0 1 0 0 1 1 1 1;
                    1 1 1 0 0 0 1 0 0 1 0 1 0 0 1 1;
                    1 1 1 1 1 0 0 0 1 0 0 1 0 1 0 0;
                    0 1 1 0 1 0 1 1 0 1 1 1 0 0 0 0;
                    0 0 0 1 1 0 1 0 1 1 0 1 1 1 0 0;
                    0 0 0 0 0 1 1 0 1 0 1 1 0 1 1 1;
                    1 1 0 0 0 0 0 1 1 0 1 0 1 1 0 1;
                    0 1 1 1 0 0 0 0 0 1 1 0 1 0 1 1;
                    1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0;
                    1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0;
                    1 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1]);
      end
    end
    
    function [MPDU, frameEndInSamples] = stepImpl(obj, received)
            
      MPDU = [];
      frameEndInSamples = 0;
      
      if ~any(abs(received) > obj.CarrierSenseThreshold)
        % performance optimization: do not decode if receptions are ongoing
        return;
      end
      
      % Receive filter; half-sine pulse for all bands except for 780 MHz (raised cosine)
      if ~strcmp(obj.Band, '780 MHz')
        % 2450 MHz, 915 MHz, 868 MHz
        filtered = obj.pReceiveFilterHalfSine(received);
        if strcmp(obj.Band, '868 MHz')
          received = filtered; % 868 is filtered by both half sine & RRC
        end
      end
      if any(strcmp(obj.Band, {'780 MHz', '868 MHz'}))
        filtered = obj.pReceiveFilterRRC(received);
      end
      
      % synchronization (optional)
      synced = filtered;
      if obj.CoarseFrequencyCompensation
        % Coarse Frequency Compensation
        synced = obj.pCoarseFrequencyCompensator(filtered);
        
        if obj.FineFrequencyCompensation
          % Fine Frequency Compensation
          synced = obj.pFineFrequencyCompensator(synced);
          
          if obj.TimingRecovery
            % Timing Recovery
            synced = obj.pSymbolSynchronizer(synced);
          end
        end
      end
            
      twoLastInputs = [obj.pPrevInput; synced];
      
      if ~(obj.CoarseFrequencyCompensation && obj.FineFrequencyCompensation && obj.TimingRecovery)
        twoLastInputs = twoLastInputs(1:obj.SamplesPerChip:end);
      end
      
      if ~obj.pFoundPreamble
        % We are searching for a preamble / frame
        obj.searchAndProcessHeader(twoLastInputs);        
      end
      
      frameEndInSamples = length(received) - obj.SamplesPerChip*(length(twoLastInputs)*2 - obj.pNextStop)/2;
      
      if obj.pFoundPreamble
        % Preamble has been found, now we are decoding the frame
        MPDU = obj.decodeFrame(twoLastInputs);
      end
      
      % Cache previous input for preamble detection
      obj.pPrevInput = synced;
    end
    
  
    
    function searchAndProcessHeader(obj, twoLastInputs)
      [preambleStart, demodulated] = obj.detectPreamble(twoLastInputs);
        
      if ~isempty(preambleStart)
        % Preamble was found
        preambleLen = 4*8;
        SFDLen = 8;
        PHRLen = 8;
        if preambleStart < length(twoLastInputs)*2 - (preambleLen + SFDLen + PHRLen)*4*2
          % ensure that the frame length is also present in the last two
          % inputs, otherwise defer decoding until next step().
          
          % Decode start of frame delimiter
          sfdSuccess = obj.decodeSFD(demodulated, preambleStart);
          if sfdSuccess 
            obj.pFoundPreamble = true;
          end

          % Decode PHY header, to obtain frame length information
          frameLen = obj.decodePHR(demodulated, preambleStart);
          obj.pRemainingFrameBits = 8*frameLen;
          obj.pMPDUBuffer = zeros(obj.pRemainingFrameBits, 1);
          % find preamble start in demodulated signal, i.e., 2 inputs x 20
          % symbols = 40 symbols = 160 bits = 640 I/Q chips = 1280 (real) chips
          obj.pNextStart = preambleStart + (preambleLen + SFDLen + PHRLen)*4*2;
          obj.pNextStop = min(length(twoLastInputs)*2 - obj.pMargin, obj.pNextStart + 8*frameLen*4*2-1);
        end
      end
    end    
    
    function [preambleStart, demodulated] = detectPreamble(obj, twoLastInputs)
      
      if obj.CoarseFrequencyCompensation || obj.FineFrequencyCompensation
        % need to resolve phase ambiguity
        phaseRange = 0:pi/2:3*pi/2;
      else
        phaseRange = 0;
      end
      
      for phase = phaseRange
        obj.pRotation = phase;
        rotated = twoLastInputs*exp(1i*phase);

        %% O-QPSK demodulation
        temp = [transpose(real(rotated (1:end))); transpose(imag(rotated (1:end)))];
        demodulated = temp(:) > 0; % Slicing, convert [-1 1] to [0 1]

        %% Preamble detection
        % Exhaustive sliding window for detection of first preamble
        for preambleStart = 1:(length(demodulated)-8*obj.pChipLen+1)
          % The preamble is 32 (despreaded) zeros. This is 8 symbols (4 octets),
          % which corresponds to 8*chipLen spreaded bits.
          preambleFound = true;  

          for chipNo = 1:8 % each chip should give symbol 0, which is 4 zero bits

            thisChip = demodulated(preambleStart + (chipNo-1)*obj.pChipLen : preambleStart-1+chipNo*obj.pChipLen);
            symbol = obj.despread(thisChip);
            if symbol ~= 0
              % preamble detection failed
              preambleFound = false;
              break; % break from detecting preamble at this start index
            end
          end
          if preambleFound % All 8 chips map to symbol 0, preamble found
            if obj.Verbosity
              fprintf('Found preamble of OQPSK PHY.\n');
            end
            return; % break from considering other preamble start indices, and possible phases
          end
        end
      end
      % preamble detection failed
      preambleStart = [];
    end
    
    function foundSFD = decodeSFD(obj, demodulatedSignal, preambleStart)
      
      chipLen = obj.pChipLen;
      
      %% Start-of-frame delimiter (SFD) detection
      SFD = [1 1 1 0 0 1 0 1];
      % SFD is 2 symbols, i.e., 2 chip sequences
      sfdStart = preambleStart + 4*8*8;
      % 1st chip sequence
      thisChip1 = demodulatedSignal(sfdStart : sfdStart -1+chipLen);
      symbol1 = obj.despread(thisChip1);
      % 2nd chip sequence
      thisChip2 = demodulatedSignal(sfdStart  + chipLen : sfdStart-1 + 2*chipLen);
      symbol2 = obj.despread(thisChip2);
      foundSFD = isequal(SFD, [int2bit(symbol1, 4, false)' int2bit(symbol2, 4, false)']);
      if foundSFD && obj.Verbosity
        fprintf('Found start-of-frame delimiter (SFD) of OQPSK PHY.\n');
      end
    end
    
    function frameLen = decodePHR(obj, demodulatedSignal, preambleStart)
      
      chipLen = obj.pChipLen;
      
      %% PHY Header (PHR)
      preambleLen = 4*8;  % 4 octets
      SFDLen = 8;         % 1 octet

      phrStart = preambleStart + 2*chipLen*(preambleLen+SFDLen)/8;
      phrChips = demodulatedSignal(phrStart : phrStart+2*chipLen-1);
      symbolA = obj.despread(phrChips(1:chipLen));
      symbolB = obj.despread(phrChips(chipLen+1:end));

      % PHR contains the MPDU length
      PHR = [int2bit(symbolA, 4, false); int2bit(symbolB, 4, false)];
      frameLen = bit2int(PHR(1:7), 7, false); % number of octets
    end
    
    function MPDU = decodeFrame(obj, twoLastInputs)
      
      range = obj.pNextStart:obj.pNextStop;
        
      % resolve phase ambiguity, according to phase value from preamble detection
      rotated = twoLastInputs*exp(1i*obj.pRotation);

      % O-QPSK demodulation
      temp = [transpose(real(rotated (1:end))); transpose(imag(rotated (1:end)))];
      demodulated = temp(:) > 0; % Slicing, convert [-1 1] to [0 1]
%       demodulated = demodulated(range);

      bits = zeros(4, floor(length(range)/obj.pChipLen));
      for chipSeqNo = 1:floor(length(range)/obj.pChipLen)

        %% Chip to symbol mapping
        thisChipSeq = demodulated(obj.pNextStart + (chipSeqNo-1)*obj.pChipLen :obj.pNextStart+chipSeqNo*obj.pChipLen-1);

        % find the chip sequence that looks the most like the received (minimum number of bit errors)
        symbol = obj.despread(thisChipSeq);

        %% Symbol to bit mapping
        bits(:, chipSeqNo) = int2bit(symbol, 4, false);
      end
      currPos = 1 + length(obj.pMPDUBuffer)-obj.pRemainingFrameBits;
      obj.pMPDUBuffer(currPos : currPos+numel(bits)-1) = bits(:);
      
      obj.pRemainingFrameBits = obj.pRemainingFrameBits-floor(length(range)/obj.pChipLen)*4;
      if obj.pRemainingFrameBits <= 0
        % frame decoding finished, search for new ones
        obj.pFoundPreamble = false;
        MPDU = obj.pMPDUBuffer;
      else
        MPDU = [];
        % start from next new input (i.e., middle of next twoLastInputs)
        if isempty(chipSeqNo)
          chipSeqNo = 0;
        end
        
        if obj.pNextStart + chipSeqNo*obj.pChipLen > length(obj.pPrevInput)*2
          obj.pNextStart = obj.pNextStart + chipSeqNo*obj.pChipLen - length(obj.pPrevInput)*2;
        else
          obj.pNextStart = obj.pNextStart + chipSeqNo*obj.pChipLen;
        end
        
        if isempty(obj.pPrevInput)
          % this is the first and only input, so we need to expect a longer end
          nextLen = length(twoLastInputs)*2*2;
        else
          nextLen = length(twoLastInputs)*2;
        end
          
        if nextLen < obj.pNextStart + obj.pRemainingFrameBits*8 
          obj.pNextStop  = nextLen - obj.pMargin;          
        else
          obj.pNextStop  = obj.pNextStart + obj.pRemainingFrameBits*8;  % *8 for bits-> real-only chips conversion
        end
      end
    end
    
    function symbol = despread(obj, chip)
      % Find the closest chip sequence
      [~, symbol] = min(sum(xor(chip', obj.pChipMap), 2));
      % subtract from size to cancel flipud:
      symbol = size(obj.pChipMap, 1) - symbol; % result follows 0-based indexing
    end
    
    function flag = isInactivePropertyImpl(obj, prop)
      flag = false;
      switch prop
        case {'FineFrequencyCompensation'}
          flag = ~obj.CoarseFrequencyCompensation;
        case {'TimingRecovery'}
          flag = ~(obj.CoarseFrequencyCompensation && obj.FineFrequencyCompensation);
       end
    end
    
    function flag = isInputComplexityMutableImpl(~, ~)
        flag = true;
    end
      
  end
  
end

