function MPDU = PHYDecoderOQPSKNoSync( waveform, varargin )
%PHYDECODEROQPSKNOSYNC Receive-side O-QPSK physical layer of 802.15.4
%   MPDU = PHYDECODEROQPSKNOSYNC( WAVEFORM ) uses 16-ary offset QPSK (O-QPSK) to
%   demodulate the physical-layer waveform and produce the MAC protocol
%   data unit MPDU. The waveform is first filtered with a half-sine pulse
%   matched filter. Finally, it is also despreaded.
%
%   See also lrwpanWaveformGenerator, LRWPAN.PHYDECODERBPSK, LRWPAN.PHYDECODERASK,
%   LRWPAN.PHYDECODERGFSK

%   Copyright 2017-2023 The MathWorks, Inc.

persistent rcosfilt % Persistent raised cosine filter, as one-time setup is the computational bottleneck

%% Validation

% OSR specification
OSR = lrwpan.internal.osrValidation(nargin, varargin);

% frequency band specification
if nargin == 3
  band = validatestring(varargin{2},{'780 MHz', '868 MHz','915 MHz', '2450 MHz'},'','frequency band');
else
  band = '2450 MHz';
end
if strcmp(band, '2450 MHz')
  chipLen = 32;    
  % See Table 73 in IEEE 802.15.4,  2011 revision
  chipMap = ...
     [1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0;
      1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0;
      0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0;
      0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1;
      0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0 0 0 1 1;
      0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1 1 1 0 0;
      1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0 0 1;
      1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 1 0 0 1 0 0 0 1 0 1 1 1 0 1 1 0 1;
      1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1;
      1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1;
      0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1;
      0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0;
      0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1 0 1 1 0;
      0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 0 1;
      1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0 1 1 0 0;
      1 1 0 0 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 1 1 1 0 0 0];
else
  chipLen = 16;
  % See Table 74 in IEEE 802.15.4,  2011 revision
  chipMap =  [0 0 1 1 1 1 1 0 0 0 1 0 0 1 0 1;
              0 1 0 0 1 1 1 1 1 0 0 0 1 0 0 1;
              0 1 0 1 0 0 1 1 1 1 1 0 0 0 1 0;
              1 0 0 1 0 1 0 0 1 1 1 1 1 0 0 0;
              0 0 1 0 0 1 0 1 0 0 1 1 1 1 1 0;
              1 0 0 0 1 0 0 1 0 1 0 0 1 1 1 1;
              1 1 1 0 0 0 1 0 0 1 0 1 0 0 1 1;
              1 1 1 1 1 0 0 0 1 0 0 1 0 1 0 0;
              0 1 1 0 1 0 1 1 0 1 1 1 0 0 0 0;
              0 0 0 1 1 0 1 0 1 1 0 1 1 1 0 0;
              0 0 0 0 0 1 1 0 1 0 1 1 0 1 1 1;
              1 1 0 0 0 0 0 1 1 0 1 0 1 1 0 1;
              0 1 1 1 0 0 0 0 0 1 1 0 1 0 1 1;
              1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0;
              1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0;
              1 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1];
end

%% O-QPSK demodulation (part 1)
re = real(waveform( 1      :end-OSR/2)); % remove "dummy" real part at end
im = imag(waveform( 1+OSR/2:end));       % remove "dummy" imag part at start

%% Receive-side filtering
if strcmp(band, '780 MHz')
  
  if isempty(rcosfilt)
    rcosfilt = comm.RaisedCosineReceiveFilter('RolloffFactor', 0.8, ...
            'InputSamplesPerSymbol', OSR, 'DecimationFactor', OSR, 'Shape', 'Normal');
	elseif rcosfilt.InputSamplesPerSymbol ~= OSR
    release(rcosfilt);
    rcosfilt.InputSamplesPerSymbol = OSR;
    rcosfilt.DecimationFactor = OSR;
  end
  delay = rcosfilt.FilterSpanInSymbols;
  qpskWaveformPadded = [re im; zeros(delay*OSR, 2)];
  filtered = rcosfilt(qpskWaveformPadded);
  
  filteredReal = filtered(1+delay:end, 1);
  filteredImag = filtered(1+delay:end, 2);
  reset(rcosfilt); % reset persistent variable
  
else % '2.4 GHz', '868 MHz','915 MHz'
  filteredReal = intdump(re, OSR);
  filteredImag = intdump(im, OSR);
end
  
%% O-QPSK demodulation (part 2)
temp = [transpose(filteredReal); transpose(filteredImag)];
demodulated = temp(:) > 0; % Slicing, convert [-1 1] to [0 1]

bits = zeros(4, length(demodulated)/chipLen);
for idx = 1:length(demodulated)/chipLen
  
  %% Chip to symbol mapping
  thisChip = demodulated(1+(idx-1)*chipLen:idx * chipLen);
  
  % find the chip sequence that looks the most like the received (minimum number of bit errors)
  [~, symbol] = min(sum(xor(thisChip', chipMap), 2));
  symbol = symbol - 1; % -1 for 1-based indexing

  %% Symbol to bit mapping
  bits(:, idx) = int2bit(symbol, 4, false);
end
  
%% Remove headers, output MPDU (MAC protocol data unit)

preambleLen = 4*8;  % 4 octets
SFDLen = 8;         % 1 octet
PHRLen = 8;         % 1 octet
offset = preambleLen + SFDLen + PHRLen;
MPDU = bits(1+offset:end)';
