% ZigBee/UWB Waveform Generation
%
% Generate and decode waveforms and frames for the IEEE 802.15.4 physical
% and medium-access control layers and for the ZigBee network and
% application layers.
%
%   <a href="matlab:help lrwpanHRPConfig">lrwpanHRPConfig</a>           - Configuration for IEEE 802.15.4a/z UWB waveforms
%   <a href="matlab:help lrwpanOQPSKConfig">lrwpanOQPSKConfig</a>         - Configuration for OQPSK (ZigBee) IEEE 802.15.4 waveforms
%   <a href="matlab:help lrwpanWaveformGenerator">lrwpanWaveformGenerator</a>   - Generate UWB/OQPSK IEEE 802.15.4 waveforms
%
%   <a href="matlab:helpview('comm','comm_zigbee')">Documentation and example gallery for ZigBee</a>
%   <a href="matlab:helpview('comm','comm_uwb')">Documentation and example gallery for UWB</a>

% Copyright 2017-2023 The MathWorks, Inc.

