function PSDU = lrwpanWaveformDecoder(wave, cfg, varargin)
%LRWPANWAVEFORMDECODER Decode HRP IEEE 802.15.4a/z UWB waveform
% PSDU = LRWPANWAVEFORMDECODER(WAVE, CFG) decodes WAVE, an HRP (high rate
% pulse repetition frequency) ultra-wide band IEEE 802.15.4a/z waveform.
% CFG must be an <a
% href="matlab:help('lrwpanHRPConfig')">lrwpanHRPConfig</a> object matching the specifications of WAVE. 
% For example, WAVE is either an HRPF (higher pulse repetition frequency),
% BPRF (base pulse repetition frequency) or an IEEE 802.15.4a waveform,
% according to the Mode property of the input configuration object CFG. The
% output PSDU is the PHY service data unit, which is passed from the MAC
% layer to construct the payload of the HRP frame.
%
% PSDU = LRWPANWAVEFORMDECODER(..., VALIDATE) also performs frame-validity
% checks when the VALIDATE flag is true.
%
%   Example 1: 
%     % Decode an HPRF IEEE 802.15.4z waveform and compare output with original PSDU
%     psdu = randi([0, 1], 800, 1);                       % original PSDU
%     cfgHPRF = lrwpanHRPConfig(Mode='HPRF', ...          % HPRF mode
%                  MeanPRF='124.8MHz', ...                % 16 chips per payload symbol
%                  STSPacketConfiguration=1, ...          % Enable STS before payload
%                  NumSTSSegments=2, ...                  % 2 STS segments
%                  PSDULength=length(psdu));
%     waveHPRF = lrwpanWaveformGenerator(psdu, cfgHPRF);  % create HPRF waveform
%     psduDec = lrwpanWaveformDecoder(waveHPRF, cfgHPRF); % decode HPRF waveform
%     assert(isequal(psdu, psduDec));                     % compare output with original message
%
%   See also lrwpanHRPConfig, lrwpanWaveformGenerator.

%   Copyright 2021-2023 The MathWorks, Inc.

  narginchk(2, 3);
  if nargin == 2 
    validate = false;
  else
    validate = varargin{1};
  end
  
  PSDU = [];
  offset = 0;
  
  wave = real(wave)/max(real(wave)); % normalize to 1
  
  %% Integrate and dump: Convert waveform to ternary (-1, 0, 1) symbols
  if cfg.SamplesPerPulse > 1
    integOffset = 1+round(cfg.SamplesPerPulse/2); % Group delay is equal to SamplesPerPulse.
  
    integrated = intdump([wave(1+integOffset:end); zeros(integOffset, 1)], cfg.SamplesPerPulse) * cfg.SamplesPerPulse;
    ternarySymbols = integrated;
    T = 1;
  else
    ternarySymbols = wave;
    T = 1/3;
  end
  ternarySymbols(abs(ternarySymbols)<T) = 0;
  ternarySymbols(ternarySymbols>T) = 1;
  ternarySymbols(ternarySymbols<-T) = -1;
  
  %% SYNC finding
  code = lrwpan.internal.HRPCodes(cfg.CodeIndex);
  L = cfg.PreambleSpreadingFactor;
  Nsync = cfg.PreambleDuration;
  spreadedCode = zeros(cfg.PreambleCodeLength*L, 1);
  spreadedCode(1:L:end) = code;
  repeatedCode = repmat(spreadedCode, Nsync, 1);
  SYNClen = Nsync*L*cfg.PreambleCodeLength;
  
  if validate
    comparison = repeatedCode == ternarySymbols(offset+1:offset+SYNClen);
    if ~all(comparison)
      warning(message('lrwpan:LRWPAN:PreambleMismatch', 'SYNC', mat2str(find(comparison))));
    end
  end
  
  %% SFD
  SFD = lrwpan.internal.getSFD(cfg);
  spreadedSFD = SFD.*spreadedCode;
  spreadedSFD = spreadedSFD(:);
  preambleLen = SYNClen + length(spreadedSFD);
  
  if validate
    comparison = spreadedSFD == ternarySymbols(offset+SYNClen+1:offset+preambleLen);
    if ~all(comparison)
      warning(message('lrwpan:LRWPAN:PreambleMismatch', 'SFD', mat2str(find(comparison))));
    end
  end
  
  %% STS Packet Configuration
  switch cfg.STSPacketConfiguration
    case 0
      phrStart = offset+preambleLen+1;
      [phrEnd, phrCW] = processPHR(ternarySymbols, phrStart, cfg, validate);
      payloadStart = phrEnd+1;
      PSDU = decodePayload(ternarySymbols, payloadStart, phrCW, cfg);
    
    case 1
      if strcmp(cfg.Mode, '802.15.4a')
        phrStart = offset+preambleLen+1;
      else
        stsStart = offset+preambleLen+1;
        stsEnd = processSTS(ternarySymbols, stsStart, cfg);   
        phrStart = stsEnd+1;
      end
      [phrEnd, phrCW] = processPHR(ternarySymbols, phrStart, cfg, validate);
      payloadStart = phrEnd+1;
      PSDU = decodePayload(ternarySymbols, payloadStart, phrCW, cfg);
      
    case 2
      phrStart = offset+preambleLen+1;
      [phrEnd, phrCW] = processPHR(ternarySymbols, phrStart, cfg, validate);
      payloadStart = phrEnd+1;
      [PSDU, payloadEnd] = decodePayload(ternarySymbols, payloadStart, phrCW, cfg);
    
      stsStart = payloadEnd+1;
      processSTS(ternarySymbols, stsStart, cfg);
      
    otherwise % case 3
      stsStart = offset+preambleLen+1;
      processSTS(ternarySymbols, stsStart, cfg);
  end

end

%% PHR demodulation & decoding
function [phrEnd, cw] = processPHR(ternarySymbols, phrStart, cfg, validate)
  phrNotPayload = true;
  
  inHPRF = cfg.MeanPRFNum > 62.4;
  if inHPRF
    [cw, phrEnd] = demodHPRF(phrNotPayload, ternarySymbols, phrStart, cfg);
    
  else % BPM-BPSK (Burst-position modulation w BPSK)
   
    [cw, phrEnd] = demodBPMBPSK(phrNotPayload, ternarySymbols, phrStart, cfg);
  end
  % Rate 1/2 coding:
  PHRdemod = convdec(cw(:), cfg.ConstraintLength);
  
  % SECDED decoding -> PHR header
  if validate
    phrLen = 19;
    decodePHR(PHRdemod(1:phrLen), cfg);
  end
end
  

%% Payload demodulation and decoding
function [PSDU, payloadEnd] = decodePayload(ternarySymbols, payloadStart, cwPHR, cfg)
  phrNotPayload = false;
  
  PSDULength = cfg.PSDULength*8;
  if cfg.MeanPRFNum < 124.8 || cfg.ConstraintLength == 3
    % PSDU Length describe the number of uncoded octets. ternarySymbols
    % contain PSDU that may be RS-encoded
    N = 63;
    K = 55;
    blockSize = 330;
    % parity bits are added for any block of 333 bits, even if partially filled
    PSDULength = PSDULength + ((N-K)*blockSize/K) * ceil(PSDULength/blockSize);
  end
  
  % "Modulation symbols" to codewords
  inHPRF = cfg.MeanPRFNum > 62.4;
  if inHPRF
    [cwPayload, payloadEnd] = demodHPRF(phrNotPayload, ternarySymbols, payloadStart, cfg, PSDULength);
    
  else % BPM-BPSK (Burst-position modulation w BPSK)
   
    [cwPayload, payloadEnd] = demodBPMBPSK(phrNotPayload, ternarySymbols, payloadStart, cfg, PSDULength);
  end
  
  % Rate 1/2 convolutional coding:
  if cfg.ConvolutionalCoding
    cw = [cwPHR cwPayload];
    decoded = convdec(cw(:), cfg.ConstraintLength);
    
    numPHRSymbols = 19;
    if cfg.MeanPRFNum < 124.8 || cfg.ConstraintLength == 3
      tailToIgnore = 2;
      rsCW = decoded(1+numPHRSymbols: end-tailToIgnore);
    
    else % CL = 7
      % Sec. 15.3.3.3 in 15.4z: "separately appending six zero bits to both the PHR and the PSDU"
      tailToIgnore = 6;
      % tail after payload is ignored during modulation
      rsCW = decoded(1+numPHRSymbols+tailToIgnore: end);
    end
    
  else % No Convolutional Coding
    rsCW = cwPayload;
  end
  
  % Reed Solomon decoding -> PSDU
  if cfg.MeanPRFNum < 124.8 || cfg.ConstraintLength == 3
    encodeNotDecode = false;
    PSDU = lrwpan.internal.hrpRS(rsCW, encodeNotDecode);
  else
    % no RS encoding when HPRF and constraint length = 7
    PSDU = rsCW;
  end
end
  
%% HPRF demodulation for PHR & Payload
function [cw, fieldEnd] = demodHPRF(phrNotPayload, ternarySymbols, fieldStart, cfg, varargin)
  
  phrLen = 19;
  if cfg.MeanPRFNum < 124.8 || cfg.ConstraintLength == 3
    numPHRSym = phrLen+2;
  else % CL = 7 
    numPHRSym = phrLen+6;
  end
  if phrNotPayload
    numSymbols = numPHRSym;
  else
    PSDULength = varargin{1};
    numSymbols = PSDULength;
  end
  cw = zeros(2, numSymbols); % pre-allocate to prevent auto-grow in FOR loop

  fieldEnd = fieldStart; % init
  
  if cfg.MeanPRFNum > 124.8
    chipsPerSymbol = 16 * (1+phrNotPayload); % double the symbols for PHR
  else
    chipsPerSymbol = 64 * (1+phrNotPayload);
  end
  if cfg.ConstraintLength==7 && phrNotPayload
    chipsPerSymbol = chipsPerSymbol/2;
  end
  % chipsPerSymbol above includes guard bands. ChipsPerSymbol from
  % lrwpanHRPConfig describes only the meaningful content (without guard bands)
  if phrNotPayload
    pnSamplesPerFrame = cfg.ChipsPerSymbol(1);
    pnMaskOffset = 0;
  else
    pnSamplesPerFrame = cfg.ChipsPerSymbol(end);
    pnMaskOffset = numPHRSym*cfg.ChipsPerSymbol(1);
  end
  pn = lrwpan.internal.createScrambler(cfg.CodeIndex, pnSamplesPerFrame, pnMaskOffset);
    
  symbols = reshape(ternarySymbols(fieldStart:fieldStart+numSymbols*chipsPerSymbol-1), chipsPerSymbol, []);
  if cfg.MeanPRFNum == 124.8
    symbols = symbols(1:2:end, :); % extra guard band between chips for 124.8 MHz
  end
  
  % Demodulate, ChipsPerSymbol bits -> 2-bit codewords
  symbolMap = lrwpan.internal.hrpHPRFSymbolMap(cfg.MeanPRFNum, cfg.ConstraintLength);
  if ~phrNotPayload && cfg.ConstraintLength==3
    symbolMap = symbolMap(:, 1:(end*(1+phrNotPayload)/2));
  end
  longerPHR = phrNotPayload && (cfg.ConstraintLength==3);
  for sym = 1:numSymbols
    thisSym = symbols(:, sym);
    
    % remove guard bands:
    thisSym = reshape(thisSym, [], 4*(1+longerPHR));
    thisSym = thisSym(:, 1:2:end);
    thisSym = thisSym(:);
    
    % Despread/Descramble:
    spreadingSeq  = pn();
    thisSym = thisSym./(1-2*spreadingSeq);
    
    % Bipolar to unipolar conversion: -1->1, 1->0
    thisSym = (1-thisSym)/2;
    
    % project the current symbol to all possible symbols. Choose
    % (demodulate) the one with the smallest Hamming distance (bit errors)
    [~, demodIdx] = min(sum(xor(symbolMap, thisSym'), 2));
    
    % Map table index to binary codeword from Tables 15-10c/d/ef
    msbFirst = false;
    cw(:, sym) = int2bit(demodIdx-1, 2, msbFirst);
  end
  
  fieldEnd = fieldEnd + chipsPerSymbol*numSymbols -1;
end

%% BPM-BPSK demodulation for PHR & Payload (BPRF, 802.15.4a)
function [cw, fieldEnd] = demodBPMBPSK(phrNotPayload, ternarySymbols, fieldStart, cfg, varargin)
  numPHRSym = 21;
  if phrNotPayload
    numSymbols = numPHRSym;
  else
    PSDULength = varargin{1};
    numSymbols = PSDULength;
  end
  cw = zeros(2, numSymbols);

  fieldEnd = fieldStart;
  
  if phrNotPayload
    pnSamplesPerFrame = cfg.ChipsPerBurst(1);
    pnMaskOffset = 0;
    chipsPerSymbol = cfg.ChipsPerSymbol(1);
  else
    pnSamplesPerFrame = cfg.ChipsPerBurst(end);
    pnMaskOffset = numPHRSym*cfg.ChipsPerBurst(1);
    chipsPerSymbol = cfg.ChipsPerSymbol(end);
  end
  pn = lrwpan.internal.createScrambler(cfg.CodeIndex, pnSamplesPerFrame, pnMaskOffset);
  symbols = reshape(ternarySymbols(fieldStart:fieldStart+numSymbols*chipsPerSymbol-1), chipsPerSymbol, []);
  for sym = 1:numSymbols
    thisSym = symbols(:, sym);
    % Find the burst with the highest energy, to find the used position:
    bursts = reshape(thisSym, pnSamplesPerFrame, []);
    burstPowers = sum(abs(bursts));
    [~, burstPosition] = max(burstPowers);
    
    % Systematic bit (g_0)
    systematicBit = burstPosition>cfg.BurstsPerSymbol/2;
    
    % Parity bit (g_1)
    thisBurst = bursts(:, burstPosition);
    % The Burst sequence is spreaded with the PN sequence and the Parity bit
    spreadingSeq  = pn();
    seqFor0 = thisBurst./(1-2*spreadingSeq);
    seqFor1 = -seqFor0;
    % Find the most likely parity bit value given the received burst and
    % the current spreader sequence. Minimize bit differences (Hamming
    % distance), with hard decision:
    if sum(seqFor1) > sum(seqFor0)
      parityBit = 1;
    else
      parityBit = 0;
    end

    cw(:, sym) = [systematicBit; parityBit];
  end
  fieldEnd = fieldEnd + numSymbols*chipsPerSymbol -1;
end

%% Convolutional Decoding for PHR & Payload
function systematicBits = convdec(cw, constraintLength)

  tbDepth = 5*(constraintLength-1);
  if constraintLength == 3
    % Constraint length 3, as in 15.3.3.3 in 15.4a 
    trellis = poly2trellis(3, [2 5]);
  else
    % Constraint length 7, as in 15.3.3.3 in 15.4z amendment
    trellis = poly2trellis(7, [133 171]);
    if size(cw, 1)/2 < tbDepth % PHR
      cw = [cw; zeros(10, 1)]; 
    end
  end
  systematicBits = vitdec(cw, trellis, tbDepth, 'trunc', 'hard');
end

%% PHR decoding (SECDED, frame decoding)  
function decodePHR(demodPHR, cfg)

% SECDED decoding 
% The parity bit XOR formula can construct a binary index address pointing
% to the location of the error in the systematic bits.
% Addressing is constructed after removing powers of two from possible indexes: 
% [b0 b1 b2 b3 b4 b5 b6 b7 b8 b9 b10 b11 b12]
%   3  5  6  7  9 10 11 12 13 14  15  17  18
  
  receivedSystematic = demodPHR(1:13);
  receivedParity = demodPHR(14:end);
  phr = lrwpan.internal.hrpSECDED(receivedSystematic);
  syndromes = xor(receivedParity, phr(14:end));
  
  idx = bit2int(syndromes(2:end), length(syndromes(2:end))); % exclude 14th bit, which is for DED only, not for error addressing
  
  if idx > 0 % error can be corrected
    powersOf2 = 2.^(0:5);
    addresses = setdiff(1:length(demodPHR), powersOf2);
    errorLocation = find(addresses==idx);
    phr(errorLocation) = ~phr(errorLocation);
      
    if ~syndromes(1) % Double error detection. 2nd error cannot be corrected.
      warning(message('lrwpan:LRWPAN:DED'));
    end
  end
  
  inHPRF = cfg.MeanPRFNum > 62.4;
  if inHPRF
    if cfg.STSPacketConfiguration == 2 && (cfg.ExtraSTSGapLength > 0 || cfg.ExtraSTSGapIndex > 0) 
      extraGapIdx = bit2int(phr([1 2]), 2);
      PSDULength = bit2int(phr(3:12), 10);
    else
      PSDULength = bit2int(phr(1:12), 12);
    end
    
    ranging = logical(phr(13));
  else
    if cfg.MeanPRFNum == 3.9
      dataRates = [0.11 0.85 1.7 6.81];
    else
      dataRates = [0.11 0.85 6.81 27.24];
    end
    dataRate = dataRates(1+bit2int(phr([1 2]), 2));
    if dataRate*1e3 ~= cfg.DataRateNum
      warning(message('lrwpan:LRWPAN:UnexpectedDataRate', num2str(dataRate), num2str(cfg.DataRateNum/1e3)));
    end
    
    PSDULength = bit2int(phr(3:9), 7); %#ok<*NASGU> 
    
    ranging = logical(phr(10));
    
    preambleDurations = [16 64 1024 4096];
    preambleDuration = preambleDurations(1+bit2int(phr([12 13]), 2, false));
    if preambleDuration ~= cfg.PreambleDuration
      warning(message('lrwpan:LRWPAN:UnexpectedPreambleDuration', preambleDuration, cfg.PreambleDuration));
    end
  end
  if PSDULength ~= cfg.PSDULength
    warning(message('lrwpan:LRWPAN:PSDULenMismatchTX', PSDULength, cfg.PSDULength));
  end
   
  if ranging ~= cfg.Ranging
    warning(message('lrwpan:LRWPAN:UnexpectedRanging', double(ranging)));
  end
end
  
%% STS processing
function stsEnd = processSTS(~, stsStart, cfg)

% This function does not perform AES-128 decoding.

  gapLen = 512; % chips
  if strcmp(cfg.Mode, 'BPRF')
    numSegments = 1;
    segmentLen = 64*512; % STSSegmentLength is in units of 512 chips
  else  
    numSegments = cfg.NumSTSSegments;
    segmentLen = cfg.STSSegmentLength*512; % it is in units of 512 chips
  end
  
  if strcmp(cfg.Mode, 'HPRF') && cfg.STSPacketConfiguration == 2
    % add extra gap
    extraGap = 4*cfg.ExtraSTSGapLength;
  else
    extraGap = 0;
  end
  
  stsEnd = stsStart + gapLen + extraGap + numSegments*(segmentLen+gapLen)-1;
end
