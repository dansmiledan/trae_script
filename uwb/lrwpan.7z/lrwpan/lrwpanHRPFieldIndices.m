function ind = lrwpanHRPFieldIndices(cfg)
%LRWPANHRPFieldIndices Find starting and ending index for each field of PHY frame
%  IND = LRWPANHRPFIELDINDICES(CFG) returns a struct IND containing [start
%  end] pairs for each field of the HRP UWB IEEE 802.15.4a/z waveform
%  described by the <a
% href="matlab:help('lrwpanHRPConfig')">lrwpanHRPConfig</a> configuration object CFG. The different fields that are located are: SYNC
%  (synchronization header), SFD (start of frame delimiter), PHR (PHY
%  header), payload and STS (scrambled timestamp sequence).

%   Copyright 2021-2023 The MathWorks, Inc.
    
  %% SYNC
  code = lrwpan.internal.HRPCodes(cfg.CodeIndex);
  L = cfg.PreambleSpreadingFactor;
  N = cfg.PreambleDuration;
  sps = cfg.SamplesPerPulse;
  
  syncLen = L*length(code)*N*sps;
  
  %% SFD  
  if strcmp(cfg.Mode, '802.15.4a')
    if cfg.DataRateNum ~= 110
      sfdLen = 8;
    else
      sfdLen = 64;
    end
    numSTSSegments = 0;
    segLen = 0;
    
  else
    if strcmp(cfg.Mode, 'BPRF')
    
      numSTSSegments = 1;
      segLen = 64*512; % STSSegmentLength is in units of 512 chips
    else % HPRF
      numSTSSegments = cfg.NumSTSSegments;
      segLen = cfg.STSSegmentLength*512; % STSSegmentLength is in units of 512 chips
    end
    switch cfg.SFDNumber  
      case {0, 2} 
        sfdLen = 8;
      case 1
        sfdLen = 4;
      case 3
        sfdLen = 16;
      case 4
        sfdLen = 32;
    end
  end
  
  sfdLen = sfdLen*L*length(code)*sps;
  
  ind.SHR = [1 syncLen+sfdLen];
  ind.SYNC = [1 syncLen];
  ind.SFD = [syncLen+1 syncLen+sfdLen];
  
  %% PHR & Payload
  numPSDUsym = cfg.PSDULength*8;
  if ~strcmp(cfg.Mode, 'HPRF') || cfg.ConstraintLength == 3
    % account for RS Encoding
    N = 63;  K = 55;  blockSize = 330;
    % parity bits are added for any block of 333 bits, even if partially filled
    numPSDUsym = numPSDUsym + ((N-K)*blockSize/K) * ceil(numPSDUsym/blockSize);
  end
  if ~cfg.ConvolutionalCoding
    % when convolutional coding is not applied, modulation treats odd bits
    % as systematic, even as parity
    numPSDUsym = numPSDUsym/2;
  end
   
  numPHRsymbols = 21;
  if ~strcmp(cfg.Mode, 'HPRF')
    phrLen = numPHRsymbols*cfg.ChipsPerSymbol(1)*cfg.SamplesPerPulse;
    psduLen = numPSDUsym*cfg.ChipsPerSymbol(end)*cfg.SamplesPerPulse;
  else
    if cfg.MeanPRFNum == 249.6
      phrLen = numPHRsymbols*32*cfg.SamplesPerPulse;
      psduLen = numPSDUsym*16*cfg.SamplesPerPulse;
    else
      phrLen = numPHRsymbols*128*cfg.SamplesPerPulse;
      psduLen = numPSDUsym*64*cfg.SamplesPerPulse;
    end
    if cfg.ConstraintLength == 7
      phrLen = phrLen/2; % same with Payload
    end
  end
  
  gapLen = 512;
  stsLen = gapLen+numSTSSegments*(segLen+gapLen);
  stsLen = stsLen*sps;
  
  if strcmp(cfg.Mode, '802.15.4a') || any(cfg.STSPacketConfiguration == [0 2])
    ind.PHR = [syncLen+sfdLen+1 syncLen+sfdLen+phrLen];
    ind.Payload = [syncLen+sfdLen+phrLen+1 syncLen+sfdLen+phrLen+psduLen];
  elseif cfg.STSPacketConfiguration == 1
    ind.PHR = [syncLen+sfdLen+stsLen+1 syncLen+sfdLen+stsLen+phrLen];
    ind.Payload = [syncLen+sfdLen+stsLen+phrLen+1 syncLen+sfdLen+stsLen+phrLen+psduLen];
  else % STSPacketConfiguration == 2
    ind.PHR = [];
    ind.Payload = [];
  end
  
  %% STS
  if strcmp(cfg.Mode, '802.15.4a') || cfg.STSPacketConfiguration==0
    ind.STS = [];
  else
    if any(cfg.STSPacketConfiguration==[1 3])
        ind.STS = [syncLen+sfdLen+1 syncLen+sfdLen+stsLen];
    else %2
        if strcmp(cfg.Mode, 'HPRF') && cfg.ExtraSTSGapLength > 0
          % add extra gap
          extraGap = 4*cfg.ExtraSTSGapLength;
        else
          extraGap = 0;
        end      
      
        ind.STS = [syncLen+sfdLen+phrLen+psduLen+1 syncLen+sfdLen+phrLen+psduLen+extraGap+stsLen];
    end
  end
